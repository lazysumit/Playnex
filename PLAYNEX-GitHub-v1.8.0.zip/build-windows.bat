@echo off
REM Builds the PLAYNEX installer. Requires Node.js 18+ (https://nodejs.org).
cd /d "%~dp0"
echo Checking the project contains no personal or computer details...
call node tools\privacy-check.js || goto :err
echo Installing build tools (warnings from third-party packages are hidden)...
call npm install --no-audit --no-fund --loglevel=error || goto :err
call npm run dist || goto :err
echo Checking the finished installer contents...
call node tools\privacy-check.js --dist || goto :leak
for /f "delims=" %%v in ('node -p "require('./package.json').version"') do set VER=%%v
echo.
echo Done. Installer is in the "dist" folder: PLAYNEX-Setup-%VER%.exe
pause
exit /b 0
:leak
del /q "dist\PLAYNEX-Setup-*.exe" 2>nul
echo The installer was deleted because it contained personal details.
:err
echo Build stopped.
pause
exit /b 1
