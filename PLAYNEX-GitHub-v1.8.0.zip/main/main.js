'use strict';
const { app, BrowserWindow, Tray, Menu, Notification, dialog, ipcMain, shell, nativeImage, nativeTheme, desktopCapturer, screen, globalShortcut, powerMonitor } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');
const { pathToFileURL } = require('url');

const { Store } = require('./store');
const { scanAll, PLATFORMS, manual, isNotGame } = require('./scanners');
const { Metadata, steamSearch } = require('./metadata');
const ratings = require('./ratings');
const { Wallpapers } = require('./wallpapers');
const { Tracker } = require('./tracker');
const { Music } = require('./music');
const { Overlay, volume } = require('./overlay');
const { evaluate } = require('./achievements');
const { Remote } = require('./remote');

if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }

let win = null, tray = null, store, meta, tracker;
let remote = null, powerPending = null, powerTimer = null;
let wall = null, music = null, musicDetecting = false, overlay = null, uiAccent = '#3d8bff';
let quitting = false, scanning = false, derived = null;
const ICON = path.join(__dirname, '..', 'build', 'icon.png');

/* ------------------------------------------------------------------ state */
const settings = () => store.data.settings;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const send = (ch, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(ch, ...a); };

function fullState() {
  const d = store.data;
  return {
    games: d.games, collections: d.collections, sessions: d.sessions, settings: d.settings,
    profile: d.profile, notifications: d.notifications, captures: d.captures, meta: d.meta,
    running: tracker ? tracker.snapshot() : {},
    achievements: derived ? derived.list : [], level: derived ? derived.level : null,
    version: app.getVersion(),
    remote: remote ? remote.info() : null, power: powerState(),
    wall: wall ? wall.state() : { busy: false, diag: {}, found: 0, shown: 0, active: 0, saved: 0, fetchedAt: 0 },
    music: { available: process.platform === 'win32', now: music ? music.now : [], installed: music ? music.installed : [], diag: music ? music.diag : null },
    platforms: PLATFORMS, systemDark: nativeTheme.shouldUseDarkColors, isFullscreen: !!(win && win.isFullScreen()),
  };
}
let pushTimer = null; const pending = new Set();
function push(...keys) {
  keys.forEach((k) => pending.add(k));
  if (pushTimer) return;
  pushTimer = setTimeout(() => {
    pushTimer = null;
    const s = fullState(); const patch = {};
    for (const k of pending) patch[k] = s[k];
    pending.clear();
    send('state:patch', patch);
    refreshTray();
  }, 60);
}

function refreshDerived() {
  derived = evaluate(store.data);
  for (const a of derived.fresh) notify('Achievement unlocked', `${a.name} — ${a.desc}`, 'achievement');
  push('achievements', 'level');
  store.save();
}

function notify(title, body, type = 'info') {
  const n = { id: uid(), ts: Date.now(), title, body, type, read: false };
  store.data.notifications.unshift(n);
  store.data.notifications.length = Math.min(store.data.notifications.length, 100);
  push('notifications');
  send('toast', n);
  if (settings().notifications && Notification.isSupported() && !(win && win.isFocused())) {
    try { new Notification({ title, body, icon: ICON, silent: type !== 'achievement' }).show(); } catch (_) { /* ignore */ }
  }
  store.save();
}

/* ---------------------------------------------------------------- library */
function mergeScan({ games, manualGames, report }) {
  const data = store.data, now = Date.now();
  const seen = new Set();
  const launcherDirs = new Set(games.map((g) => String(g.installDir).toLowerCase()));
  let added = 0;
  for (const r of [...games, ...manualGames]) {
    if (r.platform === 'manual' && launcherDirs.has(String(r.installDir).toLowerCase())) continue;
    const id = `${r.platform}:${r.appId}`;
    let g = data.games[id];
    if (!g) {
      g = data.games[id] = { id, added: now, playtime: 0, favorite: false, hidden: false, lastPlayed: null, art: {}, meta: {}, platform: r.platform };
      added++;
    }
    g.appId = r.appId; g.installDir = r.installDir; g.exe = r.exe || g.exe || null;
    if (!g.titleEdited) g.title = r.title;
    if (!g.customLaunch) g.launch = r.launch;
    if (r.steamAppId) g.steamAppId = r.steamAppId;
    if (r.extra) g.extra = r.extra;
    g.installed = true;
    seen.add(id);
  }
  // Retire launchers/utilities picked up by earlier scans (kept in the file so history isn't lost, but never shown or tracked).
  for (const g of Object.values(data.games)) if (isNotGame(g)) { g.installed = false; g.hidden = true; g.notGame = true; }
  // Mark uninstalled games (only for platforms whose scan succeeded)
  for (const g of Object.values(data.games)) {
    if (g.platform === 'custom' || seen.has(g.id)) continue;
    const key = g.platform;
    const ok = key === 'manual' ? !(report.manual && report.manual.error) : report[key] && !report[key].error && settings().platforms[key] !== false;
    if (ok) g.installed = false;
  }
  return added;
}

async function runScan() {
  if (scanning) return { busy: true };
  scanning = true; send('scan:progress', { state: 'start' });
  try {
    const res = await scanAll(settings(), (p) => send('scan:progress', { state: 'progress', ...p }));
    const added = mergeScan(res);
    store.data.meta.scans++; store.data.meta.firstRun = false;
    push('games', 'meta'); refreshDerived();
    const total = Object.values(store.data.games).filter((g) => g.installed !== false).length;
    send('scan:progress', { state: 'done', added, total, report: res.report });
    if (added) notify('Library updated', `${added} new game${added === 1 ? '' : 's'} found.`, 'library');
    queueMeta(Object.values(store.data.games).filter((g) => g.installed !== false && !g.metaFetched).map((g) => g.id));
    return { added, total, report: res.report };
  } finally { scanning = false; }
}

const metaQueue = []; let metaActive = 0;
function queueMeta(ids, opts = {}) {
  for (const id of ids) if (!metaQueue.find((q) => q.id === id)) metaQueue.push({ id, opts });
  pumpMeta();
}
function pumpMeta() {
  while (metaActive < 3 && metaQueue.length) {
    const { id, opts } = metaQueue.shift();
    const g = store.data.games[id];
    if (!g) continue;
    metaActive++;
    meta.identify(g, opts).then((patch) => {
      const cur = store.data.games[id]; if (!cur) return;
      Object.assign(cur, patch); push('games'); store.save();
    }).catch((e) => console.error('identify', id, e)).finally(() => { metaActive--; pumpMeta(); });
  }
}

async function launchGame(id) {
  const g = store.data.games[id];
  if (!g) return { ok: false, error: 'Game not found' };
  try {
    await tracker.launch(g);
    g.lastPlayed = Date.now(); push('games'); store.save();
    send('toast', { id: uid(), title: `Launching ${g.title}`, body: 'Starting…', type: 'launch' });
    return { ok: true };
  } catch (e) {
    const msg = `Could not start ${g.title}. ${e.code === 'ENOENT' ? 'The launcher or executable was not found.' : String(e.message || e)}`;
    notify('Launch failed', msg, 'error');
    return { ok: false, error: msg };
  }
}

function recordSession(gameId, start, end) {
  const g = store.data.games[gameId]; if (!g) return;
  const duration = Math.round((end - start) / 1000);
  store.data.sessions.push({ id: uid(), gameId, start, end, duration });
  if (store.data.sessions.length > 20000) store.data.sessions.splice(0, store.data.sessions.length - 20000);
  g.playtime = (g.playtime || 0) + duration; g.lastPlayed = end;
  const m = Math.round(duration / 60);
  notify(g.title, `Session ended — ${m >= 60 ? Math.floor(m / 60) + 'h ' + (m % 60) + 'm' : Math.max(1, m) + ' min'} played.`, 'session');
  push('games', 'sessions'); refreshDerived();
}


/* ------------------------------------------------------------- screenshots */
const safeName = (n) => String(n || 'Desktop').replace(/[<>:"/\\|?*\x00-\x1f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 60) || 'Desktop';
const stamp = (d = new Date()) => { const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`; };
let capturing = false;

/** F11 (configurable): captures the game you're playing, or the launcher itself when it is in front. */
async function takeScreenshot() {
  if (capturing) return null; capturing = true;
  try {
    const running = tracker ? tracker.snapshot() : {};
    const gid = Object.keys(running).sort((a, b) => running[b] - running[a])[0] || null;
    const g = gid ? store.data.games[gid] : null;
    const launcherInFront = win && !win.isDestroyed() && win.isVisible() && win.isFocused();
    let png;
    if (launcherInFront) {
      png = (await win.webContents.capturePage()).toPNG();
    } else {
      const disp = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
      const size = { width: Math.round(disp.size.width * disp.scaleFactor), height: Math.round(disp.size.height * disp.scaleFactor) };
      const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: size });
      const src = sources.find((x) => String(x.display_id) === String(disp.id)) || sources[0];
      if (!src || src.thumbnail.isEmpty()) throw new Error('Could not read the screen');
      png = src.thumbnail.toPNG();
    }
    const label = g ? g.title : launcherInFront ? 'PLAYNEX' : 'Desktop';
    const dir = path.join(app.getPath('pictures'), 'PLAYNEX', safeName(label));
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${safeName(label)} ${stamp()}.png`);
    fs.writeFileSync(file, png);
    const rec = { id: uid(), gameId: g ? g.id : null, label, file, url: pathToFileURL(file).href, ts: Date.now() };
    store.data.captures.unshift(rec);
    if (store.data.captures.length > 2000) store.data.captures.length = 2000;
    store.save(); push('captures');
    send('capture:flash', rec);
    if (settings().notifications && Notification.isSupported()) {
      try { new Notification({ title: 'Screenshot saved', body: label, silent: !settings().captureSound, icon: nativeImage.createFromPath(file).resize({ width: 256 }) }).show(); } catch (_) { /* ignore */ }
    }
    return rec;
  } catch (e) {
    notify('Screenshot failed', String(e.message || e), 'error'); return null;
  } finally { capturing = false; }
}

function registerCaptureKey() {
  globalShortcut.unregisterAll();
  const s = settings();
  const reg = (key, fn) => { try { return globalShortcut.register(key, fn); } catch (_) { return false; } };
  if (s.captureEnabled) {
    const key = s.captureKey || 'F11';
    if (!reg(key, () => { takeScreenshot(); })) notify('Screenshot key unavailable', `${key} is in use by another program. Pick a different key in Settings → Controls.`, 'error');
  }
  if (s.overlayEnabled !== false) {
    const key = s.overlayKey || 'Ctrl+Shift+G';
    if (!reg(key, () => { if (overlay) overlay.toggle(); })) notify('Overlay key unavailable', `${key} is in use by another program. Pick a different key in Settings → Controls.`, 'error');
  }
}


/* ----------------------------------------------------------------- power + phone remote */
const POWER_DELAY = 10;   // seconds the PC waits so a shut down / restart can still be cancelled
function powerState() { return { pending: powerPending, allowed: settings().remotePower !== false }; }
function setPending(p) { powerPending = p; clearTimeout(powerTimer); if (p) powerTimer = setTimeout(() => { powerPending = null; push('power'); }, (POWER_DELAY + 15) * 1000); push('power'); }
function runPower(kind) {
  if (process.platform !== 'win32') return Promise.resolve({ ok: false, error: 'Shut down and restart work on Windows only.' });
  const run = (args) => new Promise((resolve) => execFile('shutdown', args, { windowsHide: true, timeout: 10000 }, (err, _o, stderr) => resolve({ err, msg: String(stderr || (err && err.message) || '') })));
  if (kind === 'cancel') return run(['/a']).then((r) => { setPending(null); return r.err ? { ok: false, error: 'Nothing to cancel.' } : { ok: true }; });
  if (kind !== 'shutdown' && kind !== 'restart') return Promise.resolve({ ok: false, error: 'Unknown action.' });
  if (powerPending && powerPending.at > Date.now()) return Promise.resolve({ ok: false, error: 'A shut down or restart is already counting down.' });
  store.save();   // playtime and settings are written before Windows closes the app
  const args = [kind === 'restart' ? '/r' : '/s', '/t', String(POWER_DELAY), '/c', `PLAYNEX: ${kind === 'restart' ? 'restarting' : 'shutting down'} in ${POWER_DELAY} seconds`];
  if (settings().powerForce === true) args.push('/f');
  return run(args).then((r) => {
    if (r.err) return { ok: false, error: /1190|already/i.test(r.msg) ? 'A shut down or restart is already scheduled.' : 'Windows refused the request.' };
    const at = Date.now() + POWER_DELAY * 1000; setPending({ action: kind, at }); return { ok: true, at };
  });
}
async function confirmPower(kind) {
  const restart = kind === 'restart';
  const r = await dialog.showMessageBox(win && !win.isDestroyed() ? win : undefined, { type: 'warning', buttons: ['Cancel', restart ? 'Restart' : 'Shut down'], defaultId: 0, cancelId: 0, noLink: true, title: 'PLAYNEX', message: restart ? 'Restart this PC?' : 'Shut down this PC?', detail: `It will ${restart ? 'restart' : 'turn off'} in ${POWER_DELAY} seconds and you can cancel until then. Open games and apps will be closed.` });
  return r.response === 1 ? runPower(kind) : { ok: false, cancelled: true };
}

async function remoteStatus() {
  const d = store.data, run = tracker ? tracker.snapshot() : {}, st = settings();
  if (overlay) overlay.gpuKeepAlive();
  const running = Object.entries(run).map(([id, start]) => { const g = d.games[id]; return g ? { id, title: g.title, start } : null; }).filter(Boolean);
  const mus = st.musicEnabled !== false && music ? music.now.map((s) => ({ app: s.app, appId: s.appId, title: s.title, artist: s.artist, status: s.status, thumb: typeof s.thumb === 'string' && s.thumb.startsWith('data:') ? s.thumb : undefined })) : [];
  return { now: Date.now(), pc: os.hostname(), version: app.getVersion(), running, music: mus, sys: overlay ? overlay.sys() : {}, power: powerState() };
}
function applyRemote() {
  if (!remote) return Promise.resolve();
  const s = settings(); const port = Math.max(1024, Math.min(65535, Number(s.remotePort) || 47600));
  return s.remoteEnabled === true ? remote.start(port) : remote.stop();
}
function createRemote() {
  remote = new Remote({
    dir: store.dir, staticDir: path.join(__dirname, '..', 'renderer', 'remote'), status: remoteStatus,
    actions: {
      screenshot: () => takeScreenshot(),
      music: (cmd, appId) => (music ? music.control(cmd, appId) : false),
      quitGame: async (id) => (tracker && tracker.snapshot()[id] ? tracker.killGame(id) : false),
      power: (kind) => (kind !== 'cancel' && settings().remotePower === false ? { ok: false, error: 'Power actions from the phone are turned off on the PC (Settings, Remote).' } : runPower(kind)),
      captureFile: (id) => { const c = store.data.captures.find((x) => x.id === id); return c ? c.file : null; },
      cover: (id) => { const g = store.data.games[id]; return g ? (g.customArt && g.customArt.cover) || (g.art && (g.art.cover || g.art.icon)) || '' : ''; },
    },
  });
  remote.on('change', () => push('remote'));
  applyRemote();
}

/* ----------------------------------------------------------------- in-game overlay */
function overlayState() {
  const d = store.data, run = tracker ? tracker.snapshot() : {};
  const art = (g) => (g.customArt && g.customArt.cover) || (g.art && (g.art.cover || g.art.icon)) || '';
  const running = Object.entries(run).map(([id, start]) => { const g = d.games[id]; return g ? { id, title: g.title, start, cover: art(g) } : null; }).filter(Boolean);
  const recent = Object.values(d.games).filter((g) => g.installed !== false && !g.hidden && g.lastPlayed && !run[g.id]).sort((a, b) => b.lastPlayed - a.lastPlayed).slice(0, 6).map((g) => ({ id: g.id, title: g.title, cover: art(g) }));
  const day0 = new Date(); day0.setHours(0, 0, 0, 0);
  const today = d.sessions.filter((s) => s.end >= day0.getTime()).reduce((a, s) => a + s.duration, 0) + running.reduce((a, r) => a + Math.max(0, (Date.now() - Math.max(r.start, day0.getTime())) / 1000), 0);
  const st = settings();
  return { now: Date.now(), running, recent, today: Math.round(today), music: music ? music.now : [], accent: uiAccent, sys: overlay ? overlay.sys() : {}, musicOn: st.musicEnabled !== false, key: st.overlayKey || 'Ctrl+Shift+G', capture: !!st.captureEnabled };
}

/* ----------------------------------------------------------------- window */
function createWindow() {
  const b = store.data.meta.bounds || {};
  win = new BrowserWindow({
    width: b.width || 1440, height: b.height || 900, x: b.x, y: b.y, minWidth: 1000, minHeight: 640,
    frame: false, backgroundColor: '#05070d', show: false, title: 'PLAYNEX', icon: ICON,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => { if (!settings().startMinimized) win.show(); if (b.maximized) win.maximize(); });
  const saveBounds = () => {
    if (win.isDestroyed() || win.isFullScreen()) return;
    store.data.meta.bounds = { ...win.getNormalBounds(), maximized: win.isMaximized() }; store.save();
  };
  win.on('resize', saveBounds); win.on('move', saveBounds);
  win.on('enter-full-screen', () => send('fullscreen', true));
  win.on('leave-full-screen', () => send('fullscreen', false));
  win.on('maximize', () => send('fullscreen', win.isFullScreen()));
  win.on('close', (e) => {
    if (!quitting && settings().closeToTray && tray) {
      e.preventDefault(); win.hide();
      if (!store.data.meta.trayHinted) { store.data.meta.trayHinted = true; notify('Still running', 'PLAYNEX is in the system tray so playtime keeps tracking. Right-click the tray icon to quit.', 'info'); }
    }
  });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); } });
}

function showWindow() { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); }

function createTray() {
  try {
    const img = nativeImage.createFromPath(ICON);
    tray = new Tray(img.isEmpty() ? nativeImage.createEmpty() : img.resize({ width: 16, height: 16 }));
    tray.setToolTip('PLAYNEX');
    tray.on('click', () => (win && win.isVisible() && win.isFocused() ? win.hide() : showWindow()));
    refreshTray();
  } catch (e) { console.error('tray', e); tray = null; }
}
let trayTimer = null;
function refreshTray() {
  if (!tray) return;
  clearTimeout(trayTimer);
  trayTimer = setTimeout(() => {
    const recent = Object.values(store.data.games).filter((g) => g.lastPlayed && g.installed !== false)
      .sort((a, b) => b.lastPlayed - a.lastPlayed).slice(0, 6);
    const running = Object.keys(tracker ? tracker.snapshot() : {});
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Open PLAYNEX', click: showWindow },
      { type: 'separator' },
      ...(recent.length ? [{ label: 'Play', enabled: false }, ...recent.map((g) => ({ label: g.title, click: () => launchGame(g.id) }))] : [{ label: 'No recent games', enabled: false }]),
      { type: 'separator' },
      { label: 'Rescan library', click: () => runScan().catch(() => {}) },
      { label: 'Full screen', click: () => { showWindow(); win.setFullScreen(!win.isFullScreen()); } },
      { type: 'separator' },
      { label: running.length ? `Quit (${running.length} game${running.length > 1 ? 's' : ''} running)` : 'Quit', click: () => { quitting = true; app.quit(); } },
    ]));
    tray.setToolTip(running.length ? `PLAYNEX — playing ${store.data.games[running[0]]?.title || ''}` : 'PLAYNEX');
  }, 300);
}

/* -------------------------------------------------------------------- IPC */
const handle = (ch, fn) => ipcMain.handle(ch, async (e, ...a) => { try { return await fn(...a); } catch (err) { console.error(ch, err); return { error: String(err && err.message || err) }; } });
const copyInto = (src, destDir, base) => { fs.mkdirSync(destDir, { recursive: true }); const dest = path.join(destDir, base + path.extname(src).toLowerCase()); fs.copyFileSync(src, dest); return pathToFileURL(dest).href + '?v=' + Date.now(); };
const pickImage = async () => { const r = await dialog.showOpenDialog(win, { title: 'Choose an image', properties: ['openFile'], filters: [{ name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'] }] }); return r.canceled ? null : r.filePaths[0]; };

function registerIpc() {
  handle('state:get', () => fullState());

  handle('library:scan', () => runScan());
  handle('library:scanFolder', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a folder that contains your games', properties: ['openDirectory'] });
    if (r.canceled) return { canceled: true };
    const f = r.filePaths[0];
    if (!settings().scanFolders.includes(f)) settings().scanFolders.push(f);
    store.save(); push('settings');
    return runScan();
  });
  handle('library:removeFolder', (f) => { settings().scanFolders = settings().scanFolders.filter((x) => x !== f); store.save(); push('settings'); return runScan(); });
  handle('library:refreshAll', ({ force } = {}) => { const ids = Object.values(store.data.games).filter((g) => g.installed !== false).map((g) => g.id); queueMeta(ids, { force: !!force }); return { queued: ids.length }; });
  handle('library:addCustom', async ({ exe, title, args } = {}) => {
    if (!exe) {
      const r = await dialog.showOpenDialog(win, { title: 'Choose a game executable', properties: ['openFile'], filters: [{ name: 'Programs', extensions: ['exe', 'bat', 'cmd', 'lnk'] }] });
      if (r.canceled) return { canceled: true };
      exe = r.filePaths[0];
    }
    const raw = manual.customGame(exe, { title, args });
    const id = `${raw.platform}:${raw.appId}`;
    const g = store.data.games[id] || (store.data.games[id] = { id, added: Date.now(), playtime: 0, favorite: false, hidden: false, lastPlayed: null, art: {}, meta: {} });
    Object.assign(g, { platform: 'custom', appId: raw.appId, title: title || g.title || raw.title, titleEdited: !!title, installDir: raw.installDir, exe: raw.exe, launch: raw.launch, customLaunch: true, installed: true, hidden: false });
    push('games'); refreshDerived(); queueMeta([id]);
    return { id };
  });

  handle('dialog:pickExe', async () => { const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Programs', extensions: ['exe', 'bat', 'cmd'] }] }); return r.canceled ? null : r.filePaths[0]; });
  handle('dialog:pickImage', () => pickImage());

  handle('game:launch', (id) => launchGame(id));
  handle('game:update', (id, p) => {
    const g = store.data.games[id]; if (!g) return null;
    if (typeof p.title === 'string' && p.title.trim() && p.title !== g.title) { g.title = p.title.trim(); g.titleEdited = true; }
    if (typeof p.favorite === 'boolean') g.favorite = p.favorite;
    if (typeof p.hidden === 'boolean') g.hidden = p.hidden;
    if (typeof p.notes === 'string') g.notes = p.notes;
    if (typeof p.launchExe === 'string' || typeof p.launchArgs === 'string') {
      const cur = g.launch || { type: 'exe' };
      if (p.launchExe) { g.launch = { type: 'exe', target: p.launchExe, args: p.launchArgs ?? cur.args ?? '', cwd: path.dirname(p.launchExe) }; g.exe = p.launchExe; g.customLaunch = true; }
      else if (cur.type === 'exe') { g.launch = { ...cur, args: p.launchArgs || '' }; g.customLaunch = true; }
    }
    push('games'); refreshDerived(); return g;
  });
  handle('game:remove', (id) => {
    const g = store.data.games[id]; if (!g) return false;
    if (g.platform === 'custom') { g.installed = false; g.hidden = true; } else g.hidden = true;
    push('games'); refreshDerived(); return true;
  });
  handle('game:refreshMeta', (id, opts = {}) => { queueMeta([id], opts); return true; });
  handle('game:matches', (title) => meta.matches(title));
  handle('game:applyMatch', (id, steamAppId) => { const g = store.data.games[id]; if (g) { g.steamAppId = String(steamAppId); queueMeta([id], { steamAppId: String(steamAppId), force: true }); } return true; });
  handle('game:openFolder', (id) => { const g = store.data.games[id]; if (g && g.installDir) shell.openPath(g.installDir); return true; });
  handle('game:setArt', async (id, kind, action) => {
    const g = store.data.games[id]; if (!g) return null;
    g.customArt = g.customArt || {};
    if (action === 'clear') delete g.customArt[kind];
    else { const f = await pickImage(); if (!f) return null; g.customArt[kind] = copyInto(f, meta.dirFor(id), 'custom-' + kind); }
    push('games'); store.save(); return g.customArt;
  });
  const RATING_TTL = 3 * 24 * 3600 * 1000;
  handle('game:ratings', async (id, force) => {
    const g = store.data.games[id]; if (!g) return { error: 'Unknown game' };
    if (!force && g.ratings && Date.now() - g.ratings.fetchedAt < RATING_TTL && g.ratings.v === 4) return g.ratings;
    const m = g.meta || {};
    const r = await ratings.lookup({ title: (m.matchedName || g.title), steamAppId: g.steamAppId, steamSearch,
      steamMetacritic: m.metacritic ? { score: m.metacritic, url: m.metacriticUrl } : null, rawgKey: settings().rawgKey });
    r.v = 4;
    if (!r.critic && !r.steam && !r.rawg && g.ratings) return { ...g.ratings, stale: true };   // offline: keep what we had
    g.ratings = r; if (r.critic) g.meta = { ...m, metacritic: r.critic.score }; push('games'); store.save();
    return r;
  });
  handle('ratings:search', async (title) => {
    title = String(title || '').trim(); if (!title) return { error: 'Type a game name' };
    return { title, ...(await ratings.lookup({ title, steamSearch, rawgKey: settings().rawgKey })) };
  });
  handle('game:steamAchievements', async (id) => {
    const g = store.data.games[id]; const s = settings();
    if (!g || !g.steamAppId) return { error: 'This game is not matched to a Steam app.' };
    if (!s.steamApiKey || !s.steamId) return { error: 'Add your Steam Web API key and SteamID64 in Settings to see Steam achievements.' };
    try {
      const r = await fetch(`https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid=${g.steamAppId}&key=${encodeURIComponent(s.steamApiKey)}&steamid=${encodeURIComponent(s.steamId)}&l=english`);
      const j = await r.json();
      if (!j.playerstats || !j.playerstats.success) return { error: (j.playerstats && j.playerstats.error) || 'No achievements for this game, or your profile is private.' };
      return { list: (j.playerstats.achievements || []).map((a) => ({ id: a.apiname, name: a.name || a.apiname, desc: a.description || '', done: !!a.achieved, at: a.unlocktime ? a.unlocktime * 1000 : null })) };
    } catch (e) { return { error: 'Could not reach Steam. Check your connection and API key.' }; }
  });

  handle('collection:save', (c) => {
    const list = store.data.collections;
    if (c.id) { const x = list.find((k) => k.id === c.id); if (x) { x.name = c.name; if (c.color) x.color = c.color; } } else list.push({ id: uid(), name: c.name, color: c.color || null, gameIds: c.gameIds || [] });
    push('collections'); refreshDerived(); return list;
  });
  handle('collection:delete', (id) => { store.data.collections = store.data.collections.filter((c) => c.id !== id); push('collections'); refreshDerived(); return true; });
  handle('collection:toggleGame', (cid, gid) => {
    const c = store.data.collections.find((k) => k.id === cid); if (!c) return false;
    const i = c.gameIds.indexOf(gid); if (i >= 0) c.gameIds.splice(i, 1); else c.gameIds.push(gid);
    push('collections'); store.save(); return true;
  });

  handle('settings:set', (patch) => {
    const s = settings();
    for (const [k, v] of Object.entries(patch)) { if (k === 'platforms') Object.assign(s.platforms, v); else s[k] = v; }
    if ('captureEnabled' in patch || 'captureKey' in patch || 'overlayEnabled' in patch || 'overlayKey' in patch) registerCaptureKey();
    if ('musicEnabled' in patch && music) { if (s.musicEnabled) music.start(); else music.stop(); }
    if ('musicBrowser' in patch && music) music._last = '';
    if ('remoteEnabled' in patch || 'remotePort' in patch) applyRemote();
    if ('launchAtLogin' in patch) app.setLoginItemSettings({ openAtLogin: !!s.launchAtLogin, args: ['--hidden'] });
    const wallKeys = ['saverSource', 'saverWebQuality', 'saverWebWallhaven', 'saverWebBing', 'saverWebCave', 'saverWebHalla', 'saverCatGaming', 'saverCatNature', 'saverCatAnimals', 'saverCatSpace', 'saverCatCars', 'saverCatCities'];
    if (wall && wallKeys.some((k) => k in patch)) {
      if (wallKeys.slice(1).some((k) => k in patch)) wall.resetCatalog();                // sources / topics / quality changed: start from a fresh list
      if (s.saverSource === 'web' || s.saverSource === 'mix') wall.loadCatalog().catch(() => {});   // list only, no pictures
      push('wall');
    }
    store.save(); push('settings'); return s;
  });
  handle('wall:next', async () => (wall ? wall.next().catch(() => null) : null));
  handle('wall:check', async () => { if (!wall) return null; wall.loadCatalog(true).catch(() => {}); return wall.state(); });
  handle('wall:open', async () => { if (!wall) return null; const d = wall.folder(); fs.mkdirSync(d, { recursive: true }); const err = await shell.openPath(d); return { path: d, error: err || '' }; });
  handle('wall:clear', async () => { if (wall) wall.deleteAll(); return wall ? wall.state() : null; });
  handle('settings:setBackground', async (action) => {
    const s = settings();
    if (action === 'clear') { s.customBackground = null; if (s.wallpaper === 'custom') s.wallpaper = 'dynamic'; } else {
      const f = await pickImage(); if (!f) return null;
      s.customBackground = copyInto(f, store.dir, 'background'); s.wallpaper = 'custom';
    }
    store.save(); push('settings'); return s;
  });
  handle('profile:set', (p) => { Object.assign(store.data.profile, { name: String(p.name || 'Player One').slice(0, 24) }); store.save(); push('profile'); return store.data.profile; });
  handle('profile:setAvatar', async (action) => {
    if (action === 'clear') store.data.profile.avatar = null; else { const f = await pickImage(); if (!f) return null; store.data.profile.avatar = copyInto(f, store.dir, 'avatar'); }
    store.save(); push('profile'); return store.data.profile;
  });

  handle('notifications:read', () => { store.data.notifications.forEach((n) => { n.read = true; }); push('notifications'); store.save(); return true; });
  handle('notifications:clear', () => { store.data.notifications = []; push('notifications'); store.save(); return true; });

  handle('remote:pair', () => (remote ? remote.startPairing() : null));
  handle('remote:cancelPair', () => (remote ? remote.cancelPairing() : false));
  handle('remote:revoke', (id) => (remote ? remote.revoke(String(id)) : false));
  handle('remote:revokeAll', () => (remote ? remote.revokeAll() : false));
  handle('power:run', (kind) => confirmPower(String(kind)));
  handle('power:cancel', () => runPower('cancel'));
  handle('capture:take', () => takeScreenshot());
  handle('capture:show', (id) => { const c = store.data.captures.find((x) => x.id === id); if (c) shell.showItemInFolder(c.file); return !!c; });
  handle('capture:openFolder', () => { const d = path.join(app.getPath('pictures'), 'PLAYNEX'); fs.mkdirSync(d, { recursive: true }); return shell.openPath(d); });
  handle('capture:delete', (id) => {
    const i = store.data.captures.findIndex((x) => x.id === id); if (i < 0) return false;
    const [c] = store.data.captures.splice(i, 1);
    try { fs.unlinkSync(c.file); } catch (_) { /* already gone */ }
    store.save(); push('captures'); return true;
  });
  // OS-level idle time (keyboard/mouse anywhere) plus whether our window is actually in front.
  handle('app:idle', () => {
    let sec = null; try { sec = powerMonitor.getSystemIdleTime(); } catch (_) { /* unsupported */ }
    const w = win && !win.isDestroyed() ? win : null;
    return { sec, shown: !!(w && w.isVisible() && !w.isMinimized()), focused: !!(w && w.isFocused()) };
  });
  let saverWasFs = false;
  handle('app:screensaver', (on) => {
    if (!win || win.isDestroyed()) return false;
    if (on) { if (!win.isFocused() || !win.isVisible()) return false; saverWasFs = win.isFullScreen(); if (!saverWasFs) win.setFullScreen(true); }
    else if (!saverWasFs && win.isFullScreen()) win.setFullScreen(false);
    return true;
  });
  /* ---- music ---- */
  const musicApps = () => [...(music ? music.installed : []), ...(settings().musicApps || []).map((a) => ({ ...a, custom: true }))];
  const detectMusic = async () => { if (!music || musicDetecting) return; musicDetecting = true; try { await music.detect(); } finally { musicDetecting = false; push('music'); } };
  handle('ui:accent', (c) => { if (/^#[0-9a-f]{6}$/i.test(c)) uiAccent = c; return true; });
  handle('overlay:toggle', () => { if (overlay) overlay.toggle(); return true; });
  ipcMain.handle('overlay:state', () => overlayState());
  ipcMain.handle('overlay:close', () => { if (overlay) overlay.hide(); return true; });
  ipcMain.handle('overlay:action', async (_e, action, arg) => {
    switch (action) {
      case 'music': return music ? music.control(arg && arg.cmd, arg && arg.appId) : false;
      case 'volume': return volume(arg);
      case 'capture': if (overlay) overlay.hide(); await new Promise((r) => setTimeout(r, 350)); return takeScreenshot();
      case 'launcher': if (overlay) overlay.hide(); if (win) { win.show(); if (win.isMinimized()) win.restore(); win.focus(); } return true;
      case 'launch': if (overlay) overlay.hide(); return launchGame(String(arg));
      case 'quit': return tracker ? tracker.killGame(String(arg)) : false;
      default: return false;
    }
  });
  handle('music:control', (action, appId) => (music ? music.control(action, appId) : false));
  handle('music:detect', async () => { await detectMusic(); return true; });
  handle('music:launch', (id) => { const a = musicApps().find((x) => x.id === id); return a && music ? music.launch(a) : false; });
  handle('music:add', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a music app', properties: ['openFile'], filters: [{ name: 'Programs', extensions: ['exe', 'lnk', 'bat', 'cmd'] }] });
    if (r.canceled || !r.filePaths[0]) return null;
    const exe = r.filePaths[0]; const name = path.basename(exe).replace(/\.[^.]+$/, '');
    const s = settings(); s.musicApps = s.musicApps || [];
    if (!s.musicApps.some((a) => a.exe.toLowerCase() === exe.toLowerCase())) s.musicApps.push({ id: 'custom-' + Date.now().toString(36), name, exe });
    store.save(); push('settings', 'music'); return true;
  });
  handle('music:rename', (id, name) => { const a = (settings().musicApps || []).find((x) => x.id === id); if (a && String(name).trim()) { a.name = String(name).trim().slice(0, 40); store.save(); push('settings'); } return !!a; });
  handle('music:remove', (id) => { const s = settings(); s.musicApps = (s.musicApps || []).filter((a) => a.id !== id); store.save(); push('settings', 'music'); return true; });
  handle('app:fullscreen', () => { win.setFullScreen(!win.isFullScreen()); return win.isFullScreen(); });
  handle('app:openDataDir', () => shell.openPath(store.dir));
  handle('app:exportData', async () => {
    const r = await dialog.showSaveDialog(win, { defaultPath: 'playnex-backup.json', filters: [{ name: 'JSON', extensions: ['json'] }] });
    if (r.canceled) return false; fs.writeFileSync(r.filePath, JSON.stringify(store.data, null, 2)); return true;
  });
  handle('app:quit', () => { quitting = true; app.quit(); });
  handle('win:minimize', () => win.minimize());
  handle('win:maximize', () => { if (win.isMaximized()) win.unmaximize(); else win.maximize(); return win.isMaximized(); });
  handle('win:close', () => win.close());
}


/** The app used to be called "Game Launcher". Bring its saved data (library, settings, artwork) and screenshots over once, so nothing is lost. */
function migrateFromGameLauncher() {
  try {
    const now = app.getPath('userData'), old = path.join(app.getPath('appData'), 'Game Launcher');
    if (old !== now && fs.existsSync(path.join(old, 'library.json')) && !fs.existsSync(path.join(now, 'library.json'))) {
      const skip = /[\\/](Cache|Code Cache|GPUCache|Crashpad|DawnCache|blob_storage|Session Storage|Local Storage|Network|Partitions|wallpapers)([\\/]|$)/i;
      fs.mkdirSync(now, { recursive: true });
      fs.cpSync(old, now, { recursive: true, force: false, filter: (src) => !skip.test(src) });
    }
    const oldPics = path.join(app.getPath('pictures'), 'Game Launcher'), newPics = path.join(app.getPath('pictures'), 'PLAYNEX');
    if (fs.existsSync(oldPics) && !fs.existsSync(newPics)) fs.renameSync(oldPics, newPics);
  } catch (_) { /* best effort: the app still starts, just with a fresh library */ }
}

/* -------------------------------------------------------------- app start */
app.on('second-instance', showWindow);
app.on('will-quit', () => { globalShortcut.unregisterAll(); if (remote) remote.stop(); if (wall) wall.onQuit(); });   // temporary pictures always go; saved ones only stay if "keep" is on
app.on('before-quit', () => { quitting = true; if (overlay) overlay.destroy(); if (music) music.stop(); if (tracker) { tracker.stop(); tracker.flushAll(); } if (store) store.flush(); });
app.on('window-all-closed', () => { if (quitting || !tray) app.quit(); });

app.whenReady().then(() => {
  app.setAppUserModelId('com.local.gamelauncher');   // internal ID: must never change, or Windows treats new versions as a different app
  migrateFromGameLauncher();
  store = new Store(app.getPath('userData'));
  meta = new Metadata({
    artDir: path.join(app.getPath('userData'), 'art'), getSettings: settings,
    getIcon: async (exe) => { const img = await app.getFileIcon(exe, { size: 'large' }); return img.isEmpty() ? null : img.toPNG(); },
  });
  tracker = new Tracker({
    getGames: () => store.data.games, recordSession,
    onChange: (running) => { push('running'); send('state:patch', { running }); },
    openExternal: (url) => shell.openExternal(url),
  });
  registerIpc();
  createRemote();
  createWindow();
  overlay = new Overlay({});
  registerCaptureKey();
  createTray();
  nativeTheme.on('updated', () => push('systemDark'));
  derived = evaluate(store.data); store.save();
  tracker.start();
  wall = new Wallpapers({ dir: path.join(app.getPath('temp'), 'playnex-wallpapers'), persistDir: path.join(app.getPath('userData'), 'wallpapers'), getSettings: settings, onChange: () => push('wall') });
  setTimeout(() => { const s = settings(); if (s.saverSource === 'web' || s.saverSource === 'mix') wall.loadCatalog().catch(() => {}); }, 15000);   // just the list of links
  music = new Music({ getSettings: settings });
  music.on('change', () => push('music'));
  if (settings().musicEnabled !== false) music.start();
  setTimeout(() => { if (music) music.detect().then(() => push('music')).catch(() => {}); }, 4000);
  win.webContents.once('did-finish-load', () => {
    const first = store.data.meta.firstRun;
    if (first || settings().scanOnStartup) setTimeout(() => runScan().catch((e) => console.error('scan', e)), 800);
    else queueMeta(Object.values(store.data.games).filter((g) => g.installed !== false && !g.metaFetched).map((g) => g.id));
  });
});
