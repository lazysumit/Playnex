'use strict';
// Game launching + process monitoring + playtime/session tracking.
const path = require('path');
const { spawn, execFile } = require('child_process');

const isWin = process.platform === 'win32';
const lc = (s) => String(s || '').toLowerCase();

function listProcessPaths() {
  return new Promise((resolve) => {
    if (!isWin) return resolve([]);
    // Win32_Process also reports paths of elevated (admin) games, which Get-Process hides from a normal app.
    const cmd = "$a = @(Get-CimInstance Win32_Process -Property ExecutablePath -ErrorAction SilentlyContinue | ForEach-Object { $_.ExecutablePath }); $b = @(Get-Process -ErrorAction SilentlyContinue | ForEach-Object { $_.Path }); ($a + $b) | Where-Object { $_ } | Sort-Object -Unique";
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', cmd],
      { windowsHide: true, maxBuffer: 16 * 1024 * 1024, timeout: 15000 }, (err, stdout) => {
        if (err && !stdout) return resolve([]);
        resolve(String(stdout).split(/\r?\n/).map((s) => s.trim()).filter(Boolean));
      });
  });
}

class Tracker {
  /**
   * deps: { getGames:()=>object, recordSession(gameId,start,end), onChange(running), openExternal(url) }
   */
  constructor(deps) {
    this.d = deps;
    this.running = {}; // gameId -> { start, lastSeen, misses }
    this.timer = null;
    this.boost = 0;
    this.busy = false;
  }

  start() { this._schedule(1500); }
  stop() { clearTimeout(this.timer); this.timer = null; }
  _schedule(ms) { clearTimeout(this.timer); this.timer = setTimeout(() => this._tick(), ms); }

  async launch(game) {
    const l = game.launch || {};
    const args = l.args ? l.args.match(/(?:[^\s"]+|"[^"]*")+/g).map((a) => a.replace(/^"|"$/g, '')) : [];
    const runExe = (exe, cwd) => new Promise((resolve, reject) => {
      const child = spawn(exe, args, { cwd: cwd || path.dirname(exe), detached: true, stdio: 'ignore', windowsHide: false });
      child.once('error', reject);
      child.once('spawn', () => { child.unref(); resolve(); });
    });
    const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
    // Programs that need administrator rights can't be started by a normal process (EACCES / error 740).
    // Start-Process -Verb RunAs shows the Windows permission prompt and starts the game elevated.
    const runElevated = (exe, cwd) => new Promise((resolve, reject) => {
      const ps = `Start-Process -FilePath ${q(exe)} ${args.length ? '-ArgumentList ' + args.map(q).join(',') + ' ' : ''}-WorkingDirectory ${q(cwd || path.dirname(exe))} -Verb RunAs -ErrorAction Stop`;
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true, timeout: 180000 }, (err, _o, stderr) => {
        if (!err) return resolve();
        reject(new Error(/cancel/i.test(String(stderr) + err.message) ? 'Administrator permission was declined, so the game was not started.' : 'Could not start the game as administrator. ' + String(stderr || err.message).split('\n')[0]));
      });
    });
    const needsElevation = (e) => e && (['EACCES', 'EPERM', 'UNKNOWN'].includes(e.code) || e.errno === 740 || /elevation|740/i.test(String(e.message)));
    const start = async (exe, cwd) => {
      if (game.needsAdmin) return runElevated(exe, cwd);
      try { await runExe(exe, cwd); } catch (e) {
        if (!needsElevation(e)) throw e;
        await runElevated(exe, cwd); game.needsAdmin = true; // remembered: next time it goes straight to the prompt
      }
    };
    try {
      if (l.type === 'protocol') await this.d.openExternal(l.target);
      else if (l.type === 'aumid') {
        try { await new Promise((res, rej) => spawn('explorer.exe', [`shell:AppsFolder\\${l.target}`], { detached: true, stdio: 'ignore' }).once('error', rej).once('spawn', res)); }
        catch (e) { if (l.fallbackExe) await start(l.fallbackExe); else throw e; }
      } else if (l.type === 'exe') await start(l.target, l.cwd);
      else throw new Error('No launch method for this game.');
    } catch (e) {
      if (l.fallbackExe && l.type !== 'aumid') { await start(l.fallbackExe); } else throw e;
    }
    this.boost = 15; // poll quickly for the next ~30s to catch the process
    this._schedule(1500);
    return true;
  }

  async _tick() {
    if (this.busy) return;
    this.busy = true;
    try {
      const procs = (await listProcessPaths()).map(lc);
      const set = new Set(procs);
      const games = Object.values(this.d.getGames()).filter((g) => g.installed !== false);
      const now = Date.now();
      const active = new Set();
      // longest install dir wins so nested folders don't double count
      const targets = games.map((g) => ({
        id: g.id,
        dir: g.installDir ? lc(g.installDir).replace(/[\\/]+$/, '') + '\\' : null,
        exe: lc(g.exe || (g.launch && g.launch.type === 'exe' ? g.launch.target : '')),
        launcherExe: g.platform === 'riot' || g.platform === 'ea',
      }));
      const ownerOf = new Map();
      for (const p of set) {
        let best = null;
        for (const t of targets) {
          if ((t.dir && p.startsWith(t.dir)) || (t.exe && p === t.exe)) {
            const len = t.dir ? t.dir.length : t.exe.length;
            if (!best || len > best.len) best = { id: t.id, len };
          }
        }
        if (best) ownerOf.set(best.id, true);
      }
      for (const id of ownerOf.keys()) active.add(id);

      let changed = false;
      for (const id of active) {
        if (!this.running[id]) { this.running[id] = { start: now, lastSeen: now, misses: 0 }; changed = true; } else { this.running[id].lastSeen = now; this.running[id].misses = 0; }
      }
      for (const id of Object.keys(this.running)) {
        if (active.has(id)) continue;
        const r = this.running[id];
        r.misses++;
        if (r.misses >= 2) {
          delete this.running[id]; changed = true;
          if (r.lastSeen - r.start >= 10000) this.d.recordSession(id, r.start, r.lastSeen);
        }
      }
      if (changed) this.d.onChange(this.snapshot());
    } catch (e) { console.error('tracker tick', e); } finally {
      this.busy = false;
      const next = this.boost > 0 ? 2000 : Object.keys(this.running).length ? 5000 : 7000;
      if (this.boost > 0) this.boost--;
      this._schedule(next);
    }
  }

  /** Stop every process that belongs to a game (same ownership rule used for tracking). Returns true if a command was issued. */
  killGame(id) {
    const g = this.d.getGames()[id];
    if (!g || !isWin) return Promise.resolve(false);
    const dir = g.installDir ? lc(g.installDir).replace(/[\\/]+$/, '') + '\\' : '';
    const exe = lc(g.exe || (g.launch && g.launch.type === 'exe' ? g.launch.target : ''));
    if (dir.length < 8 && !exe) return Promise.resolve(false); // never match a drive root
    const cmd = "$d=$env:GL_DIR; $e=$env:GL_EXE; Get-CimInstance Win32_Process -Property ExecutablePath,ProcessId | Where-Object { $_.ExecutablePath -and ((($d.Length -ge 8) -and $_.ExecutablePath.ToLower().StartsWith($d)) -or ($e -and $_.ExecutablePath.ToLower() -eq $e)) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }";
    return new Promise((resolve) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', cmd],
      { windowsHide: true, timeout: 15000, env: { ...process.env, GL_DIR: dir, GL_EXE: exe } }, () => { this.boost = 3; resolve(true); }));
  }

  snapshot() { const o = {}; for (const [id, r] of Object.entries(this.running)) o[id] = r.start; return o; }

  /** Flush running sessions when the app quits so playtime isn't lost. */
  flushAll() {
    for (const [id, r] of Object.entries(this.running)) {
      if (r.lastSeen - r.start >= 10000) this.d.recordSession(id, r.start, r.lastSeen);
    }
    this.running = {};
  }
}

module.exports = { Tracker, listProcessPaths };
