'use strict';
// Launcher achievements, stats and gamer-level maths. Pure functions => easy to test.

const DAY = 86400000;
const dayKey = (t) => { const d = new Date(t); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); };

function computeStats(data) {
  const games = Object.values(data.games);
  const installed = games.filter((g) => g.installed !== false && !g.hidden);
  const sessions = data.sessions;
  const totalSec = games.reduce((a, g) => a + (g.playtime || 0), 0);
  const perDay = {};
  let longest = 0, night = 0, early = 0;
  for (const s of sessions) {
    const k = dayKey(s.start);
    perDay[k] = (perDay[k] || 0) + s.duration;
    longest = Math.max(longest, s.duration);
    const h = new Date(s.start).getHours();
    if (h < 5) night++;
    else if (h < 8) early++;
  }
  // streak ending today (or yesterday)
  let streak = 0;
  let t = Date.now();
  if (!perDay[dayKey(t)]) t -= DAY;
  while (perDay[dayKey(t)]) { streak++; t -= DAY; }
  let bestStreak = 0, run = 0;
  const keys = Object.keys(perDay).map(Number).sort((a, b) => a - b);
  let prev = null;
  for (const k of keys) {
    const d = new Date(Math.floor(k / 10000), Math.floor((k % 10000) / 100) - 1, k % 100).getTime();
    run = prev !== null && Math.round((d - prev) / DAY) === 1 ? run + 1 : 1;
    bestStreak = Math.max(bestStreak, run, streak);
    prev = d;
  }
  return {
    totalSec, games: installed.length,
    played: games.filter((g) => (g.playtime || 0) > 0).length,
    sessions: sessions.length, longest, streak, bestStreak,
    favorites: games.filter((g) => g.favorite).length,
    collections: data.collections.length,
    platforms: new Set(installed.map((g) => g.platform)).size,
    custom: games.filter((g) => g.platform === 'custom').length,
    night, early, maxDaySec: Math.max(0, ...Object.values(perDay)),
    daysPlayed: Object.keys(perDay).length,
    captures: (data.captures || []).length,
    customThemes: ((data.settings && data.settings.customThemes) || []).length,
    themeChanged: data.settings && data.settings.themeId && data.settings.themeId !== 'midnight' ? 1 : 0,
    maxGameSec: Math.max(0, ...games.map((g) => g.playtime || 0)),
    weekend: Object.keys(perDay).some((k) => { const n = Number(k); const d = new Date(Math.floor(n / 10000), Math.floor((n % 10000) / 100) - 1, n % 100); return d.getDay() === 6 && perDay[dayKey(d.getTime() + DAY)]; }) ? 1 : 0,
  };
}

const H = 3600;
const A = (id, name, desc, icon, xp, tier, f, target) => ({ id, name, desc, icon, xp, tier, f, target });
const DEFS = [
  // ---- getting started
  A('first-launch', 'First Launch', 'Play your first game from PLAYNEX', 'rocket', 50, 'bronze', (s) => s.sessions, 1),
  A('custom-1', 'Do It Yourself', 'Add a custom executable', 'wrench', 50, 'bronze', (s) => s.custom, 1),
  A('collection-1', 'Organiser', 'Create a collection', 'folder', 50, 'bronze', (s) => s.collections, 1),
  A('photo-1', 'Photographer', 'Take your first screenshot', 'camera', 50, 'bronze', (s) => s.captures, 1),
  A('theme-1', 'Palette Swap', 'Switch to a different theme', 'palette', 50, 'bronze', (s) => s.themeChanged, 1),
  A('sessions-10', 'Settling In', 'Play 10 sessions', 'flag', 75, 'bronze', (s) => s.sessions, 10),
  // ---- playtime
  A('hour-1', 'Warming Up', 'Play for 1 hour in total', 'hourglass', 50, 'bronze', (s) => s.totalSec / H, 1),
  A('hour-10', 'Regular', 'Play for 10 hours in total', 'clock', 100, 'bronze', (s) => s.totalSec / H, 10),
  A('hour-50', 'Dedicated', 'Play for 50 hours in total', 'medal', 200, 'silver', (s) => s.totalSec / H, 50),
  A('hour-100', 'Veteran', 'Play for 100 hours in total', 'shield', 300, 'silver', (s) => s.totalSec / H, 100),
  A('hour-500', 'Legend', 'Play for 500 hours in total', 'crown', 800, 'gold', (s) => s.totalSec / H, 500),
  A('hour-1000', 'Eternal', 'Play for 1,000 hours in total', 'infinity', 1200, 'gold', (s) => s.totalSec / H, 1000),
  // ---- library
  A('games-10', 'Collector', 'Have 10 games in your library', 'book', 100, 'bronze', (s) => s.games, 10),
  A('games-50', 'Hoarder', 'Have 50 games in your library', 'gem', 250, 'silver', (s) => s.games, 50),
  A('games-100', 'Archivist', 'Have 100 games in your library', 'diamond', 600, 'gold', (s) => s.games, 100),
  A('played-5', 'Explorer', 'Play 5 different games', 'compass', 100, 'bronze', (s) => s.played, 5),
  A('played-20', 'Wanderer', 'Play 20 different games', 'map', 250, 'silver', (s) => s.played, 20),
  A('multi-3', 'Multi-platform', 'Own games from 3 different platforms', 'globe', 100, 'bronze', (s) => s.platforms, 3),
  A('fav-5', 'Curator', 'Mark 5 favourites', 'heart', 100, 'bronze', (s) => s.favorites, 5),
  // ---- habits
  A('night-owl', 'Night Owl', 'Start a session between midnight and 5 am', 'moon', 100, 'silver', (s) => s.night, 1),
  A('early-bird', 'Early Bird', 'Start a session between 5 and 8 am', 'sunrise', 100, 'silver', (s) => s.early, 1),
  A('weekend', 'Weekend Warrior', 'Play on both Saturday and Sunday', 'mountain', 100, 'bronze', (s) => s.weekend, 1),
  A('streak-3', 'On a Roll', 'Play 3 days in a row', 'flame', 100, 'bronze', (s) => s.bestStreak, 3),
  A('streak-7', 'Unstoppable', 'Play 7 days in a row', 'calendar', 300, 'silver', (s) => s.bestStreak, 7),
  A('streak-30', 'Creature of Habit', 'Play 30 days in a row', 'sparkle', 900, 'gold', (s) => s.bestStreak, 30),
  A('days-20', 'Regular Visitor', 'Play on 20 different days', 'calendar', 200, 'silver', (s) => s.daysPlayed, 20),
  A('sessions-100', 'Centurion', 'Play 100 sessions', 'target', 400, 'silver', (s) => s.sessions, 100),
  // ---- big sessions
  A('marathon', 'Marathon', 'Play a single session of 3 hours or more', 'timer', 200, 'silver', (s) => s.longest / H, 3),
  A('ultra', 'Ultra Marathon', 'Play a single session of 6 hours or more', 'bolt', 500, 'gold', (s) => s.longest / H, 6),
  A('fullday', 'Full Day', 'Play 8 hours in a single day', 'sun', 300, 'silver', (s) => s.maxDaySec / H, 8),
  A('loyal', 'Loyal Fan', 'Play one game for 25 hours', 'star', 250, 'silver', (s) => s.maxGameSec / H, 25),
  A('devoted', 'Devoted', 'Play one game for 100 hours', 'trophy', 600, 'gold', (s) => s.maxGameSec / H, 100),
  // ---- captures & style
  A('photo-25', 'Shutterbug', 'Take 25 screenshots', 'image', 150, 'silver', (s) => s.captures, 25),
  A('photo-100', 'Paparazzi', 'Take 100 screenshots', 'sparkle', 400, 'gold', (s) => s.captures, 100),
  A('theme-own', 'Designer', 'Create your own theme', 'palette', 100, 'silver', (s) => s.customThemes, 1),
];
// The platinum trophy is awarded for earning every other trophy.
const PLATINUM = { id: 'platinum', name: 'Platinum Player', desc: 'Earn every other trophy', icon: 'trophy', xp: 2000, tier: 'platinum' };

/** Returns [{id,name,desc,icon,xp,tier,cur,target,unlockedAt}] and mutates data.unlocked; also returns newly unlocked defs. */
function evaluate(data) {
  const stats = computeStats(data);
  const fresh = [];
  const list = DEFS.map((d) => {
    const cur = Math.min(d.target, d.f(stats));
    if (cur >= d.target && !data.unlocked[d.id]) { data.unlocked[d.id] = Date.now(); fresh.push(d); }
    return { id: d.id, name: d.name, desc: d.desc, icon: d.icon, xp: d.xp, tier: d.tier, cur: Math.round(cur * 10) / 10, target: d.target, unlockedAt: data.unlocked[d.id] || null };
  });
  const got = list.filter((a) => a.unlockedAt).length;
  if (got >= list.length && !data.unlocked[PLATINUM.id]) { data.unlocked[PLATINUM.id] = Date.now(); fresh.push(PLATINUM); }
  list.push({ ...PLATINUM, cur: got, target: list.length, unlockedAt: data.unlocked[PLATINUM.id] || null });
  return { list, fresh, stats, level: levelInfo(stats, list) };
}

const TITLES = ['Newcomer', 'Rookie', 'Player', 'Challenger', 'Contender', 'Veteran', 'Elite', 'Master', 'Grandmaster', 'Legend'];
function levelInfo(stats, list) {
  const xp = Math.round(stats.totalSec / H * 25 + stats.sessions * 5 + list.filter((a) => a.unlockedAt).reduce((n, a) => n + a.xp, 0));
  const level = Math.floor(Math.sqrt(xp / 100)) + 1;
  const base = 100 * (level - 1) ** 2, next = 100 * level ** 2;
  return { xp, level, base, next, title: TITLES[Math.min(TITLES.length - 1, Math.floor((level - 1) / 2))] };
}

module.exports = { computeStats, evaluate, levelInfo, DEFS, dayKey };
