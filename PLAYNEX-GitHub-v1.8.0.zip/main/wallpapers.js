'use strict';
// Online wallpapers for the screensaver.
//   Wallhaven     official public API (SFW only)                               - reliable
//   Bing          Bing's daily photo feed, UHD                                  - reliable
//   WallpaperCave reads the site's search + wallpaper pages                     - best effort (no API)
//   Wallhalla     reads the site's listing + wallpaper pages                    - best effort (no API)
// Every picture is downloaded once into a local cache and only kept if its real size is at least the chosen
// quality (2K = 2560x1440, 4K = 3840x2160) and it is 16:9. The screensaver then plays from disk.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { pathToFileURL } = require('url');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) PLAYNEX/1.7';
const QUALITY = { '2k': { w: 2560, h: 1440, label: '2K QHD' }, '4k': { w: 3840, h: 2160, label: '4K UHD' } };
const TOPICS = {
  gaming: { label: 'Gaming', q: 'video game', cave: 'gaming', cats: '110', on: true },
  nature: { label: 'Nature', q: 'nature landscape', cave: 'nature', cats: '100', on: true },
  animals: { label: 'Animals', q: 'animal wildlife', cave: 'animals', cats: '100', on: true },
  space: { label: 'Space', q: 'space galaxy', cave: 'space', cats: '100', on: false },
  cars: { label: 'Cars', q: 'supercar', cave: 'cars', cats: '100', on: false },
  cities: { label: 'Cities', q: 'city night skyline', cave: 'city night', cats: '100', on: false },
};
const SOURCES = { wallhaven: 'Wallhaven', bing: 'Bing daily', wallpapercave: 'WallpaperCave', wallhalla: 'Wallhalla' };
const SETTING_KEY = { wallhaven: 'saverWebWallhaven', bing: 'saverWebBing', wallpapercave: 'saverWebCave', wallhalla: 'saverWebHalla' };

const rnd = (n) => Math.floor(Math.random() * n);
const shuffle = (a) => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = rnd(i + 1); [r[i], r[j]] = [r[j], r[i]]; } return r; };
const decode = (t) => String(t || '').replace(/&amp;/g, '&').replace(/&#0?39;|&#x27;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();

/** Width/height from the first bytes of a PNG, JPEG or WebP file (no decoding). */
function imageSize(b) {
  if (!b || b.length < 30) return null;
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), ext: 'png' };
  if (b[0] === 0xff && b[1] === 0xd8) {
    let i = 2;
    while (i + 9 < b.length) {
      if (b[i] !== 0xff) { i++; continue; }
      const m = b[i + 1];
      if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) return { h: b.readUInt16BE(i + 5), w: b.readUInt16BE(i + 7), ext: 'jpg' };
      if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { i += 2; continue; }
      i += 2 + b.readUInt16BE(i + 2);
    }
    return null;
  }
  if (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') {
    const t = b.toString('ascii', 12, 16);
    if (t === 'VP8X') return { w: 1 + b.readUIntLE(24, 3), h: 1 + b.readUIntLE(27, 3), ext: 'webp' };
    if (t === 'VP8 ') return { w: b.readUInt16LE(26) & 0x3fff, h: b.readUInt16LE(28) & 0x3fff, ext: 'webp' };
    if (t === 'VP8L' && b[20] === 0x2f) { const v = b.readUInt32LE(21); return { w: (v & 0x3fff) + 1, h: ((v >> 14) & 0x3fff) + 1, ext: 'webp' }; }
  }
  return null;
}
const is169 = (w, h) => h > 0 && Math.abs(w / h - 16 / 9) < 0.045;
const qualityLabel = (w) => (w >= 7000 ? '8K' : w >= 5000 ? '5K' : w >= 3800 ? '4K UHD' : w >= 2500 ? '2K QHD' : 'Full HD');

/* ------------------------------------------------------------------ sources */
const sources = {
  async wallhaven({ topics, q, get }) {
    const out = [];
    for (const t of topics) {
      const url = `https://wallhaven.cc/api/v1/search?q=${encodeURIComponent(t.q)}&categories=${t.cats}&purity=100&atleast=${q.w}x${q.h}&ratios=16x9&sorting=toplist&topRange=1y&page=${1 + rnd(3)}`;
      const j = await get(url, { json: true });
      out.push(...parseWallhaven(j, t, q));
    }
    return out;
  },
  async bing({ get }) {
    const out = [];
    for (const idx of [0, 8]) {
      const j = await get(`https://www.bing.com/HPImageArchive.aspx?format=js&idx=${idx}&n=8&mkt=en-US`, { json: true });
      out.push(...parseBing(j));
    }
    return out;
  },
  async wallpapercave({ topics, q, get }) {
    const out = [];
    for (const t of topics) {
      const html = await get(`https://wallpapercave.com/search?q=${encodeURIComponent(t.cave + ' ' + (q.w >= 3840 ? '4k' : '2k'))}`);
      const ids = shuffle(parseCaveIds(html)).slice(0, 8);
      const pages = await mapLimit(ids, 4, async (id) => ({ id, html: await get(`https://wallpapercave.com/w/${id}`).catch(() => null) }));
      pages.forEach((p) => out.push(parseCavePage(p.id, p.html, t)));
    }
    return out;
  },
  async wallhalla({ q, get }) {
    const lists = await Promise.all(['best', 'recent', 'random'].map((p) => get(`https://wallhalla.com/${p}`).catch(() => null)));
    const ids = shuffle([...new Set(lists.flatMap(parseHallIds))]).slice(0, 14);
    const pages = await mapLimit(ids, 4, async (id) => ({ id, html: await get(`https://wallhalla.com/wallpaper/${id}`).catch(() => null) }));
    return pages.map((p) => parseHallPage(p.id, p.html)).filter((x) => !x.hint || x.hint.w >= q.w);
  },
};

function parseWallhaven(j, topic, q) {
  return ((j && j.data) || []).map((d) => {
    const [w, h] = String(d.resolution || '').split('x').map(Number);
    return { id: 'wh-' + d.id, source: 'wallhaven', title: topic.label, topic: topic.label, page: d.url, urls: [d.path], hint: { w, h }, credit: 'Wallhaven' };
  }).filter((x) => x.urls[0] && (!x.hint.w || (x.hint.w >= q.w && is169(x.hint.w, x.hint.h))));
}
function parseBing(j) {
  return ((j && j.images) || []).filter((i) => i.urlbase).map((i) => ({
    id: 'bing-' + (i.hsh || i.urlbase), source: 'bing', title: decode(i.title) || 'Bing daily', topic: 'Photography', page: i.copyrightlink || 'https://www.bing.com',
    urls: [`https://www.bing.com${i.urlbase}_UHD.jpg`], hint: null, credit: decode(i.copyright),
  }));
}
function parseCaveIds(html) { return [...new Set([...(String(html || '')).matchAll(/\/(?:w|wp)\/((?:u?wp)\d{5,})/g)].map((m) => m[1]))]; }
function metaOf(html, prop) { const m = String(html || '').match(new RegExp(`<meta[^>]+(?:property|name)=["']${prop}["'][^>]+content=["']([^"']+)["']`, 'i')) || String(html || '').match(new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${prop}["']`, 'i')); return m ? decode(m[1]) : ''; }
function parseCavePage(id, html, topic) {
  const og = metaOf(html, 'og:image'); const title = metaOf(html, 'og:title').replace(/\s*[-|–]\s*wallpapercave.*$/i, '').replace(/\s+wallpapers?$/i, '').trim();
  const urls = [og, `https://wallpapercave.com/wp/${id}.jpg`, `https://wallpapercave.com/wp/${id}.webp`].filter(Boolean);
  return { id: 'wc-' + id, source: 'wallpapercave', title: title || topic.label, topic: topic.label, page: `https://wallpapercave.com/w/${id}`, urls: [...new Set(urls)], hint: null, credit: 'WallpaperCave' };
}
function parseHallIds(html) { return [...new Set([...(String(html || '')).matchAll(/\/wallpaper\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/g)].map((m) => m[1]))]; }
function parseHallPage(id, html) {
  const base = `https://wallhalla.com/storage/wallpapers/variants/${id}/1`;
  const og = metaOf(html, 'og:image');
  const title = (metaOf(html, 'og:title') || decode((String(html || '').match(/<title>([^<]*)<\/title>/i) || [])[1])).replace(/\s*[-|–]\s*wallhalla.*$/i, '').trim();
  const res = String(html || '').match(/(\d{4})\s*[×x]\s*(\d{4})/);
  return { id: 'wh2-' + id, source: 'wallhalla', title: title || 'Wallhalla', topic: 'Wallhalla', page: `https://wallhalla.com/wallpaper/${id}`, hint: res ? { w: +res[1], h: +res[2] } : null,
    urls: [...new Set([`${base}/3840.webp`, `${base}/2560.webp`, og, `${base}/1920.webp`].filter(Boolean))], credit: 'Wallhalla' };
}

async function mapLimit(list, n, fn) {
  const out = new Array(list.length); let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, list.length) }, async () => { while (i < list.length) { const k = i++; out[k] = await fn(list[k], k); } }));
  return out;
}

/* --------------------------------------------------------------- on-demand cache */
// Nothing is downloaded in bulk. The catalog is only a list of links; a picture is fetched when the screensaver asks
// for the next one.
//   Keep OFF (default): at most KEEP pictures sit in a temporary folder, which is deleted when the app closes.
//   Keep ON:            pictures are saved (up to a limit) so the screensaver also works offline.
const KEEP = 4;
class Wallpapers {
  constructor({ dir, persistDir, getSettings, onChange, fetchImpl }) {
    this.dir = dir; this.persistDir = persistDir || path.join(dir, '..', 'playnex-wallpapers-kept');
    this.getSettings = getSettings || (() => ({})); this.onChange = onChange || (() => {}); this.fetch = fetchImpl || ((...a) => fetch(...a));
    this.busy = false; this.diag = {}; this.catalog = []; this.cursor = 0; this.catalogAt = 0; this.files = []; this.saved = []; this.shown = 0; this.loading = null; this.nexting = null; this.last = null;
    this.rmDir(this.dir);                                   // temporary pictures never survive a restart
    if (this.keepOn()) this.loadSaved(); else this.rmDir(this.persistDir);
  }

  /** The folder pictures currently go to (saved folder when keeping, temporary folder otherwise). */
  folder() { return this.keepOn() ? this.persistDir : this.dir; }
  keepOn() { return this.getSettings().saverWebKeep === true; }
  cap() { return Math.max(10, Math.min(120, Number(this.getSettings().saverWebCap) || 40)); }
  quality() { return QUALITY[this.getSettings().saverWebQuality] || QUALITY['2k']; }
  enabledSources() { const s = this.getSettings(); return Object.keys(SOURCES).filter((k) => s[SETTING_KEY[k]] !== false); }
  enabledTopics() {
    const s = this.getSettings(); const on = Object.entries(TOPICS).filter(([k, t]) => { const v = s['saverCat' + k[0].toUpperCase() + k.slice(1)]; return v == null ? t.on : v; }).map(([, t]) => t);
    return on.length ? on : [TOPICS.gaming, TOPICS.nature, TOPICS.animals];
  }
  state() { return { busy: this.busy, diag: this.diag, found: this.catalog.length, shown: this.shown, active: this.files.length, saved: this.saved.length, fetchedAt: this.catalogAt, folder: this.folder(), keep: this.keepOn() }; }
  stale() { return !this.catalog.length || Date.now() - this.catalogAt > 6 * 3600e3; }
  rmDir(d) { try { fs.rmSync(d, { recursive: true, force: true }); } catch (_) { /* ignore */ } }

  loadSaved() {
    try {
      const idx = JSON.parse(fs.readFileSync(path.join(this.persistDir, 'index.json'), 'utf8'));
      this.saved = (idx.items || []).filter((r) => fs.existsSync(path.join(this.persistDir, r.file))).map((r) => ({ ...r, dir: this.persistDir }));
    } catch (_) { this.saved = []; }
  }
  saveIndex() { try { fs.mkdirSync(this.persistDir, { recursive: true }); fs.writeFileSync(path.join(this.persistDir, 'index.json'), JSON.stringify({ items: this.saved.map(({ dir, ...r }) => r) })); } catch (_) { /* ignore */ } }

  async get(url, { json = false, buf = false, timeout = 20000 } = {}) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
    try {
      const origin = new URL(url).origin;
      const r = await this.fetch(url, { headers: { 'User-Agent': UA, Accept: json ? 'application/json' : buf ? 'image/*,*/*' : 'text/html,*/*', Referer: origin + '/' }, signal: ctl.signal });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      if (json) return await r.json();
      if (buf) { const len = Number(r.headers.get('content-length') || 0); if (len > 40e6) throw new Error('too large'); return Buffer.from(await r.arrayBuffer()); }
      return await r.text();
    } finally { clearTimeout(t); }
  }

  /** Ask every enabled source what it has. Only small text/JSON requests - no pictures are downloaded here. */
  loadCatalog(force = false) {
    if (this.loading) return this.loading;
    if (!force && !this.stale()) return Promise.resolve(this.state());
    this.loading = (async () => {
      this.busy = true; this.diag = {}; this.onChange();
      try {
        const q = this.quality(), topics = this.enabledTopics(), srcKeys = this.enabledSources();
        const ctx = { topics, q, get: (u, o) => this.get(u, o) };
        const lists = await Promise.all(srcKeys.map(async (k) => {
          try { const r = await sources[k](ctx); this.diag[k] = { found: r.length, shown: 0, failed: 0 }; return r; }
          catch (e) { this.diag[k] = { found: 0, shown: 0, failed: 0, error: String(e && e.message || e).slice(0, 80) }; return []; }
          finally { this.onChange(); }
        }));
        const fresh = lists.map((l) => shuffle(l)); const queue = [];
        for (let n = 0; fresh.some((l) => n < l.length); n++) fresh.forEach((l) => { if (n < l.length) queue.push(l[n]); });   // round-robin across sources
        this.catalog = queue; this.cursor = 0; this.catalogAt = Date.now();
      } finally { this.busy = false; this.loading = null; this.onChange(); }
      return this.state();
    })();
    return this.loading;
  }

  /** Pictures already on this PC that meet the chosen quality. */
  cachedPool() { const q = this.quality(); return [...this.saved, ...this.files].filter((r) => r.w >= q.w && fs.existsSync(path.join(r.dir, r.file))); }
  fromCache() {
    const pool = this.cachedPool(); if (!pool.length) return null;
    const others = pool.filter((r) => r.id !== this.last); const r = (others.length ? others : pool)[rnd((others.length ? others : pool).length)];
    return r;
  }

  /** Give the screensaver ONE more picture (it calls this just before it needs it). Null if nothing usable. */
  next() {
    if (this.nexting) return this.nexting;
    this.nexting = (async () => {
      try {
        const keep = this.keepOn();
        await this.loadCatalog(false).catch(() => {});
        const q = this.quality(); let tries = 0, scanned = 0;
        // Rolling shelf: always fetch a NEW picture; once the shelf is full, the oldest saved one is deleted (see store()).
        while (tries < 5 && scanned < this.catalog.length) {
          if (this.cursor >= this.catalog.length) { this.cursor = 0; this.catalog = shuffle(this.catalog); }
          const item = this.catalog[this.cursor++]; scanned++;
          if ([...this.saved, ...this.files].some((f) => f.id === item.id)) continue;   // already on this PC: look for a fresh one
          const d = this.diag[item.source]; tries++;
          const rec = await this.download(item, q, keep ? this.persistDir : this.dir);
          if (!rec) { if (d) d.failed++; this.onChange(); continue; }
          this.store(rec, keep);
          if (d) d.shown++;
          return this.serve(rec);
        }
        const c = this.fromCache();          // offline, or every source failed: play what is already on this PC
        return c ? this.serve(c) : null;
      } catch (_) { return null; }
    })();
    const p = this.nexting; const clear = () => { if (this.nexting === p) this.nexting = null; };
    p.then(clear, clear);
    return p;
  }
  serve(rec) { this.last = rec.id; this.shown++; this.onChange(); return this.view(rec); }

  store(rec, keep) {
    if (keep) {
      this.saved.push(rec);
      while (this.saved.length > this.cap()) { const old = this.saved.shift(); fs.promises.unlink(path.join(old.dir, old.file)).catch(() => {}); }
      this.saveIndex();
    } else {
      this.files.push(rec);
      while (this.files.length > KEEP) { const old = this.files.shift(); fs.promises.unlink(path.join(old.dir, old.file)).catch(() => {}); }
    }
  }

  view(i) {
    return { id: i.id, url: pathToFileURL(path.join(i.dir, i.file)).href, title: i.title, topic: i.topic, source: i.source, sourceName: SOURCES[i.source] || i.source, w: i.w, h: i.h, quality: qualityLabel(i.w), page: i.page, credit: i.credit };
  }

  async download(item, q, dir) {
    for (const url of item.urls) {
      try {
        const buf = await this.get(url, { buf: true, timeout: 40000 });
        const sz = imageSize(buf);
        if (!sz || sz.w < q.w || !is169(sz.w, sz.h)) continue;
        fs.mkdirSync(dir, { recursive: true });
        const file = `${item.source}-${crypto.createHash('md5').update(item.id).digest('hex').slice(0, 12)}.${sz.ext}`;
        await fs.promises.writeFile(path.join(dir, file), buf);
        return { id: item.id, file, dir, source: item.source, title: item.title, topic: item.topic, page: item.page, credit: item.credit, w: sz.w, h: sz.h };
      } catch (_) { /* try the next candidate */ }
    }
    return null;
  }

  /** On exit: temporary pictures always go; saved ones go too unless "keep" is on. */
  onQuit() { this.files = []; this.rmDir(this.dir); if (!this.keepOn()) { this.saved = []; this.rmDir(this.persistDir); } }
  /** The Delete button: everything, kept or not. */
  deleteAll() { this.files = []; this.saved = []; this.rmDir(this.dir); this.rmDir(this.persistDir); this.last = null; this.onChange(); }
  /** Forget the list of links (sources/topics/quality changed). Pictures on disk are left alone. */
  resetCatalog() { this.catalog = []; this.cursor = 0; this.catalogAt = 0; this.diag = {}; this.onChange(); }
}

module.exports = { Wallpapers, imageSize, is169, qualityLabel, parseWallhaven, parseBing, parseCaveIds, parseCavePage, parseHallIds, parseHallPage, TOPICS, SOURCES, QUALITY };
