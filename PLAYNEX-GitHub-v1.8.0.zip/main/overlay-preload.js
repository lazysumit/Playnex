'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const INVOKE = new Set(['overlay:state', 'overlay:close', 'overlay:action']);
const EVENTS = new Set(['overlay:open', 'overlay:close']);
contextBridge.exposeInMainWorld('ov', {
  invoke: (ch, ...a) => (INVOKE.has(ch) ? ipcRenderer.invoke(ch, ...a) : Promise.reject(new Error('blocked channel ' + ch))),
  on: (ch, cb) => { if (!EVENTS.has(ch)) return () => {}; const h = () => cb(); ipcRenderer.on(ch, h); return () => ipcRenderer.removeListener(ch, h); },
});
