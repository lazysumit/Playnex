'use strict';
/**
 * In-game overlay: a transparent, always-on-top window opened with a global shortcut.
 * It works over games running windowed or borderless. Games in exclusive full-screen draw above normal windows, so the overlay
 * can't appear on top of those (use borderless / windowed-fullscreen in the game).
 */
const { BrowserWindow, screen } = require('electron');
const { execFile } = require('child_process');
const os = require('os');
const path = require('path');

class Overlay {
  constructor({ getData, onClose }) { this.getData = getData; this.onClose = onClose; this.win = null; this.cpuPrev = null; this.accent = '#3d8bff'; }

  get visible() { return !!(this.win && !this.win.isDestroyed() && this.win.isVisible()); }

  _create() {
    this.win = new BrowserWindow({
      show: false, frame: false, transparent: true, resizable: false, movable: false, minimizable: false, maximizable: false, fullscreenable: false,
      skipTaskbar: true, hasShadow: false, focusable: true, alwaysOnTop: true, backgroundColor: '#00000000', title: 'PLAYNEX Overlay',
      webPreferences: { preload: path.join(__dirname, 'overlay-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false },
    });
    this.win.setAlwaysOnTop(true, 'screen-saver');
    this.win.setVisibleOnAllWorkspaces && this.win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    this.win.loadFile(path.join(__dirname, '..', 'renderer', 'overlay.html'));
    this.win.on('blur', () => { /* stays open until dismissed so a stray click on the game doesn't lose the panel */ });
    this.win.on('closed', () => { this.win = null; });
  }

  toggle() { return this.visible ? this.hide() : this.show(); }

  show() {
    if (!this.win || this.win.isDestroyed()) this._create();
    // Cover the monitor the mouse is on (that's almost always where the game is).
    const d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
    this.win.setBounds(d.bounds);
    this.win.webContents.send('overlay:open');
    this.win.setAlwaysOnTop(true, 'screen-saver');
    this.win.show(); this.win.focus();
    this._gpuStart();
  }

  /** GPU load is sampled in the background while the overlay is open (nvidia-smi if present, else Windows' GPU Engine counters). */
  _gpuStart() {
    if (this.gpuTimer || process.platform !== 'win32') return;
    const run = (cmd, args) => new Promise((res) => execFile(cmd, args, { windowsHide: true, timeout: 6000 }, (e, out) => res(e ? null : String(out))));
    const sample = async () => {
      if (this.gpuBusy) return; this.gpuBusy = true;
      try {
        let v = null;
        if (this.gpuSrc !== 'counter') {
          const o = await run('nvidia-smi', ['--query-gpu=utilization.gpu', '--format=csv,noheader,nounits']);
          const n = o && o.split(/\r?\n/).map((x) => parseInt(x, 10)).filter((x) => !isNaN(x));
          if (n && n.length) { v = Math.max(...n); this.gpuSrc = 'smi'; } else if (this.gpuSrc == null) this.gpuSrc = 'counter';
        }
        if (v == null) {
          const o = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
            "try{$s=(Get-Counter '\\GPU Engine(*engtype_3D)\\Utilization Percentage' -ErrorAction Stop).CounterSamples|Measure-Object CookedValue -Sum;[math]::Round($s.Sum)}catch{''}"]);
          const n = o && parseInt(o.trim(), 10); if (n != null && !isNaN(n)) v = Math.min(100, Math.max(0, n));
        }
        this.gpu = v;
      } finally { this.gpuBusy = false; }
    };
    sample(); this.gpuTimer = setInterval(sample, 2500);
  }
  /** Keep GPU sampling alive for a few seconds (the phone remote asks for it while it is open). */
  gpuKeepAlive() { this._gpuStart(); clearTimeout(this._ka); this._ka = setTimeout(() => { if (!this.visible) this._gpuStop(); }, 12000); if (this._ka.unref) this._ka.unref(); }
  _gpuStop() { clearInterval(this.gpuTimer); this.gpuTimer = null; }

  hide() {
    if (this.win && !this.win.isDestroyed()) { this.win.webContents.send('overlay:close'); this.win.hide(); }
    this._gpuStop();
    if (this.onClose) this.onClose();
  }

  destroy() { if (this.win && !this.win.isDestroyed()) this.win.destroy(); this.win = null; }

  /** CPU % since the last call, and memory %. */
  sys() {
    const cpus = os.cpus(); let idle = 0, total = 0;
    for (const c of cpus) { for (const t of Object.values(c.times)) total += t; idle += c.times.idle; }
    let cpu = null;
    if (this.cpuPrev) { const dt = total - this.cpuPrev.total, di = idle - this.cpuPrev.idle; cpu = dt > 0 ? Math.round((1 - di / dt) * 100) : null; }
    this.cpuPrev = { total, idle };
    const mem = Math.round((1 - os.freemem() / os.totalmem()) * 100);
    return { cpu, mem, gpu: this.gpu == null ? null : this.gpu };
  }
}

/** System volume via the Windows media keys (works for whatever device is the default output). */
function volume(action) {
  if (process.platform !== 'win32') return false;
  const code = { up: 0xAF, down: 0xAE, mute: 0xAD }[action]; if (!code) return false;
  const n = action === 'mute' ? 1 : 3;
  const ps = `Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern void keybd_event(byte k, byte s, int f, int e);' -Name K -Namespace W; 1..${n} | ForEach-Object { [W.K]::keybd_event(${code}, 0, 0, 0); [W.K]::keybd_event(${code}, 0, 2, 0) }`;
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true, timeout: 8000 }, () => {});
  return true;
}

module.exports = { Overlay, volume };
