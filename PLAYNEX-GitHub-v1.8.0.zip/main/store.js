'use strict';
// Tiny JSON persistence layer (no native modules => installs cleanly on any Windows PC).
const fs = require('fs');
const path = require('path');

const DEFAULTS = {
  games: {},
  collections: [],
  sessions: [],
  captures: [],
  notifications: [],
  unlocked: {},
  profile: { name: 'Player One', avatar: null, createdAt: Date.now() },
  meta: { firstRun: true, scans: 0 },
  settings: {
    themeMode: 'dark', // dark | light | system
    themeId: 'midnight',
    customThemes: [], // [{id,name,mode,accent,bg}]
    wallpaper: 'dynamic', // dynamic | custom | none
    customBackground: null,
    bgDim: 0.5,
    bgBlur: 0,
    platforms: {
      steam: true, epic: true, xbox: true, ubisoft: true, ea: true,
      battlenet: true, gog: true, riot: true, rockstar: true,
    },
    scanFolders: [],
    scanOnStartup: true,
    steamGridDbKey: '',
    rawgKey: '',
    steamApiKey: '',
    steamId: '',
    launchAtLogin: false,
    startMinimized: false,
    closeToTray: true,
    notifications: true,
    controller: true,
    showcaseEnabled: true,
    showcaseDelay: 10,
    showcaseSlide: 8,
    saverEnabled: true,
    saverDelay: 60,
    saverSlide: 10,
    lightTone: 40,
    musicEnabled: true,
    musicBrowser: true,
    overlayEnabled: true,
    remoteEnabled: false,
    remotePort: 47600,
    remotePower: true,
    powerForce: false,
    overlayKey: 'Ctrl+Shift+G',
    musicArtLookup: true,
    musicApps: [],
    saverClock: true,
    saverClockSize: 96,
    saverDate: true,
    saverClockPos: 'top-right',
    saverClockFmt: 'auto',
    saverSource: 'games',
    saverWebQuality: '2k',
    showBrand: false,
    saverWebKeep: false,
    saverWebCap: 40,
    saverWebCaption: true,
    saverWebWallhaven: true,
    saverWebBing: true,
    saverWebCave: true,
    saverWebHalla: true,
    saverCatGaming: true,
    saverCatNature: true,
    saverCatAnimals: true,
    saverCatSpace: false,
    saverCatCars: false,
    saverCatCities: false,
    saverMusic: true,
    saverMusicPos: 'bottom-right',
    saverMusicSize: 100,
    glassLevel: 60,
    captureEnabled: true,
    captureKey: 'F11',
    captureSound: true,
    tileSize: 170,
    libView: 'grid',
    libSort: 'name',
    libDir: 'asc',
  },
};

class Store {
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, 'library.json');
    this.data = JSON.parse(JSON.stringify(DEFAULTS));
    this._t = null;
    fs.mkdirSync(dir, { recursive: true });
    this._load();
  }

  _load() {
    let raw;
    try { raw = fs.readFileSync(this.file, 'utf8'); } catch (e) { return; }
    try {
      const j = JSON.parse(raw);
      for (const k of Object.keys(DEFAULTS)) {
        if (j[k] === undefined) continue;
        if (k === 'settings') {
          this.data.settings = { ...DEFAULTS.settings, ...j.settings,
            platforms: { ...DEFAULTS.settings.platforms, ...(j.settings.platforms || {}) } };
        } else if (k === 'profile' || k === 'meta') this.data[k] = { ...DEFAULTS[k], ...j[k] };
        else this.data[k] = j[k];
      }
    } catch (e) {
      // Corrupt file: keep a copy so nothing is silently lost, then start fresh.
      try { fs.copyFileSync(this.file, this.file + '.corrupt-' + Date.now()); } catch (_) { /* ignore */ }
    }
  }

  save() {
    clearTimeout(this._t);
    this._t = setTimeout(() => this.flush(), 400);
  }

  flush() {
    clearTimeout(this._t);
    try {
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.data));
      fs.renameSync(tmp, this.file);
    } catch (e) { console.error('store save failed', e); }
  }
}

module.exports = { Store, DEFAULTS };
