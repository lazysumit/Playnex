'use strict';
// Automatic game identification, artwork and metadata.
// Keyless sources: Steam store search + appdetails + Steam CDN (works for non-Steam games too, by title match).
// Optional: SteamGridDB (API key in Settings) for better covers / banners / logos / icons.
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');

const UA = 'PLAYNEX/1.0 (personal desktop app)';
const CDN = (id, f) => [
  `https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/${id}/${f}`,
  `https://cdn.cloudflare.steamstatic.com/steam/apps/${id}/${f}`,
  `https://cdn.akamai.steamstatic.com/steam/apps/${id}/${f}`,
];

async function getJson(url, headers = {}, timeout = 12000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(url, { headers: { 'User-Agent': UA, ...headers }, signal: ctl.signal });
    if (!r.ok) return null;
    return await r.json();
  } catch (_) { return null; } finally { clearTimeout(t); }
}

function norm(s) {
  return String(s || '').toLowerCase().replace(/[™®©]/g, '').replace(/&/g, ' and ')
    .replace(/\b(the|edition|definitive|complete|game of the year|goty|remastered|deluxe|standard|ultimate|enhanced|digital|pc)\b/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ').trim();
}
function bigrams(s) { const a = new Set(); for (let i = 0; i < s.length - 1; i++) a.add(s.slice(i, i + 2)); return a; }
function similarity(a, b) {
  a = norm(a); b = norm(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return 0.88;
  const A = bigrams(a), B = bigrams(b);
  let n = 0; for (const x of A) if (B.has(x)) n++;
  return (2 * n) / (A.size + B.size || 1);
}

async function steamSearch(term) {
  const j = await getJson(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(term)}&l=english&cc=us`);
  return ((j && j.items) || []).map((i) => ({ appId: String(i.id), name: i.name, score: similarity(term, i.name), image: i.tiny_image }));
}

async function steamDetails(appId) {
  const j = await getJson(`https://store.steampowered.com/api/appdetails?appids=${appId}&l=english`);
  const d = j && j[appId] && j[appId].success ? j[appId].data : null;
  return d;
}

class Metadata {
  constructor({ artDir, getSettings, getIcon }) {
    this.artDir = artDir;
    this.getSettings = getSettings;
    this.getIcon = getIcon || (async () => null);
  }

  dirFor(id) { const d = path.join(this.artDir, id.replace(/[^a-z0-9_-]/gi, '_')); fs.mkdirSync(d, { recursive: true }); return d; }

  /** Download (or copy) the first working candidate into the game's art folder. Returns a file:// URL or null. */
  async fetchArt(id, kind, candidates) {
    for (const c of candidates.filter(Boolean)) {
      try {
        if (!/^https?:/i.test(c)) {
          if (!fs.existsSync(c)) continue;
          const dest = path.join(this.dirFor(id), kind + (path.extname(c) || '.jpg'));
          fs.copyFileSync(c, dest);
          return pathToFileURL(dest).href + '?v=' + Date.now();
        }
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), 15000);
        const r = await fetch(c, { headers: { 'User-Agent': UA }, signal: ctl.signal }).finally(() => clearTimeout(t));
        if (!r.ok) continue;
        const buf = Buffer.from(await r.arrayBuffer());
        if (buf.length < 800) continue;
        const ct = r.headers.get('content-type') || '';
        const ext = /png/.test(ct) ? '.png' : /webp/.test(ct) ? '.webp' : /gif/.test(ct) ? '.gif' : '.jpg';
        const dest = path.join(this.dirFor(id), kind + ext);
        fs.writeFileSync(dest, buf);
        return pathToFileURL(dest).href + '?v=' + Date.now();
      } catch (_) { /* try next */ }
    }
    return null;
  }

  localSteamArt(game) {
    const root = game.extra && game.extra.steamRoot;
    if (!root || !game.steamAppId) return {};
    const base = path.join(root, 'appcache', 'librarycache');
    const found = {};
    const want = { cover: 'library_600x900.jpg', banner: 'library_hero.jpg', logo: 'logo.png', header: 'header.jpg' };
    const legacy = (f) => path.join(base, `${game.steamAppId}_${f}`);
    const walk = (d, depth, name) => {
      try {
        for (const e of fs.readdirSync(d, { withFileTypes: true })) {
          const p = path.join(d, e.name);
          if (e.isFile() && e.name === name) return p;
          if (e.isDirectory() && depth < 2) { const r = walk(p, depth + 1, name); if (r) return r; }
        }
      } catch (_) { /* ignore */ }
      return null;
    };
    for (const [k, f] of Object.entries(want)) {
      const lp = legacy(f);
      found[k] = fs.existsSync(lp) ? lp : walk(path.join(base, String(game.steamAppId)), 0, f);
    }
    return found;
  }

  /** Candidate matches for a manual "identify" dialog. */
  async matches(title) { return (await steamSearch(title)).slice(0, 8); }

  async sgdb(title, key) {
    const H = { Authorization: `Bearer ${key}` };
    const s = await getJson(`https://www.steamgriddb.com/api/v2/search/autocomplete/${encodeURIComponent(title)}`, H);
    const hit = s && s.data && s.data.find((g) => similarity(title, g.name) > 0.6);
    if (!hit) return {};
    const q = async (p) => { const j = await getJson(`https://www.steamgriddb.com/api/v2/${p}`, H); return j && j.data && j.data[0] ? j.data[0].url : null; };
    const [cover, banner, logo, icon] = await Promise.all([
      q(`grids/game/${hit.id}?dimensions=600x900&types=static`), q(`heroes/game/${hit.id}?types=static`),
      q(`logos/game/${hit.id}?types=static`), q(`icons/game/${hit.id}?types=static`),
    ]);
    return { cover, banner, logo, icon, name: hit.name };
  }

  /**
   * Identify a game and download its artwork + metadata. Returns a patch to merge into the game.
   * opts.steamAppId forces a specific match; opts.force re-downloads even if already present.
   */
  async identify(game, opts = {}) {
    const settings = this.getSettings();
    const patch = { art: { ...(game.art || {}) }, meta: { ...(game.meta || {}) }, metaFetched: Date.now() };
    let appId = opts.steamAppId || game.steamAppId || null;
    let matchName = null;

    if (!appId) {
      const results = await steamSearch(game.title);
      const best = results.sort((a, b) => b.score - a.score)[0];
      if (best && best.score >= 0.72) { appId = best.appId; matchName = best.name; }
    }
    if (appId) patch.steamAppId = appId;

    const details = appId ? await steamDetails(appId) : null;
    if (details) {
      patch.meta = {
        description: details.short_description || '',
        about: (details.about_the_game || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 1500),
        developers: details.developers || [], publishers: details.publishers || [],
        genres: (details.genres || []).map((g) => g.description),
        releaseDate: details.release_date && details.release_date.date || '',
        metacritic: details.metacritic ? details.metacritic.score : null, metacriticUrl: details.metacritic ? details.metacritic.url || '' : '',
        website: details.website || '', matchedName: matchName || details.name,
        categories: (details.categories || []).slice(0, 8).map((c) => c.description),
      };
    }

    const sgdb = settings.steamGridDbKey ? await this.sgdb(matchName || game.title, settings.steamGridDbKey) : {};
    const local = this.localSteamArt(game);
    const has = (k) => patch.art[k] && !opts.force;
    const id = game.id;

    const jobs = [];
    const job = (k, cands) => { if (!has(k)) jobs.push(this.fetchArt(id, k, cands).then((u) => { if (u) patch.art[k] = u; })); };
    const steam = appId ? (f) => CDN(appId, f) : () => [];
    job('cover', [local.cover, sgdb.cover, ...steam('library_600x900_2x.jpg'), ...steam('library_600x900.jpg'), ...steam('header.jpg'), details && details.header_image]);
    job('banner', [local.banner, sgdb.banner, ...steam('library_hero.jpg'), details && details.background_raw, ...steam('page_bg_generated_v6b.jpg'),
      details && details.screenshots && details.screenshots[0] && details.screenshots[0].path_full]);
    job('logo', [local.logo, sgdb.logo, ...steam('logo.png')]);
    job('header', [local.header, ...steam('header.jpg'), details && details.header_image]);
    if (sgdb.icon) job('icon', [sgdb.icon]);
    await Promise.all(jobs);

    // Icon from the executable when nothing better exists.
    if (!patch.art.icon && game.exe) {
      try {
        const buf = await this.getIcon(game.exe);
        if (buf) { const dest = path.join(this.dirFor(id), 'icon.png'); fs.writeFileSync(dest, buf); patch.art.icon = pathToFileURL(dest).href + '?v=' + Date.now(); }
      } catch (_) { /* ignore */ }
    }

    // Screenshots (keep remote URLs for a lighter cache; download first 3 for offline use).
    if (details && details.screenshots && (!patch.art.screenshots || opts.force)) {
      const shots = details.screenshots.slice(0, 10);
      patch.art.screenshots = shots.map((s) => s.path_full);
      patch.art.thumbs = shots.map((s) => s.path_thumbnail);
    }
    return patch;
  }
}

module.exports = { Metadata, similarity, norm, steamSearch };
