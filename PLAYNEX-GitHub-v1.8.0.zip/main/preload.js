'use strict';
const { contextBridge, ipcRenderer } = require('electron');

const INVOKE = new Set([
  'state:get', 'library:scan', 'library:scanFolder', 'library:removeFolder', 'library:addCustom', 'library:refreshAll',
  'dialog:pickExe', 'dialog:pickImage',
  'game:launch', 'game:update', 'game:remove', 'game:refreshMeta', 'game:matches', 'game:applyMatch',
  'game:openFolder', 'game:setArt', 'game:steamAchievements', 'game:ratings', 'wall:next', 'wall:check', 'wall:clear', 'wall:open', 'remote:pair', 'remote:cancelPair', 'remote:revoke', 'remote:revokeAll', 'power:run', 'power:cancel', 'ratings:search',
  'collection:save', 'collection:delete', 'collection:toggleGame',
  'settings:set', 'settings:setBackground', 'profile:set', 'profile:setAvatar',
  'notifications:read', 'notifications:clear',
  'app:fullscreen', 'app:screensaver', 'app:idle', 'ui:accent', 'overlay:toggle', 'music:control', 'music:detect', 'music:launch', 'music:add', 'music:rename', 'music:remove', 'capture:take', 'capture:show', 'capture:delete', 'capture:openFolder', 'app:openDataDir', 'app:exportData', 'app:quit',
  'win:minimize', 'win:maximize', 'win:close',
]);
const EVENTS = new Set(['state:patch', 'toast', 'scan:progress', 'fullscreen', 'navigate', 'capture:flash']);

contextBridge.exposeInMainWorld('api', {
  invoke: (ch, ...a) => (INVOKE.has(ch) ? ipcRenderer.invoke(ch, ...a) : Promise.reject(new Error('blocked channel ' + ch))),
  on: (ch, cb) => {
    if (!EVENTS.has(ch)) return () => {};
    const h = (_e, ...a) => cb(...a);
    ipcRenderer.on(ch, h);
    return () => ipcRenderer.removeListener(ch, h);
  },
  platform: process.platform,
});
