'use strict';
// Phone remote: a small web server that lets a paired phone see what is running, take a screenshot, control music,
// quit the game and shut down / restart the PC. It is OFF unless the user turns it on, needs a one-time pairing code,
// and every request must carry a secret token. No third-party code and no Electron imports: it is fully testable.
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { EventEmitter } = require('events');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml' };
const PAIR_TTL = 3 * 60 * 1000;          // a pairing code works for 3 minutes
const MAX_BODY = 4096;
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const safeEq = (a, b) => { const x = sha(a), y = sha(b); return crypto.timingSafeEqual(x, y); };

class Remote extends EventEmitter {
  /**
   * deps: { dir, staticDir, status():Promise<object>|object, actions:{screenshot,music,quitGame,power,captureFile,cover}, fetchImpl }
   */
  constructor(deps) {
    super();
    this.d = deps; this.server = null; this.port = 0; this.error = '';
    this.file = path.join(deps.dir, 'remote.json');
    this.devices = []; this.pairing = null; this.pairFails = []; this.lockUntil = 0; this.ipFails = new Map(); this.coverCache = new Map(); this.saveTimer = null;
    this._load();
  }

  /* ------------------------------------------------------------------ paired phones */
  _load() { try { const j = JSON.parse(fs.readFileSync(this.file, 'utf8')); this.devices = Array.isArray(j.devices) ? j.devices.filter((x) => x && x.id && x.hash) : []; } catch (_) { this.devices = []; } }
  _save() { clearTimeout(this.saveTimer); this.saveTimer = null; try { fs.mkdirSync(this.d.dir, { recursive: true }); fs.writeFileSync(this.file, JSON.stringify({ devices: this.devices })); } catch (_) { /* ignore */ } }
  _saveSoon() { if (!this.saveTimer) { this.saveTimer = setTimeout(() => this._save(), 30000); if (this.saveTimer.unref) this.saveTimer.unref(); } }
  publicDevices() { return this.devices.map((x) => ({ id: x.id, name: x.name, created: x.created, lastSeen: x.lastSeen || 0 })); }
  revoke(id) { const n = this.devices.length; this.devices = this.devices.filter((x) => x.id !== id); if (this.devices.length !== n) { this._save(); this.emit('change'); } return true; }
  revokeAll() { this.devices = []; this._save(); this.emit('change'); return true; }

  startPairing() {
    if (Date.now() < this.lockUntil) return null;
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    this.pairing = { code, expires: Date.now() + PAIR_TTL };
    clearTimeout(this.pairTimer); this.pairTimer = setTimeout(() => { this.pairing = null; this.emit('change'); }, PAIR_TTL + 200); if (this.pairTimer.unref) this.pairTimer.unref();
    this.emit('change');
    return { code, expires: this.pairing.expires };
  }
  cancelPairing() { this.pairing = null; clearTimeout(this.pairTimer); this.emit('change'); return true; }

  _pair(body) {
    const now = Date.now();
    if (now < this.lockUntil) return { code: 429, body: { error: 'Too many wrong codes. Try again in a few minutes.' } };
    if (!this.pairing || now > this.pairing.expires) return { code: 400, body: { error: 'No pairing is open. On the PC, open Settings → Remote and press "Pair a phone".' } };
    const code = String((body && body.code) || '').replace(/\D/g, '');
    if (code.length !== 6 || !safeEq(code, this.pairing.code)) {
      this.pairFails = this.pairFails.filter((t) => now - t < 10 * 60 * 1000); this.pairFails.push(now);
      if (this.pairFails.length >= 5) { this.pairing = null; this.pairFails = []; this.lockUntil = now + 5 * 60 * 1000; this.emit('change'); return { code: 429, body: { error: 'Too many wrong codes. Pairing is locked for 5 minutes.' } }; }
      return { code: 403, body: { error: 'That code is not right.' } };
    }
    const token = crypto.randomBytes(32).toString('hex');
    const name = String((body && body.name) || 'Phone').replace(/[^\w .\-+()]/g, '').trim().slice(0, 40) || 'Phone';
    this.devices.push({ id: crypto.randomBytes(6).toString('hex'), name, hash: sha(token).toString('hex'), created: now, lastSeen: now });
    this.pairing = null; this.pairFails = []; this._save(); this.emit('change');
    return { code: 200, body: { token } };
  }

  _auth(req) {
    const h = String(req.headers.authorization || ''); const m = /^Bearer ([0-9a-f]{64})$/i.exec(h); if (!m) return null;
    const want = sha(m[1]).toString('hex'); let hit = null;
    for (const d of this.devices) { if (d.hash.length === want.length && crypto.timingSafeEqual(Buffer.from(d.hash), Buffer.from(want))) hit = d; }
    if (hit) { hit.lastSeen = Date.now(); this._saveSoon(); }
    return hit;
  }

  /* ------------------------------------------------------------------ server */
  addresses() {
    const out = [];
    for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push(a.address);
    return out.sort((a, b) => (a.startsWith('192.168.') ? 0 : a.startsWith('10.') ? 1 : 2) - (b.startsWith('192.168.') ? 0 : b.startsWith('10.') ? 1 : 2));
  }
  info() {
    const running = !!this.server;
    return { running, port: this.port, error: this.error, urls: running ? this.addresses().map((a) => `http://${a}:${this.port}`) : [], devices: this.publicDevices(), pairing: this.pairing && Date.now() < this.pairing.expires ? { code: this.pairing.code, expires: this.pairing.expires } : null, locked: Date.now() < this.lockUntil };
  }

  start(port) {
    if (this.server && this.port === port) return Promise.resolve(this.info());
    return this.stop().then(() => new Promise((resolve) => {
      this.error = '';
      const srv = http.createServer((req, res) => this._handle(req, res).catch(() => { try { this._send(res, 500, { error: 'Server error' }); } catch (_) { /* ignore */ } }));
      srv.on('error', (e) => { this.error = e.code === 'EADDRINUSE' ? `Port ${port} is already in use. Pick another port.` : String(e.message || e); this.server = null; this.port = 0; this.emit('change'); resolve(this.info()); });
      srv.listen(port, '0.0.0.0', () => { this.server = srv; this.port = srv.address().port; this.emit('change'); resolve(this.info()); });
    }));
  }
  stop() {
    return new Promise((resolve) => {
      this.pairing = null;
      if (!this.server) { this.port = 0; return resolve(); }
      const s = this.server; this.server = null; this.port = 0;
      try { s.closeAllConnections && s.closeAllConnections(); } catch (_) { /* ignore */ }
      s.close(() => { this.emit('change'); resolve(); });
    });
  }

  _send(res, code, body, headers = {}) {
    const isBuf = Buffer.isBuffer(body); const data = isBuf ? body : JSON.stringify(body);
    res.writeHead(code, { 'Content-Type': isBuf ? headers['Content-Type'] || 'application/octet-stream' : 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', ...headers });
    res.end(data);
  }
  _body(req) {
    return new Promise((resolve) => {
      let n = 0; const chunks = [];
      req.on('data', (c) => { n += c.length; if (n > MAX_BODY) { req.destroy(); resolve(null); } else chunks.push(c); });
      req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (_) { resolve(null); } });
      req.on('error', () => resolve(null));
    });
  }
  _blocked(ip) { const f = this.ipFails.get(ip); return !!(f && f.until > Date.now()); }
  _fail(ip) { const now = Date.now(); const f = this.ipFails.get(ip) || { n: 0, until: 0 }; f.n++; if (f.n >= 20) { f.until = now + 60000; f.n = 0; } this.ipFails.set(ip, f); if (this.ipFails.size > 500) this.ipFails.clear(); }

  async _static(req, res, pathname) {
    const name = pathname === '/' ? 'index.html' : pathname.replace(/^\//, '');
    if (!/^[\w.\-]+$/.test(name)) return this._send(res, 404, { error: 'Not found' });
    let files = []; try { files = fs.readdirSync(this.d.staticDir); } catch (_) { /* ignore */ }
    if (!files.includes(name)) return this._send(res, 404, { error: 'Not found' });
    const ext = path.extname(name).toLowerCase(); const buf = fs.readFileSync(path.join(this.d.staticDir, name));
    const h = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' };
    if (ext === '.html') h['Content-Security-Policy'] = "default-src 'self'; img-src 'self' blob: data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'";
    return this._send(res, 200, buf, h);
  }

  async _handle(req, res) {
    const ip = req.socket.remoteAddress || '?'; const url = new URL(req.url, 'http://x'); const p = url.pathname;
    if (!p.startsWith('/api/')) { if (req.method !== 'GET') return this._send(res, 405, { error: 'Method not allowed' }); return this._static(req, res, p); }
    if (this._blocked(ip)) return this._send(res, 429, { error: 'Too many attempts. Wait a minute.' });
    const a = this.d.actions || {};

    if (p === '/api/ping' && req.method === 'GET') return this._send(res, 200, { app: 'PLAYNEX', ok: true });
    if (p === '/api/pair' && req.method === 'POST') {
      const body = await this._body(req); if (body === null) return this._send(res, 400, { error: 'Bad request' });
      const r = this._pair(body); if (r.code !== 200) this._fail(ip); return this._send(res, r.code, r.body);
    }

    const dev = this._auth(req);
    if (!dev) { this._fail(ip); return this._send(res, 401, { error: 'Not paired' }); }

    if (p === '/api/status' && req.method === 'GET') return this._send(res, 200, { ...(await this.d.status()), device: dev.name });
    if (p === '/api/unpair' && req.method === 'POST') { this.revoke(dev.id); return this._send(res, 200, { ok: true }); }

    if (req.method === 'GET') {
      let m;
      if ((m = /^\/api\/capture\/([\w-]{1,64})$/.exec(p))) {
        const f = a.captureFile && a.captureFile(m[1]); if (!f || !fs.existsSync(f)) return this._send(res, 404, { error: 'Not found' });
        return this._send(res, 200, fs.readFileSync(f), { 'Content-Type': 'image/png' });
      }
      if ((m = /^\/api\/cover\/([\w-]{1,64})$/.exec(p))) return this._cover(res, m[1]);
      return this._send(res, 404, { error: 'Not found' });
    }

    if (req.method !== 'POST') return this._send(res, 405, { error: 'Method not allowed' });
    const body = await this._body(req); if (body === null) return this._send(res, 400, { error: 'Bad request' });

    if (p === '/api/screenshot') {
      const rec = a.screenshot ? await a.screenshot() : null;
      return rec ? this._send(res, 200, { id: rec.id, label: rec.label, ts: rec.ts }) : this._send(res, 500, { error: 'Could not take a screenshot (is the PC locked or asleep?)' });
    }
    if (p === '/api/music') {
      const cmd = String(body.cmd || ''); if (!['toggle', 'next', 'prev'].includes(cmd)) return this._send(res, 400, { error: 'Bad command' });
      return this._send(res, 200, { ok: !!(a.music && await a.music(cmd, String(body.appId || ''))) });
    }
    if (p === '/api/quit-game') {
      const r = a.quitGame ? await a.quitGame(String(body.id || '')) : false;
      return this._send(res, r ? 200 : 404, r ? { ok: true } : { error: 'That game is not running' });
    }
    if (p === '/api/power') {
      const kind = String(body.action || ''); if (!['shutdown', 'restart', 'cancel'].includes(kind)) return this._send(res, 400, { error: 'Bad command' });
      const r = a.power ? await a.power(kind) : { ok: false, error: 'Not supported' };
      return this._send(res, r && r.ok ? 200 : 403, r && r.ok ? r : { error: (r && r.error) || 'Not allowed' });
    }
    return this._send(res, 404, { error: 'Not found' });
  }

  async _cover(res, id) {
    try {
      const hit = this.coverCache.get(id); if (hit) return this._send(res, 200, hit.buf, { 'Content-Type': hit.type, 'Cache-Control': 'private, max-age=3600' });
      const src = this.d.actions && this.d.actions.cover ? this.d.actions.cover(id) : '';
      if (!src) return this._send(res, 404, { error: 'No artwork' });
      let buf, type = 'image/jpeg';
      if (/^https?:\/\//i.test(src)) {
        const r = await (this.d.fetchImpl || fetch)(src); if (!r.ok) return this._send(res, 404, { error: 'No artwork' });
        buf = Buffer.from(await r.arrayBuffer()); type = (r.headers.get && r.headers.get('content-type')) || type;
      } else {
        let f = src; if (/^file:/i.test(f)) f = require('url').fileURLToPath(f);
        const ext = path.extname(f).toLowerCase(); if (!MIME[ext] || !/^image\//.test(MIME[ext]) || !fs.existsSync(f)) return this._send(res, 404, { error: 'No artwork' });
        buf = fs.readFileSync(f); type = MIME[ext];
      }
      if (buf.length > 8e6) return this._send(res, 404, { error: 'No artwork' });
      if (this.coverCache.size > 40) this.coverCache.clear();
      if (!/^image\//.test(type)) type = 'image/jpeg';
      this.coverCache.set(id, { buf, type });
      return this._send(res, 200, buf, { 'Content-Type': type, 'Cache-Control': 'private, max-age=3600' });
    } catch (_) { return this._send(res, 404, { error: 'No artwork' }); }
  }
}

module.exports = { Remote, PAIR_TTL };
