'use strict';
// Ratings & reviews from several sources, looked up by game title (works for non-Steam games too).
//  - Metacritic: critic score + review count, read from the game page's structured data (no API exists).
//    If Metacritic can't be reached or parsed, the score Steam stores for it is used instead.
//  - Steam: user review summary ("Very Positive", % positive, total) and a few top reviews. Keyless.
//  - RAWG: optional (free key in Settings): community rating + its own Metacritic copy.
const { similarity } = require('./metadata');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) PLAYNEX/1.7';

async function get(url, { json = false, timeout = 12000 } = {}) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(url, { headers: { 'User-Agent': UA, Accept: json ? 'application/json' : 'text/html,*/*' }, signal: ctl.signal });
    if (!r.ok) return null;
    return json ? await r.json() : await r.text();
  } catch (_) { return null; } finally { clearTimeout(t); }
}

/** Metacritic URL slug: "Need for Speed™ Heat" -> need-for-speed-heat */
function slug(title) {
  return String(title || '').toLowerCase().replace(/[™®©']/g, '').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

/** Slug guesses, most specific first: full title, without edition words, before a subtitle separator. */
function slugCandidates(title) {
  const edition = /\b(deluxe|standard|ultimate|gold|complete|definitive|premium|digital|legacy|anniversary|game of the year|goty|remastered|enhanced|director'?s cut)( edition| version)?\b/gi;
  const set = new Set();
  const add = (t) => { const s = slug(t); if (s) set.add(s); };
  add(title);
  const bare = String(title).replace(edition, ' ').replace(/\s+/g, ' ').trim(); add(bare);
  add(bare.replace(/\s*\(.*?\)\s*/g, ' '));
  const head = bare.split(/\s[-–:]\s|:\s/)[0]; if (head && head !== bare) add(head);
  return [...set].slice(0, 4);
}

/** Pull aggregateRating out of any ld+json blocks on a Metacritic page. */
function parseMetacritic(html) {
  if (!html) return null;
  const blocks = [...html.matchAll(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)].map((m) => m[1]);
  const walk = (o, out) => { if (!o || typeof o !== 'object') return; if (Array.isArray(o)) { o.forEach((x) => walk(x, out)); return; }
    if (o.aggregateRating) out.push(o); Object.values(o).forEach((v) => walk(v, out)); };
  for (const b of blocks) {
    let j; try { j = JSON.parse(b); } catch (_) { continue; }
    const found = []; walk(j, found);
    for (const o of found) {
      const a = o.aggregateRating; const v = Number(a.ratingValue);
      if (!isFinite(v)) continue;
      return { name: o.name || '', score: Math.round(v), count: Number(a.reviewCount || a.ratingCount) || null, best: Number(a.bestRating) || 100 };
    }
  }
  return null;
}

const PLAT = { ps3: 'PS3', ps4: 'PS4', ps5: 'PS5', ps2: 'PS2', psp: 'PSP', pc: 'PC', 'xbox-360': 'Xbox 360', xbox360: 'Xbox 360', 'xbox-one': 'Xbox One', xboxone: 'Xbox One', 'xbox-series-x': 'Xbox Series X', xboxseriesx: 'Xbox Series X', xbox: 'Xbox',
  switch: 'Switch', 'switch-2': 'Switch 2', 'wii-u': 'Wii U', wii: 'Wii', '3ds': '3DS', ds: 'DS', 'playstation-vita': 'PS Vita', 'ps-vita': 'PS Vita', ios: 'iOS', ios_iphone: 'iOS', android: 'Android', stadia: 'Stadia', gamecube: 'GameCube', dreamcast: 'Dreamcast', 'game-boy-advance': 'GBA', 'nintendo-64': 'N64', playstation: 'PS1' };
function platName(raw) {
  const k = String(raw || '').toLowerCase().trim().replace(/[\s_]+/g, '-').replace(/[^a-z0-9-]/g, '');
  const k2 = k.replace(/-/g, '');
  return PLAT[k] || PLAT[k2] || String(raw || '').trim().replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

/** "All platforms" tiles from the Metacritic game page: platform, critic score, number of critic reviews. */
function parsePlatformsHtml(html) {
  if (!html) return [];
  const out = []; const re = /Based on\s*(?:<[^>]*>\s*)*(\d+)\s*(?:<[^>]*>\s*)*Critic\s*Reviews?/gi; const hits = [];
  let m; while ((m = re.exec(html))) hits.push({ i: m.index, n: Number(m[1]), end: m.index + m[0].length });
  const last = (rx, str) => { let r = null, x; const g = new RegExp(rx.source, 'gi'); while ((x = g.exec(str))) r = { v: x[1], at: x.index }; return r; };
  // each tile starts at its platform marker (link, aria-label/alt/title, svg title or plain text name); the score is anywhere inside the tile, before or after the "Based on" text
  const marks = hits.map((h, k) => {
    const lo = k ? hits[k - 1].end : Math.max(0, h.i - 2500), seg = html.slice(lo, h.i);
    const r = last(/platform=([a-z0-9-]+)/, seg) || last(/(?:aria-label|alt|title)="([^"]{2,24})"/, seg) || last(/<title>([^<]{2,24})<\/title>/, seg)
      || last(/>\s*(PS[2-5]|PC|Xbox[^<]{0,16}|Switch[^<]{0,4}|Wii U|3DS|iOS)\s*</, seg);
    return r ? { name: r.v, at: lo + r.at } : null;
  });
  hits.forEach((h, k) => {
    const mk = marks[k]; if (!mk) return;
    const nextAt = marks.slice(k + 1).find(Boolean); const end = nextAt ? nextAt.at : Math.min(html.length, h.end + 1200);
    const seg = html.slice(mk.at, h.i) + ' ' + html.slice(h.end, end);
    const nums = [...seg.matchAll(/>\s*(\d{1,3})\s*</g)].map((x) => +x[1]).filter((v) => v <= 100);
    if (nums.length) out.push({ platform: platName(mk.name), score: nums[0], count: h.n });
  });
  return dedupePlatforms(out);
}

/** Same data from Metacritic's JSON feed: any objects that carry a platform, a score and a review count. */
function parsePlatformsJson(j) {
  const out = [];
  const walk = (o) => {
    if (!o || typeof o !== 'object') return;
    if (Array.isArray(o)) { o.forEach(walk); return; }
    const pl = o.platform || o.platformName; const plain = pl && (typeof pl === 'string' ? pl : pl.name || pl.slug);
    const csum = o.criticScoreSummary || {};
    const sc = [o.score, o.metaScore, o.metascore, csum.score].find((x) => typeof x === 'number' || (typeof x === 'string' && /^\d+$/.test(x)));
    const cnt = [o.reviewCount, o.totalReviews, o.criticReviewCount, csum.reviewCount, o.count].find((x) => x != null);
    if (plain && sc != null && +sc >= 0 && +sc <= 100) out.push({ platform: platName(plain), score: +sc, count: Number(cnt) || null });
    Object.values(o).forEach(walk);
  };
  walk(j); return dedupePlatforms(out);
}
function dedupePlatforms(list) { const seen = new Set(); return list.filter((p) => !seen.has(p.platform) && seen.add(p.platform)); }

function scoreWord(s) { return s >= 90 ? 'Universal acclaim' : s >= 75 ? 'Generally favorable' : s >= 50 ? 'Mixed or average' : s >= 20 ? 'Generally unfavorable' : 'Overwhelming dislike'; }

async function metacritic(title, platformHint) {
  const bases = slugCandidates(title);
  for (const s of bases) {
    const urls = [`https://www.metacritic.com/game/${s}/`];
    if (platformHint) urls.push(`https://www.metacritic.com/game/${platformHint}/${s}/`);
    for (const url of urls) {
      const html = await get(url); const m = parseMetacritic(html);
      if (!m) continue;
      const nm = m.name || (html.match(/<title>([^<]*?)(?:\s+(?:Reviews?|for|-).*)?<\/title>/i) || [])[1] || '';
      if (nm && similarity(title, nm) < 0.55 && similarity(bases[0].replace(/-/g, ' '), nm) < 0.55) continue;   // wrong game
      let platforms = parsePlatformsHtml(html);
      if (platforms.length < 2) {
        const j = await get(`https://backend.metacritic.com/composer/metacritic/pages/games/${s}/web?apiKey=${MC_KEY}&componentName=product&componentType=Product`, { json: true });
        const alt = parsePlatformsJson(j); if (alt.length > platforms.length) platforms = alt;
      }
      return { score: m.score, count: m.count, url, slug: s, platforms, word: scoreWord(m.score), source: 'metacritic' };
    }
  }
  return null;
}

const MC_KEY = '1MOZgmNFxvmljaQR1X9KAij9Mo4xAY3u';   // the public key metacritic.com's own pages use for their review feed
const strip = (t) => String(t || '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&#x27;|&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();

/** Metacritic review feed items -> our shape (accepts a few field-name variants so small site changes don't break it). */
function parseMcFeed(j, kind) {
  const items = (j && j.data && (j.data.items || j.data.reviews)) || (j && j.items) || [];
  return items.map((it) => {
    const sc = it.score != null ? Number(it.score) : (it.rating != null ? Number(it.rating) : null);
    return {
      kind, score: isFinite(sc) ? sc : null,
      who: it.publicationName || (it.publication && it.publication.name) || it.source || it.author || it.username || '',
      author: kind === 'critic' ? (it.author || '') : (it.author || it.username || ''),
      quote: strip(it.quote || it.reviewText || it.body || it.text).slice(0, 380),
      date: it.date || it.reviewDate || '', url: it.url || it.reviewUrl || '',
    };
  }).filter((r) => r.quote.length > 20);
}

/** Fallback: read review cards out of the server-rendered critic/user review pages. */
function parseMcHtml(html, kind) {
  if (!html) return [];
  const cards = html.split(/<div[^>]+class="[^"]*c-siteReview\b[^"]*"/).slice(1);
  return cards.map((c) => {
    const sc = (c.match(/c-siteReviewScore[^>]*>\s*<span[^>]*>\s*(\d+(?:\.\d)?)/) || [])[1];
    const q = (c.match(/c-siteReview_quote[^>]*>([\s\S]*?)<\/(?:div|p)>/) || [])[1];
    const who = (c.match(/c-siteReviewHeader_(?:publicationName|reviewer|username)[^>]*>([\s\S]*?)<\/(?:a|span|div)>/) || [])[1];
    return { kind, score: sc != null ? Number(sc) : null, who: strip(who), author: '', quote: strip(q).slice(0, 380), date: '', url: '' };
  }).filter((r) => r.quote.length > 20).slice(0, 10);
}

async function metacriticReviews(slg) {
  if (!slg) return { critic: [], user: [] };
  const feed = (kind) => `https://backend.metacritic.com/reviews/metacritic/${kind}/games/${slg}/web?apiKey=${MC_KEY}&offset=0&limit=8&filterBySentiment=all&sort=${kind === 'critic' ? 'score' : 'helpful'}&componentName=${kind}-reviews&componentDisplayName=${kind}+Reviews&componentType=ReviewList`;
  const one = async (kind) => {
    let list = parseMcFeed(await get(feed(kind), { json: true }), kind);
    if (!list.length) list = parseMcHtml(await get(`https://www.metacritic.com/game/${slg}/${kind}-reviews/`), kind);
    return list.slice(0, 8);
  };
  const [critic, user] = await Promise.all([one('critic'), one('user')]);
  return { critic, user };
}

/** Steam user reviews: summary plus a few of the most helpful written reviews. */
async function steamReviews(appId) {
  const j = await get(`https://store.steampowered.com/appreviews/${appId}?json=1&language=english&purchase_type=all&filter=all&num_per_page=6`, { json: true });
  return parseSteam(j, appId);
}
function parseSteam(j, appId) {
  const q = j && j.query_summary; if (!q || !q.total_reviews) return null;
  const pos = q.total_positive || 0, tot = q.total_reviews || 0;
  const clean = (t) => String(t || '').replace(/\[\/?[a-z0-9*=_ "':/.-]+\]/gi, ' ').replace(/\s+/g, ' ').trim();
  const reviews = ((j.reviews) || []).map((r) => ({
    text: clean(r.review).slice(0, 320), up: !!r.voted_up, votes: r.votes_up || 0,
    hours: r.author && r.author.playtime_forever ? Math.round(r.author.playtime_forever / 60) : null,
  })).filter((r) => r.text.length > 25).slice(0, 4);
  return { desc: q.review_score_desc || '', percent: tot ? Math.round((pos / tot) * 100) : null, total: tot, positive: pos, reviews, url: `https://store.steampowered.com/app/${appId}/#app_reviews_hash`, source: 'steam' };
}

async function rawg(title, key) {
  if (!key) return null;
  const j = await get(`https://api.rawg.io/api/games?search=${encodeURIComponent(title)}&search_precise=true&page_size=3&key=${encodeURIComponent(key)}`, { json: true });
  const best = ((j && j.results) || []).map((r) => ({ r, s: similarity(title, r.name) })).sort((a, b) => b.s - a.s)[0];
  if (!best || best.s < 0.6) return null;
  const r = best.r;
  return { rating: r.rating || null, count: r.ratings_count || 0, metacritic: r.metacritic || null, name: r.name, url: r.slug ? `https://rawg.io/games/${r.slug}` : null, source: 'rawg' };
}

/**
 * Look up everything for one title. `steamAppId` and `steamMetacritic` ({score,url}) come from the game's saved metadata when known.
 * Every source is optional - whatever is found is returned.
 */
async function lookup({ title, steamAppId, steamMetacritic, rawgKey, steamSearch }) {
  let appId = steamAppId || null;
  if (!appId && steamSearch) {
    try { const r = (await steamSearch(title)).sort((a, b) => b.score - a.score)[0]; if (r && r.score >= 0.72) appId = r.appId; } catch (_) { /* ignore */ }
  }
  const [mc, st, rw] = await Promise.all([
    metacritic(title), appId ? steamReviews(appId) : null, rawg(title, rawgKey),
  ]);
  if (mc && mc.platforms && mc.platforms.length) {          // this is a PC launcher: lead with the PC score when Metacritic has one
    const pc = mc.platforms.find((x) => x.platform === 'PC');
    if (pc) { mc.score = pc.score; mc.count = pc.count || mc.count; mc.word = scoreWord(pc.score); mc.headline = 'PC'; }
  }
  const reviews = mc && mc.slug ? await metacriticReviews(mc.slug) : { critic: [], user: [] };
  let critic = mc;
  if (!critic && steamMetacritic && steamMetacritic.score) critic = { score: steamMetacritic.score, count: null, url: steamMetacritic.url || `https://www.metacritic.com/search/${encodeURIComponent(title)}/`, word: scoreWord(steamMetacritic.score), source: 'steam-metacritic' };
  if (!critic && rw && rw.metacritic) critic = { score: rw.metacritic, count: null, url: `https://www.metacritic.com/search/${encodeURIComponent(title)}/`, word: scoreWord(rw.metacritic), source: 'rawg-metacritic' };
  return { critic, reviews, steam: st, rawg: rw, steamAppId: appId, fetchedAt: Date.now() };
}

module.exports = { lookup, parsePlatformsHtml, parsePlatformsJson, platName, parseMcFeed, parseMcHtml, parseMetacritic, parseSteam, slug, slugCandidates, scoreWord };
