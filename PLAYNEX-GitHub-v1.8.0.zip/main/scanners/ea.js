'use strict';
// EA app / Origin. Uses registry "EA Games" keys plus the usual install roots.
const path = require('path');
const C = require('./common');

async function scan() {
  const found = new Map(); // dir(lower) -> game
  const add = (title, dir) => {
    dir = C.normPath(dir);
    if (!dir || !C.isDir(dir)) return;
    const k = dir.toLowerCase();
    if (found.has(k)) return;
    const exe = C.findMainExe(dir);
    if (!exe) return;
    found.set(k, {
      platform: 'ea', appId: C.hashId(dir), title, installDir: dir, exe,
      launch: { type: 'exe', target: exe },
    });
  };

  for (const base of ['HKLM\\SOFTWARE\\EA Games', 'HKLM\\SOFTWARE\\Electronic Arts']) {
    const entries = await C.regQueryBoth(base);
    for (const e of C.regChildren(entries, base)) {
      const dir = e.values['Install Dir'] || e.values.InstallDir || e.values['Install Dir '];
      const title = e.values.DisplayName || e.key.split('\\').pop();
      if (dir) add(title, dir);
    }
  }

  const roots = [];
  for (const pf of [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], 'C:\\Program Files', 'C:\\Program Files (x86)']) {
    if (!pf) continue;
    roots.push(path.join(pf, 'EA Games'), path.join(pf, 'Origin Games'), path.join(pf, 'Electronic Arts'));
  }
  for (const d of C.driveRoots()) roots.push(path.join(d, 'EA Games'), path.join(d, 'Origin Games'), path.join(d, 'Games', 'EA Games'));
  for (const r of new Set(roots)) for (const d of C.subdirs(r)) add(path.basename(d), d);

  return [...found.values()];
}

module.exports = { id: 'ea', name: 'EA app', scan };
