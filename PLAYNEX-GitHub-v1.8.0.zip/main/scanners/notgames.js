'use strict';
/** Launchers, utilities and runtimes that look like games to a folder/registry scan. */
const TITLE = /^(wallpaper engine|ea app|ea desktop|ea launcher|ea anticheat|ea play|ea link|origin|origin helper|epic games launcher|epic online services|easyanticheat|easy anti-?cheat|battleye|battle\.net|blizzard battle\.net|ubisoft connect|uplay|gog galaxy|riot client|rockstar games launcher|rockstar games social club|steam|steamvr|xbox|xbox app|gaming services|overwolf|discord|obs studio|nvidia.*|geforce.*|amd software.*|microsoft (visual c\+\+|\.net|edge|gaming).*|directx.*|vulkan.*|physx.*|openal.*|redistributables?|_commonredist|support|crash ?reporter|launcher helper)$/i;
const DIR = /[\\/](wallpaper_engine|wallpaper engine|electronic arts[\\/]ea desktop|ea desktop|ea app|origin|epic games[\\/]launcher|epic games[\\/]epiconlineservices|battle\.net|ubisoft game launcher|gog galaxy|riot client|rockstar games[\\/]launcher|rockstar games[\\/]social club)([\\/]|$)/i;
const EXE = /(wallpaper(32|64|_engine)?|eadesktop|eabackgroundservice|eaanticheat.*|origin|epicgameslauncher|battle\.net|upc|ubisoftconnect|galaxyclient|riotclientservices|launcherpatcher)\.exe$/i;

function isNotGame(g) {
  if (!g || g.platform === 'custom') return false;
  const title = String(g.title || '').trim();
  return TITLE.test(title) || DIR.test(String(g.installDir || '') + '\\') || EXE.test(String(g.exe || ''));
}
module.exports = { isNotGame };
