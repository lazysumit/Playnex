'use strict';
const path = require('path');
const C = require('./common');

const TITLES = {
  valorant: 'VALORANT', league_of_legends: 'League of Legends', bacon: 'Legends of Runeterra',
  lor: 'Legends of Runeterra', lion: '2XKO',
};

function parseSettings(text, folderName) {
  if (!text) return null;
  const pick = (k) => { const m = new RegExp('^\\s*' + k + '\\s*:\\s*"?([^"\\r\\n]+?)"?\\s*$', 'm').exec(text); return m ? m[1] : null; };
  const dir = pick('product_install_full_path');
  const id = pick('product_id') || (folderName || '').split('.')[0];
  const patchline = pick('patchline') || (folderName || '').split('.')[1] || 'live';
  if (!dir || !id) return null;
  return { dir: C.normPath(dir.replace(/\\\\/g, '\\')), id, patchline };
}

async function scan() {
  const base = process.env.ProgramData || 'C:\\ProgramData';
  const meta = path.join(base, 'Riot Games', 'Metadata');
  const clientJson = C.readJson(path.join(base, 'Riot Games', 'RiotClientInstalls.json'));
  const client = clientJson && (clientJson.rc_default || clientJson.rc_live || clientJson.rc_beta);
  const out = [];
  for (const d of C.subdirs(meta)) {
    const name = path.basename(d);
    if (/riot_client/i.test(name)) continue;
    const f = C.listDir(d).find((x) => /product_settings\.yaml$/i.test(x.name));
    if (!f) continue;
    const s = parseSettings(C.readText(path.join(d, f.name)), name);
    if (!s || !C.isDir(s.dir)) continue;
    const launch = client && C.exists(client)
      ? { type: 'exe', target: client, args: `--launch-product=${s.id} --launch-patchline=${s.patchline}` }
      : { type: 'exe', target: C.findMainExe(s.dir) };
    if (!launch.target) continue;
    out.push({
      platform: 'riot', appId: `${s.id}.${s.patchline}`, title: TITLES[s.id] || s.id.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
      installDir: s.dir, exe: C.findMainExe(s.dir), launch,
    });
  }
  return out;
}

module.exports = { id: 'riot', name: 'Riot Games', scan, parseSettings };
