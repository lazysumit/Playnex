'use strict';
// Xbox / Microsoft Store PC games installed via Gaming Services (X:\XboxGames\<Game>\Content).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const C = require('./common');

/** Package family name publisher hash: base32(first 8 bytes of sha256(utf16le(publisher))). */
function publisherId(publisher) {
  const h = crypto.createHash('sha256').update(Buffer.from(publisher, 'utf16le')).digest().subarray(0, 8);
  const alphabet = '0123456789abcdefghjkmnpqrstvwxyz';
  let bits = '';
  for (const b of h) bits += b.toString(2).padStart(8, '0');
  bits = bits.padEnd(65, '0');
  let out = '';
  for (let i = 0; i < 65; i += 5) out += alphabet[parseInt(bits.slice(i, i + 5), 2)];
  return out;
}

function attr(tag, name) {
  const m = new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i').exec(tag || '');
  return m ? m[1] : null;
}

function parseConfig(xml) {
  if (!xml) return null;
  const ident = /<Identity\b[^>]*>/i.exec(xml);
  if (!ident) return null;
  const name = attr(ident[0], 'Name'), publisher = attr(ident[0], 'Publisher');
  const exeTag = /<Executable\b[^>]*>/i.exec(xml);
  let title = null;
  const st = /<ShellVisuals\b[^>]*>/i.exec(xml);
  if (st) title = attr(st[0], 'DefaultDisplayName');
  if (title && /^ms-resource:/i.test(title)) title = null;
  return {
    name, publisher,
    exeName: exeTag ? attr(exeTag[0], 'Name') : null,
    appId: exeTag ? attr(exeTag[0], 'Id') || 'Game' : 'Game',
    title,
  };
}

function gamingRoots() {
  const roots = new Set();
  for (const d of C.driveRoots()) {
    roots.add(path.join(d, 'XboxGames'));
    const gr = path.join(d, '.GamingRoot');
    if (C.exists(gr)) {
      try {
        const buf = fs.readFileSync(gr);
        const s = buf.subarray(8).toString('utf16le').replace(/\0.*$/, '');
        if (s) roots.add(path.join(d, s.replace(/^\\+/, '')));
      } catch (_) { /* ignore */ }
    }
  }
  return [...roots].filter(C.isDir);
}

async function scan() {
  const out = [];
  for (const root of gamingRoots()) {
    for (const dir of C.subdirs(root)) {
      const content = path.join(dir, 'Content');
      const cfg = parseConfig(C.readText(path.join(content, 'MicrosoftGame.Config')));
      const title = (cfg && cfg.title) || path.basename(dir);
      const exe = cfg && cfg.exeName && C.exists(path.join(content, cfg.exeName))
        ? path.join(content, cfg.exeName) : C.findMainExe(C.isDir(content) ? content : dir);
      let launch;
      if (cfg && cfg.name && cfg.publisher) {
        launch = { type: 'aumid', target: `${cfg.name}_${publisherId(cfg.publisher)}!${cfg.appId}`, fallbackExe: exe };
      } else if (exe) launch = { type: 'exe', target: exe };
      else continue;
      out.push({ platform: 'xbox', appId: (cfg && cfg.name) || path.basename(dir), title, installDir: dir, exe, launch });
    }
  }
  return out;
}

module.exports = { id: 'xbox', name: 'Xbox', scan, parseConfig, publisherId };
