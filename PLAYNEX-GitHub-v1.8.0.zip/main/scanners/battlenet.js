'use strict';
const path = require('path');
const C = require('./common');

// Battle.net protocol codes for launching a product through the client.
const CODES = [
  [/world of warcraft/i, 'WoW'], [/diablo iv/i, 'Fen'], [/diablo (iii|3)/i, 'D3'],
  [/diablo ii.*resurrected/i, 'OSI'], [/overwatch/i, 'Pro'], [/hearthstone/i, 'WTCG'],
  [/starcraft ii/i, 'S2'], [/starcraft/i, 'S1'], [/heroes of the storm/i, 'Hero'],
  [/warcraft iii/i, 'W3'], [/call of duty.*(modern warfare|black ops cold war|vanguard)/i, 'ODIN'],
  [/warzone/i, 'LAZR'], [/crash bandicoot/i, 'WLBY'],
];

function codeFor(title) { for (const [re, c] of CODES) if (re.test(title)) return c; return null; }

async function scan() {
  const base = 'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall';
  const entries = await C.regQueryBoth(base);
  const out = new Map();
  for (const e of C.regChildren(entries, base)) {
    const v = e.values;
    if (!/blizzard/i.test(v.Publisher || '')) continue;
    const title = v.DisplayName;
    if (!title || /battle\.net|blizzard (agent|app)|launcher/i.test(title)) continue;
    const dir = C.normPath(v.InstallLocation || '');
    if (!dir || !C.isDir(dir)) continue;
    add(out, title, dir);
  }

  // Fallback: product.db (protobuf) — pull install paths out of the raw bytes.
  const db = path.join(process.env.ProgramData || 'C:\\ProgramData', 'Battle.net', 'Agent', 'product.db');
  try {
    const raw = require('fs').readFileSync(db).toString('latin1');
    const re = /[A-Za-z]:[\\/][\x20-\x7e]{3,200}?(?=[\x00-\x1f]|$)/g;
    let m;
    while ((m = re.exec(raw))) {
      const dir = C.normPath(m[0]);
      if (C.isDir(dir) && !/battle\.net|agent/i.test(dir)) add(out, path.basename(dir), dir);
    }
  } catch (_) { /* not installed */ }
  return [...out.values()];
}

function add(map, title, dir) {
  const k = dir.toLowerCase();
  if (map.has(k)) return;
  const exe = C.findMainExe(dir);
  const code = codeFor(title);
  if (!code && !exe) return;
  map.set(k, {
    platform: 'battlenet', appId: code || C.hashId(dir), title, installDir: dir, exe,
    launch: code ? { type: 'protocol', target: `battlenet://${code}`, fallbackExe: exe } : { type: 'exe', target: exe },
  });
}

module.exports = { id: 'battlenet', name: 'Battle.net', scan, codeFor };
