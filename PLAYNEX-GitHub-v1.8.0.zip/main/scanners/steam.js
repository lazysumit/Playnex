'use strict';
const path = require('path');
const C = require('./common');

const IGNORE_IDS = new Set(['431960', '228980', '1070560', '1391110', '1493710', '1826330', '2180100', '250820']);
const IGNORE_NAME = /^(steamworks|steam linux runtime|proton|steamvr|steam controller|wallpaper engine: |source sdk|redistributable)/i;

async function steamRoot() {
  const roots = [];
  for (const key of ['HKCU\\Software\\Valve\\Steam', 'HKLM\\SOFTWARE\\WOW6432Node\\Valve\\Steam', 'HKLM\\SOFTWARE\\Valve\\Steam']) {
    const r = await C.regQuery(key, '');
    for (const e of r) { const v = e.values.SteamPath || e.values.InstallPath; if (v) roots.push(C.normPath(v)); }
  }
  roots.push('C:\\Program Files (x86)\\Steam', 'C:\\Program Files\\Steam');
  return roots.find((r) => C.isDir(r)) || null;
}

function libraryFolders(root) {
  const libs = new Set([root]);
  const txt = C.readText(path.join(root, 'steamapps', 'libraryfolders.vdf'));
  if (txt) {
    const v = C.parseVdf(txt).libraryfolders || {};
    for (const k of Object.keys(v)) {
      const e = v[k];
      const p = typeof e === 'string' ? e : e && e.path;
      if (p) libs.add(C.normPath(p));
    }
  }
  return [...libs];
}

function parseManifest(text) {
  const s = C.parseVdf(text).AppState;
  if (!s || !s.appid) return null;
  return s;
}

async function scan() {
  const root = await steamRoot();
  if (!root) return [];
  const out = [];
  for (const lib of libraryFolders(root)) {
    const apps = path.join(lib, 'steamapps');
    for (const f of C.listDir(apps)) {
      if (!/^appmanifest_\d+\.acf$/i.test(f.name)) continue;
      const s = parseManifest(C.readText(path.join(apps, f.name)) || '');
      if (!s) continue;
      const flags = parseInt(s.StateFlags || '0', 10);
      if (!(flags & 4)) continue; // 4 = fully installed
      if (IGNORE_IDS.has(s.appid) || IGNORE_NAME.test(s.name || '')) continue;
      const installDir = path.join(apps, 'common', s.installdir || '');
      if (!C.isDir(installDir)) continue;
      out.push({
        platform: 'steam', appId: s.appid, title: s.name || s.installdir, installDir,
        steamAppId: s.appid,
        launch: { type: 'protocol', target: `steam://rungameid/${s.appid}` },
        extra: { steamRoot: root },
      });
    }
  }
  return out;
}

module.exports = { id: 'steam', name: 'Steam', scan, parseManifest, libraryFolders };
