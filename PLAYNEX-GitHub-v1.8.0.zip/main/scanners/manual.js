'use strict';
// Manual folder scanning: every sub-folder that contains a game-looking .exe becomes a game.
const path = require('path');
const C = require('./common');

function cleanTitle(name) {
  return name.replace(/[_.]+/g, ' ').replace(/\s*[\[(](?:v?\d[\d.]*|gog|steam|repack|x64|x86|win64|win32)[\])]/gi, '').replace(/\s+/g, ' ').trim();
}

async function scanFolders(folders) {
  const out = [];
  for (const root of folders || []) {
    if (!C.isDir(root)) continue;
    const dirs = C.subdirs(root);
    // If the chosen folder itself holds an exe directly, treat it as a single game.
    const direct = C.findMainExe(root, 0);
    if (direct && !dirs.length) dirs.push(root);
    for (const d of dirs) {
      const exe = C.findMainExe(d);
      if (!exe) continue;
      out.push({
        platform: 'manual', appId: C.hashId(d), title: cleanTitle(path.basename(d)), installDir: d, exe,
        launch: { type: 'exe', target: exe },
      });
    }
  }
  return out;
}

function customGame(exe, { title, args } = {}) {
  const dir = path.dirname(exe);
  return {
    platform: 'custom', appId: C.hashId(exe), title: title || cleanTitle(path.basename(exe).replace(/\.exe$/i, '')),
    installDir: dir, exe, launch: { type: 'exe', target: exe, args: args || '', cwd: dir },
  };
}

module.exports = { scanFolders, customGame, cleanTitle };
