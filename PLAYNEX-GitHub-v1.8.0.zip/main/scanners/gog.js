'use strict';
const path = require('path');
const C = require('./common');

async function scan() {
  const base = 'HKLM\\SOFTWARE\\GOG.com\\Games';
  const entries = await C.regQueryBoth(base);
  const out = [];
  for (const e of C.regChildren(entries, base)) {
    const v = e.values;
    const dir = C.normPath(v.path || '');
    if (!dir || !C.isDir(dir)) continue;
    const exe = v.exe && C.exists(v.exe) ? v.exe : C.findMainExe(dir);
    if (!exe) continue;
    out.push({
      platform: 'gog', appId: v.gameID || e.key.split('\\').pop(), title: v.gameName || path.basename(dir),
      installDir: dir, exe,
      launch: { type: 'exe', target: exe, args: v.launchParam || '', cwd: v.workingDir || dir },
    });
  }
  return out;
}

module.exports = { id: 'gog', name: 'GOG', scan };
