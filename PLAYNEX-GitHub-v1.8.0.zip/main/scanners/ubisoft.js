'use strict';
const path = require('path');
const C = require('./common');

async function scan() {
  const base = 'HKLM\\SOFTWARE\\Ubisoft\\Launcher\\Installs';
  const entries = await C.regQueryBoth(base);
  const out = [];
  for (const e of C.regChildren(entries, base)) {
    const dir = C.normPath(e.values.InstallDir || '');
    const id = e.key.split('\\').pop();
    if (!dir || !C.isDir(dir)) continue;
    out.push({
      platform: 'ubisoft', appId: id, title: path.basename(dir), installDir: dir,
      exe: C.findMainExe(dir),
      launch: { type: 'protocol', target: `uplay://launch/${id}/0` },
    });
  }
  return out;
}

module.exports = { id: 'ubisoft', name: 'Ubisoft Connect', scan };
