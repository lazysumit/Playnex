'use strict';
const path = require('path');
const C = require('./common');

function parseItem(j) {
  if (!j || !j.DisplayName || !j.InstallLocation) return null;
  const cats = (j.AppCategories || []).map((s) => String(s).toLowerCase());
  if (cats.length && !cats.includes('games')) return null; // skip add-ons, engines, tools
  if (j.bIsIncompleteInstall) return null;
  const ns = j.CatalogNamespace, item = j.CatalogItemId, app = j.AppName;
  const launch = ns && item && app
    ? { type: 'protocol', target: `com.epicgames.launcher://apps/${ns}%3A${item}%3A${app}?action=launch&silent=true` }
    : { type: 'exe', target: path.join(j.InstallLocation, j.LaunchExecutable || '') };
  return {
    platform: 'epic', appId: app || item, title: j.DisplayName, installDir: C.normPath(j.InstallLocation),
    exe: j.LaunchExecutable ? path.join(j.InstallLocation, j.LaunchExecutable) : null, launch,
  };
}

async function scan() {
  const base = process.env.ProgramData || 'C:\\ProgramData';
  const dir = path.join(base, 'Epic', 'EpicGamesLauncher', 'Data', 'Manifests');
  const out = [];
  for (const f of C.listDir(dir)) {
    if (!/\.item$/i.test(f.name)) continue;
    const g = parseItem(C.readJson(path.join(dir, f.name)));
    if (g && C.isDir(g.installDir)) out.push(g);
  }
  return out;
}

module.exports = { id: 'epic', name: 'Epic Games', scan, parseItem };
