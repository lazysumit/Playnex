'use strict';
const path = require('path');
const C = require('./common');

const KNOWN_EXE = { 'grand theft auto v': 'PlayGTAV.exe', gtav: 'PlayGTAV.exe', 'red dead redemption 2': 'RDR2.exe', 'grand theft auto iv': 'GTAIV.exe', 'max payne 3': 'MaxPayne3.exe', 'l.a. noire': 'LA Noire.exe' };

async function scan() {
  const out = new Map();
  const add = (title, dir) => {
    dir = C.normPath(dir);
    if (!dir || !C.isDir(dir) || /launcher$/i.test(path.basename(dir)) || /^rockstar games$/i.test(path.basename(dir))) return;
    const k = dir.toLowerCase();
    if (out.has(k)) return;
    const known = KNOWN_EXE[String(title).toLowerCase()];
    const exe = known && C.exists(path.join(dir, known)) ? path.join(dir, known) : C.findMainExe(dir, 1);
    if (!exe) return;
    out.set(k, { platform: 'rockstar', appId: C.hashId(dir), title, installDir: dir, exe, launch: { type: 'exe', target: exe } });
  };

  const base = 'HKLM\\SOFTWARE\\Rockstar Games';
  for (const e of C.regChildren(await C.regQueryBoth(base), base)) {
    const name = e.key.split('\\').pop();
    if (/launcher|social club/i.test(name)) continue;
    add(name, e.values.InstallFolder || e.values.InstallFolderSteam || '');
  }
  const roots = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], 'C:\\Program Files', ...C.driveRoots().map((d) => path.join(d, 'Games'))]
    .filter(Boolean).map((r) => path.join(r, 'Rockstar Games'));
  for (const r of new Set(roots)) for (const d of C.subdirs(r)) add(path.basename(d), d);
  return [...out.values()];
}

module.exports = { id: 'rockstar', name: 'Rockstar Games', scan };
