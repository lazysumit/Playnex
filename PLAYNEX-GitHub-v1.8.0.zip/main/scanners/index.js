'use strict';
const manual = require('./manual');
const { isNotGame } = require('./notgames');

const SCANNERS = [
  require('./steam'), require('./epic'), require('./xbox'), require('./ubisoft'), require('./ea'),
  require('./battlenet'), require('./gog'), require('./riot'), require('./rockstar'),
];

const PLATFORMS = {
  steam: 'Steam', epic: 'Epic Games', xbox: 'Xbox', ubisoft: 'Ubisoft Connect', ea: 'EA app',
  battlenet: 'Battle.net', gog: 'GOG', riot: 'Riot Games', rockstar: 'Rockstar Games',
  manual: 'Scanned folder', custom: 'Custom',
};

/**
 * Run every enabled scanner. A failing scanner never aborts the others.
 * onProgress({platform, name, count, error?, done, total})
 */
async function scanAll(settings, onProgress = () => {}) {
  const enabled = SCANNERS.filter((s) => settings.platforms[s.id] !== false);
  const total = enabled.length + 1;
  const results = [];
  const report = {};
  let done = 0;
  await Promise.all(enabled.map(async (s) => {
    try {
      const games = await s.scan();
      results.push(...games);
      report[s.id] = { count: games.length };
    } catch (e) {
      report[s.id] = { count: 0, error: String(e && e.message || e) };
    }
    onProgress({ platform: s.id, name: s.name, count: report[s.id].count, error: report[s.id].error, done: ++done, total });
  }));
  let manualGames = [];
  try { manualGames = await manual.scanFolders(settings.scanFolders); } catch (e) { report.manual = { count: 0, error: String(e) }; }
  report.manual = report.manual || { count: manualGames.length };
  onProgress({ platform: 'manual', name: 'Scanned folders', count: manualGames.length, done: ++done, total });
  return { games: results.filter((g) => !isNotGame(g)), manualGames: manualGames.filter((g) => !isNotGame(g)), report };
}

module.exports = { isNotGame, scanAll, PLATFORMS, SCANNERS, manual };
