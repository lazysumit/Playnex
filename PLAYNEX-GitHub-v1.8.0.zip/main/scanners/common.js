'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const isWin = process.platform === 'win32';

/** Run `reg query <key> /s` and return [{key, values:{name:value}}]. Never throws. */
function regQuery(key, view = '64') {
  return new Promise((resolve) => {
    if (!isWin) return resolve([]);
    const args = ['query', key, '/s'];
    if (view) args.push('/reg:' + view);
    execFile('reg', args, { windowsHide: true, maxBuffer: 32 * 1024 * 1024 }, (err, stdout) => {
      if (err && !stdout) return resolve([]);
      resolve(parseReg(stdout));
    });
  });
}

function parseReg(text) {
  const out = [];
  let cur = null;
  for (const line of String(text).split(/\r?\n/)) {
    if (/^HKEY_/i.test(line.trim())) { cur = { key: line.trim(), values: {} }; out.push(cur); continue; }
    if (!cur) continue;
    const m = /^\s+(.+?)\s{4}(REG_\w+)\s{0,4}(.*)$/.exec(line);
    if (m) cur.values[m[1]] = m[3];
  }
  return out;
}

/** Query both registry views and merge. */
async function regQueryBoth(key) {
  const [a, b] = await Promise.all([regQuery(key, '64'), regQuery(key, '32')]);
  const seen = new Set();
  return [...a, ...b].filter((e) => (seen.has(e.key.toLowerCase()) ? false : seen.add(e.key.toLowerCase())));
}

/** Direct children (one level) of a reg query /s result for `base`. */
function regChildren(entries, base) {
  const b = base.replace(/\\+$/, '').toLowerCase();
  return entries.filter((e) => {
    const k = e.key.toLowerCase();
    if (!k.startsWith(b + '\\')) return false;
    return !k.slice(b.length + 1).includes('\\');
  });
}

/** Valve KeyValues (VDF/ACF) parser. */
function parseVdf(text) {
  const tokens = [];
  const re = /"((?:[^"\\]|\\.)*)"|([{}])/g;
  let m;
  while ((m = re.exec(text))) {
    if (m[2]) tokens.push({ b: m[2] });
    else tokens.push({ s: m[1].replace(/\\(.)/g, (_, c) => (c === 'n' ? '\n' : c === 't' ? '\t' : c)) });
  }
  let i = 0;
  function block() {
    const obj = {};
    while (i < tokens.length) {
      const t = tokens[i++];
      if (t.b === '}') return obj;
      if (t.b === '{') continue;
      const key = t.s;
      const n = tokens[i];
      if (n && n.b === '{') { i++; obj[key] = block(); } else if (n) { obj[key] = n.s; i++; }
    }
    return obj;
  }
  return block();
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^﻿/, '')); } catch (_) { return null; }
}
function readText(file) { try { return fs.readFileSync(file, 'utf8').replace(/^﻿/, ''); } catch (_) { return null; } }
function exists(p) { try { fs.accessSync(p); return true; } catch (_) { return false; } }
function isDir(p) { try { return fs.statSync(p).isDirectory(); } catch (_) { return false; } }
function listDir(p) { try { return fs.readdirSync(p, { withFileTypes: true }); } catch (_) { return []; } }
function subdirs(p) { return listDir(p).filter((d) => d.isDirectory()).map((d) => path.join(p, d.name)); }

function driveRoots() {
  if (!isWin) return [];
  const out = [];
  for (let c = 67; c <= 90; c++) { const r = String.fromCharCode(c) + ':\\'; if (isDir(r)) out.push(r); }
  return out;
}

const EXE_SKIP = /(unins|uninst|setup|install|redist|vcredist|vc_redist|dxsetup|dotnet|crash|report|helper|updater|update|eac|easyanticheat|beservice|bootstrap|cleanup|diag|config(?:ure)?tool|notification_helper|7z|oalinst|physx|launcher_helper)/i;

/** Find the most likely game executable within a folder (depth <= 2). */
function findMainExe(dir, maxDepth = 2) {
  let best = null;
  (function walk(d, depth) {
    for (const e of listDir(d)) {
      const full = path.join(d, e.name);
      if (e.isDirectory()) {
        if (depth < maxDepth && !/^(_commonredist|redist|redistributables?|__installer|directx|vcredist|support|engine|crashreport.*)$/i.test(e.name)) walk(full, depth + 1);
      } else if (/\.exe$/i.test(e.name) && !EXE_SKIP.test(e.name)) {
        let size = 0; try { size = fs.statSync(full).size; } catch (_) { /* ignore */ }
        // Prefer exes near the root and ones matching the folder name.
        const nameBonus = path.basename(dir).toLowerCase().replace(/[^a-z0-9]/g, '').includes(e.name.toLowerCase().replace(/\.exe$/, '').replace(/[^a-z0-9]/g, '')) ? 5e7 : 0;
        const score = size + nameBonus - depth * 2e7;
        if (!best || score > best.score) best = { full, score };
      }
    }
  })(dir, 0);
  return best ? best.full : null;
}

function hashId(s) { return crypto.createHash('sha1').update(String(s).toLowerCase()).digest('hex').slice(0, 10); }

function normPath(p) { return String(p || '').replace(/\//g, '\\').replace(/\\+$/, ''); }

module.exports = {
  isWin, regQuery, regQueryBoth, regChildren, parseReg, parseVdf, readJson, readText,
  exists, isDir, listDir, subdirs, driveRoots, findMainExe, hashId, normPath,
};
