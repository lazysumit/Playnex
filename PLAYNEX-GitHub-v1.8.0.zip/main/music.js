'use strict';
/**
 * Music support (Windows).
 *  - "Now playing" comes from the Windows media session (the same source as the volume flyout), so it works for Spotify,
 *    Apple Music, iTunes, Tidal, Deezer, VLC, foobar2000, MusicBee and for web players such as SoundCloud or YouTube Music
 *    running in a browser.
 *  - Installed apps are found from known install paths, the uninstall registry and Store packages.
 *  - Users can add any other program by hand.
 */
const { spawn, execFile } = require('child_process');
const { EventEmitter } = require('events');
const fs = require('fs');
const path = require('path');
const C = require('./scanners/common');

const isWin = process.platform === 'win32';
const env = (s) => String(s).replace(/%([^%]+)%/g, (_, k) => process.env[k] || '');

const KNOWN = [
  { id: 'spotify', name: 'Spotify', color: '#1ed760', exes: ['%APPDATA%\\Spotify\\Spotify.exe'], reg: /^spotify/i, appx: /Spotify/i },
  { id: 'applemusic', name: 'Apple Music', color: '#fa2d48', exes: [], reg: /^apple music/i, appx: /AppleMusic/i },
  { id: 'itunes', name: 'iTunes', color: '#ea4cc0', exes: ['%ProgramFiles%\\iTunes\\iTunes.exe'], reg: /^itunes$/i, appx: /iTunes/i },
  { id: 'soundcloud', name: 'SoundCloud', color: '#ff5500', exes: [], reg: /^soundcloud/i, appx: /SoundCloud/i },
  { id: 'ytmusic', name: 'YouTube Music', color: '#ff0033', exes: [], reg: /youtube music/i, appx: /YouTubeMusic/i },
  { id: 'tidal', name: 'TIDAL', color: '#00ffff', exes: ['%LOCALAPPDATA%\\TIDAL\\TIDAL.exe'], reg: /^tidal/i, appx: /TIDAL/i },
  { id: 'deezer', name: 'Deezer', color: '#a238ff', exes: [], reg: /^deezer/i, appx: /Deezer/i },
  { id: 'amazonmusic', name: 'Amazon Music', color: '#25d1da', exes: ['%LOCALAPPDATA%\\Amazon Music\\Amazon Music.exe'], reg: /^amazon music/i, appx: /AmazonMusic|Amazon\.Music/i },
  { id: 'vlc', name: 'VLC', color: '#ff8800', exes: ['%ProgramFiles%\\VideoLAN\\VLC\\vlc.exe', '%ProgramFiles(x86)%\\VideoLAN\\VLC\\vlc.exe'], reg: /^vlc media player/i },
  { id: 'foobar', name: 'foobar2000', color: '#9aa4b5', exes: ['%ProgramFiles%\\foobar2000\\foobar2000.exe', '%ProgramFiles(x86)%\\foobar2000\\foobar2000.exe'], reg: /^foobar2000/i },
  { id: 'musicbee', name: 'MusicBee', color: '#f5b400', exes: ['%ProgramFiles(x86)%\\MusicBee\\MusicBee.exe', '%ProgramFiles%\\MusicBee\\MusicBee.exe'], reg: /^musicbee/i },
  { id: 'aimp', name: 'AIMP', color: '#3aa0ff', exes: ['%ProgramFiles%\\AIMP\\AIMP.exe'], reg: /^aimp/i },
  { id: 'winamp', name: 'Winamp', color: '#f0c020', exes: ['%ProgramFiles%\\Winamp\\winamp.exe', '%ProgramFiles(x86)%\\Winamp\\winamp.exe'], reg: /^winamp/i },
  { id: 'wmp', name: 'Media Player', color: '#4da3ff', exes: [], appx: /ZuneMusic|MediaPlayer/i },
];

/** Friendly name for a Windows media-session source id. */
function friendly(src) {
  const s = String(src || '');
  const rules = [[/spotify/i, 'Spotify'], [/applemusic|apple\.?music|itunes/i, 'Apple Music'], [/soundcloud/i, 'SoundCloud'], [/youtube.?music|ytmusic/i, 'YouTube Music'],
    [/tidal/i, 'TIDAL'], [/deezer/i, 'Deezer'], [/amazon.*music/i, 'Amazon Music'], [/vlc/i, 'VLC'], [/foobar/i, 'foobar2000'], [/musicbee/i, 'MusicBee'], [/aimp/i, 'AIMP'],
    [/winamp/i, 'Winamp'], [/zune|mediaplayer|microsoft\.media/i, 'Media Player'],
    [/chrome/i, 'Chrome'], [/msedge|edge/i, 'Edge'], [/firefox/i, 'Firefox'], [/brave/i, 'Brave'], [/opera/i, 'Opera'], [/vivaldi/i, 'Vivaldi']];
  for (const [re, n] of rules) if (re.test(s)) return n;
  return s.replace(/\.exe$/i, '').replace(/!.*$/, '').split(/[._]/).filter(Boolean).pop() || 'Media';
}
const isBrowser = (src) => /chrome|msedge|edge|firefox|brave|opera|vivaldi/i.test(String(src || ''));

const PREAMBLE = `
$ErrorActionPreference='SilentlyContinue'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1' })[0]
function Await($op, $t) { $m = $asTask.MakeGenericMethod($t); $n = $m.Invoke($null, @($op)); $n.Wait(-1) | Out-Null; $n.Result }
[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType=WindowsRuntime] | Out-Null
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
`;
const POLL = PREAMBLE + `
[Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType=WindowsRuntime] | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$sent = @{}
function Get-Thumb($p) {
  try {
    if (-not $p.Thumbnail) { return $null }
    $st = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
    if (-not $st -or $st.Size -le 0 -or $st.Size -gt 4000000) { return $null }
    $net = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st)
    $ms = New-Object System.IO.MemoryStream
    $net.CopyTo($ms)
    return [Convert]::ToBase64String($ms.ToArray())
  } catch { $script:terr = $_.Exception.Message; return $null }
}
while ($true) {
  $out = @()
  try {
    foreach ($s in $mgr.GetSessions()) {
      $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
      $pb = $s.GetPlaybackInfo()
      $key = $s.SourceAppUserModelId + '|' + $p.Title + '|' + $p.Artist
      $thumb = $null
      if ($p.Title -and $sent[$key] -lt 4 -and $sent[$key] -ne -1) {
        $thumb = Get-Thumb $p
        if ($thumb) { $sent[$key] = -1 } else { $sent[$key] = [int]$sent[$key] + 1 }
      }
      $out += [pscustomobject]@{ app = $s.SourceAppUserModelId; title = $p.Title; artist = $p.Artist; album = $p.AlbumTitle; status = $pb.PlaybackStatus.ToString(); thumb = $thumb; terr = $script:terr }
    }
  } catch {}
  [Console]::Out.WriteLine((ConvertTo-Json -Compress -InputObject @($out)))
  [Console]::Out.Flush()
  Start-Sleep -Milliseconds 2000
}`;
const CONTROL = (app, action) => PREAMBLE + `
$target = '${String(app).replace(/'/g, "''")}'
$s = $null
foreach ($x in $mgr.GetSessions()) { if ($x.SourceAppUserModelId -eq $target) { $s = $x } }
if (-not $s) { $s = $mgr.GetCurrentSession() }
if ($s) { switch ('${action}') {
  'toggle' { Await ($s.TryTogglePlayPauseAsync()) ([bool]) | Out-Null }
  'next' { Await ($s.TrySkipNextAsync()) ([bool]) | Out-Null }
  'prev' { Await ($s.TrySkipPreviousAsync()) ([bool]) | Out-Null }
} }`;
const enc = (s) => Buffer.from(s, 'utf16le').toString('base64');

class Music extends EventEmitter {
  constructor({ getSettings }) {
    super(); this.getSettings = getSettings; this.now = []; this.proc = null; this.installed = []; this._last = ''; this.thumbs = new Map(); this.tried = new Set(); this.diag = { fromApp: 0, fromLookup: 0, lastError: '' };
  }
  get available() { return isWin; }

  start() {
    if (!isWin || this.proc) return;
    try {
      const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', enc(POLL)], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
      this.proc = p; let buf = '';
      p.stdout.setEncoding('utf8');
      p.stdout.setEncoding('utf8');
      p.stdout.on('data', (d) => {
        buf += d; let i;
        while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (line) this._ingest(line); }
      });
      p.on('exit', () => { this.proc = null; if (this._want) setTimeout(() => this._want && this.start(), 5000); });
      p.on('error', () => { this.proc = null; });
      this._want = true;
    } catch (_) { this.proc = null; }
  }
  stop() { this._want = false; if (this.proc) { try { this.proc.kill(); } catch (_) { /* ignore */ } this.proc = null; } if (this.now.length) { this.now = []; this.emit('change', this.now); } }

  /** Shrink cover art to a small JPEG data URL so it is cheap to send to the window. */
  _shrink(b64) {
    try {
      const { nativeImage } = require('electron');
      const img = nativeImage.createFromBuffer(Buffer.from(b64, 'base64'));
      if (img.isEmpty()) return null;
      const { width } = img.getSize();
      const small = width > 220 ? img.resize({ width: 220, quality: 'good' }) : img;
      return 'data:image/jpeg;base64,' + small.toJPEG(82).toString('base64');
    } catch (_) {
      // Not running inside Electron (tests): keep it only if it is already small.
      return b64.length < 160000 ? 'data:image/png;base64,' + b64 : null;
    }
  }

  _put(key, t) { this.thumbs.set(key, t); if (this.thumbs.size > 60) this.thumbs.delete(this.thumbs.keys().next().value); }

  /** Re-attach cached art to the current list and tell the window if anything changed. */
  _refresh() {
    let changed = false;
    for (const it of this.now) { const t = this.thumbs.get(`${it.appId}|${it.title}|${it.artist}`) || null; if (t !== it.thumb) { it.thumb = t; changed = true; } }
    if (changed) { this._last = JSON.stringify(this.now); this.emit('change', this.now); }
  }

  /** HTTPS GET -> Buffer (overridable in tests). */
  fetchBuf(url) {
    return new Promise((resolve, reject) => {
      const req = require('https').get(url, { headers: { 'User-Agent': 'PLAYNEX' }, timeout: 8000 }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(this.fetchBuf(res.headers.location)); }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        const parts = []; let n = 0;
        res.on('data', (c) => { n += c.length; if (n > 3e6) { req.destroy(); reject(new Error('too large')); } else parts.push(c); });
        res.on('end', () => resolve(Buffer.concat(parts)));
      });
      req.on('timeout', () => req.destroy(new Error('timeout'))); req.on('error', reject);
    });
  }

  /** Fallback when the player gives no cover: look the song up in Apple's public iTunes Search (no account needed). */
  async _lookup(key, title, artist) {
    const st = this.getSettings();
    if (st.musicArtLookup === false || this.tried.has(key) || !title || !artist) return;
    this.tried.add(key); if (this.tried.size > 200) this.tried.delete(this.tried.values().next().value);
    try {
      const q = encodeURIComponent(`${artist} ${title}`.replace(/\s*[\(\[].*?[\)\]]/g, '').slice(0, 120));
      const j = JSON.parse((await this.fetchBuf(`https://itunes.apple.com/search?term=${q}&media=music&entity=song&limit=5`)).toString('utf8'));
      const norm = (x) => String(x || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
      const t = norm(title), a = norm(artist);
      const hit = (j.results || []).find((r) => norm(r.trackName).includes(t.split(' - ')[0]) && (norm(r.artistName).includes(a.split(' ')[0]) || a.includes(norm(r.artistName).split(' ')[0]))) || null;
      if (!hit || !hit.artworkUrl100) return;
      const img = await this.fetchBuf(hit.artworkUrl100.replace(/\d+x\d+bb/, '300x300bb'));
      const data = this._shrink(img.toString('base64')); if (!data) return;
      this._put(key, data); this.diag.fromLookup++; this._refresh();
    } catch (e) { this.diag.lastError = 'art lookup: ' + String(e && e.message || e).slice(0, 100); }
  }

  _ingest(line) {
    let arr; try { arr = JSON.parse(line); } catch (_) { return; }
    if (!Array.isArray(arr)) arr = [arr];
    const st = this.getSettings();
    const list = arr.filter((s) => s && (s.title || s.artist)).map((s) => {
      const key = `${s.app}|${s.title || ''}|${s.artist || ''}`;
      if (s.terr) this.diag.lastError = String(s.terr).slice(0, 160);
      if (s.thumb) { const t = this._shrink(s.thumb); if (t) { this._put(key, t); this.diag.fromApp++; } }
      return { appId: s.app, app: friendly(s.app), browser: isBrowser(s.app), title: s.title || '', artist: s.artist || '', album: s.album || '', status: s.status === 'Playing' ? 'playing' : 'paused', thumb: this.thumbs.get(key) || null };
    }).filter((s) => st.musicBrowser !== false || !s.browser);
    for (const it of list) if (!it.thumb) this._lookup(`${it.appId}|${it.title}|${it.artist}`, it.title, it.artist);
    list.sort((a, b) => (a.status === 'playing' ? 0 : 1) - (b.status === 'playing' ? 0 : 1));
    const key = JSON.stringify(list);
    if (key !== this._last) { this._last = key; this.now = list; this.emit('change', list); }
  }

  control(action, appId) {
    if (!isWin || !['toggle', 'next', 'prev'].includes(action)) return false;
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', enc(CONTROL(appId || '', action))], { windowsHide: true, timeout: 8000 }, () => {});
    return true;
  }

  /** Find installed music apps. Slow-ish (registry + Store), so the result is cached by the caller. */
  async detect() {
    if (!isWin) { this.installed = []; return this.installed; }
    const found = new Map();
    const add = (k, extra) => found.set(k.id, { id: k.id, name: k.name, color: k.color, ...(found.get(k.id) || {}), ...extra });
    for (const k of KNOWN) for (const e of k.exes) { const p = env(e); if (p && fs.existsSync(p)) { add(k, { exe: p }); break; } }
    try {
      const rows = [...(await C.regQueryBoth('HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall')), ...(await C.regQuery('HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall', ''))];
      for (const r of rows) {
        const name = r.values.DisplayName; if (!name) continue;
        const k = KNOWN.find((x) => x.reg && x.reg.test(name)); if (!k) continue;
        let exe = null; const ico = (r.values.DisplayIcon || '').replace(/^"|"$/g, '').split(',')[0];
        if (/\.exe$/i.test(ico) && fs.existsSync(ico)) exe = ico;
        add(k, exe ? { exe } : {});
      }
    } catch (_) { /* ignore */ }
    try {
      const pk = await new Promise((res) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "Get-AppxPackage | Where-Object { $_.Name -match 'Spotify|AppleMusic|iTunes|ZuneMusic|MediaPlayer|TIDAL|Deezer|AmazonMusic|SoundCloud|YouTubeMusic' } | ForEach-Object { $_.Name + '|' + $_.PackageFamilyName } "], { windowsHide: true, timeout: 20000 }, (e, out) => res(String(out || ''))));
      for (const line of pk.split(/\r?\n/)) {
        const [name, pfn] = line.trim().split('|'); if (!name || !pfn) continue;
        const k = KNOWN.find((x) => x.appx && x.appx.test(name)); if (k) add(k, { aumid: pfn + '!App' });
      }
    } catch (_) { /* ignore */ }
    this.installed = [...found.values()].filter((a) => a.exe || a.aumid).sort((a, b) => a.name.localeCompare(b.name));
    return this.installed;
  }

  launch(app) {
    try {
      if (app.aumid) spawn('explorer.exe', [`shell:AppsFolder\\${app.aumid}`], { detached: true, stdio: 'ignore' }).unref();
      else if (app.exe) spawn(app.exe, [], { cwd: path.dirname(app.exe), detached: true, stdio: 'ignore' }).unref();
      else return false;
      return true;
    } catch (_) { return false; }
  }
}

module.exports = { Music, friendly, KNOWN };
