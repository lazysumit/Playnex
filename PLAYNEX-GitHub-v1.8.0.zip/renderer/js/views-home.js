'use strict';
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;

  /** Poster card used in rails and the library grid. `row` keeps focus keys unique per rail. */
  GL.card = (g, row = 'c') => {
    const running = GL.isRunning(g.id);
    return `<button class="card${running ? ' live' : ''}" data-act="open" data-id="${esc(g.id)}" data-game="${esc(g.id)}" data-focus data-k="${row}-${esc(g.id)}" aria-label="${esc(g.title)}">
      ${GL.cover(g)}
      ${g.favorite ? `<span class="fav-b">${icon('starFill')}</span>` : ''}
      ${running ? '<span class="live-b">Playing</span>' : ''}
      <span class="cap"><b>${esc(g.title)}</b></span>
    </button>`;
  };

  const todaySec = () => { const t0 = GL.dayStart(Date.now()); return GL.S.sessions.filter((s) => s.start >= t0).reduce((a, s) => a + s.duration, 0); };
  const weekSec = () => { const t0 = GL.dayStart(Date.now()) - 6 * 86400000; return GL.S.sessions.filter((s) => s.start >= t0).reduce((a, s) => a + s.duration, 0); };

  function heroHtml(g) {
    if (!g) return '';
    const logo = GL.art(g, 'logo');
    const desc = (g.meta && g.meta.description) || '';
    const run = GL.isRunning(g.id);
    return `<div class="hi-logo">${logo ? `<img src="${esc(logo)}" alt="">` : ''}<h1>${esc(g.title)}</h1></div>
      <div class="hi-meta">${GL.pill(g.platform)}${run ? '<span class="chip live">Playing now</span>' : ''}
        <span class="chip">${icon('clock')}${g.playtime ? GL.dur(g.playtime) + ' played' : 'Not played yet'}</span>
        <span class="chip">${g.lastPlayed ? 'Last played ' + GL.ago(g.lastPlayed).toLowerCase() : 'Never launched'}</span></div>
      ${desc ? `<p class="hi-desc">${esc(desc)}</p>` : ''}
      <div class="hi-actions">
        <button class="btn primary big" data-act="launch" data-id="${esc(g.id)}" data-focus data-k="hero-play">${icon('play')}${run ? 'Running' : g.playtime ? 'Play' : 'Start'}</button>
        <button class="btn big" data-act="open" data-id="${esc(g.id)}" data-focus data-k="hero-open">Game details</button>
        <button class="btn icon" data-act="fav" data-id="${esc(g.id)}" data-focus data-k="hero-fav" aria-label="${g.favorite ? 'Remove from favourites' : 'Add to favourites'}">${icon(g.favorite ? 'starFill' : 'star')}</button>
      </div>`;
  }

  function empty() {
    const S = GL.S; const scanning = S.scan && S.scan.state !== 'done';
    return `<section class="empty-home">
      <div class="eh-art">${icon('gamepad')}</div>
      <h1>${scanning ? 'Looking for your games…' : 'Your library is empty'}</h1>
      <p>${scanning ? 'This only takes a moment. Games from Steam, Epic, Xbox, Ubisoft, EA, Battle.net, GOG, Riot and Rockstar show up here automatically.' : 'Scan this PC for installed games, point to a folder that holds games, or add a single program yourself.'}</p>
      <div class="hi-actions"><button class="btn primary big" data-act="scan" data-focus data-k="e-scan">${icon('refresh')}Scan for games</button>
        <button class="btn big" data-act="scanfolder" data-focus data-k="e-folder">${icon('folder')}Scan a folder</button>
        <button class="btn big" data-act="addgame" data-focus data-k="e-add">${icon('plus')}Add a game</button></div>
    </section>`;
  }

  GL.setHero = (id, force = false) => {
    const S = GL.S; const g = S.games[id]; if (!g || (S.heroId === id && !force)) return;
    S.heroId = id;
    const hi = document.getElementById('heroInfo');
    if (hi) { hi.innerHTML = heroHtml(g); hi.classList.remove('swap'); void hi.offsetWidth; hi.classList.add('swap'); }
    document.querySelectorAll('.tile.on').forEach((t) => t.classList.remove('on'));
    const t = document.querySelector(`.tile[data-id="${CSS.escape(id)}"]`); t && t.classList.add('on');
    GL.refreshBg();
  };

  /* ---- shelves: switch what the icon row shows (Continue, Most played, ...) ---- */
  function shelfDefs() {
    const S = GL.S;
    const defs = [
      { id: 'recent', label: 'Continue', list: GL.byRecent(30) },
      { id: 'fav', label: 'Favourites', list: GL.favorites().slice(0, 30) },
      { id: 'top', label: 'Most played', list: GL.mostPlayed(30) },
      { id: 'new', label: 'Recently added', list: GL.newest(30) },
    ];
    S.collections.forEach((c) => defs.push({ id: 'col:' + c.id, label: c.name, list: c.gameIds.map((id) => S.games[id]).filter((g) => g && g.installed !== false && !g.hidden) }));
    return defs.filter((d) => d.list.length);
  }
  const curShelf = (defs) => defs.find((d) => d.id === GL.S.homeShelf) || defs[0];

  const tilesHtml = (def) => def.list.map((g) => `<button class="tile${GL.S.heroId === g.id ? ' on' : ''}${GL.isRunning(g.id) ? ' live' : ''}" role="listitem" data-id="${esc(g.id)}" data-hero data-game="${esc(g.id)}" data-act="open" data-focus data-k="tile-${esc(def.id)}-${esc(g.id)}" aria-label="${esc(g.title)}">${GL.square(g)}<span class="t-name">${esc(g.title)}</span></button>`).join('') +
    `<button class="tile more" data-act="nav" data-view="library" data-focus data-k="tile-all" aria-label="Open library"><span class="cover square more-c">${icon('library')}</span><span class="t-name">Library</span></button>`;
  const chipsHtml = (defs, cur) => defs.map((d) => `<button class="shelf${d.id === cur.id ? ' on' : ''}" data-act="shelf" data-v="${esc(d.id)}" data-focus data-k="sh-${esc(d.id)}">${esc(d.label)}<em>${d.list.length}</em></button>`).join('');

  GL.views.home = {
    html(S) {
      const all = GL.all();
      if (!all.length) return empty();
      const defs = shelfDefs(); const cur = curShelf(defs); S.homeShelf = cur.id;
      const hero = S.games[S.heroId] && !S.games[S.heroId].hidden && cur.list.includes(S.games[S.heroId]) ? S.games[S.heroId] : cur.list[0];
      S.heroId = hero.id;
      return `<section class="home2">
        <div class="h-top">
          <div class="tiles" id="tiles" role="list" aria-label="${esc(cur.label)}">${tilesHtml(cur)}</div>
          <div class="h-today" aria-label="Your day"><div><b>${GL.dur(todaySec(), true)}</b><span>today</span></div><div><b>${GL.dur(weekSec(), true)}</b><span>this week</span></div><div><b>${S.level ? 'Lv ' + S.level.level : '—'}</b><span>${esc(S.level ? S.level.title : '')}</span></div></div>
        </div>
        <div class="hero-info" id="heroInfo" aria-live="polite">${heroHtml(hero)}</div>
        <nav class="shelves" id="shelves" aria-label="Game shelves">${chipsHtml(defs, cur)}</nav>
      </section>`;
    },
  };

  GL.act.shelf = (d) => {
    const S = GL.S; if (S.homeShelf === d.v) return;
    S.homeShelf = d.v;
    const defs = shelfDefs(); const cur = curShelf(defs);
    document.getElementById('shelves').innerHTML = chipsHtml(defs, cur);
    const k = document.querySelector(`.shelf[data-v="${CSS.escape(cur.id)}"]`); k && k.focus({ preventScroll: true });
    const t = document.getElementById('tiles');
    t.setAttribute('aria-label', cur.label); t.innerHTML = tilesHtml(cur); t.scrollLeft = 0;
    GL.animate(t, 'rail-in');
    GL.setHero(cur.list[0].id, true);
  };

  GL.act.scanfolder = async () => { GL.S.scan = { state: 'start' }; const r = await window.api.invoke('library:scanFolder'); if (r && r.canceled) { GL.S.scan = null; document.getElementById('scanBar') && document.getElementById('scanBar').remove(); } };

  const onHero = (e) => {
    if (!GL.S || !GL.S.view || GL.S.view.name !== 'home') return;
    const t = e.target.closest && e.target.closest('[data-hero]');
    if (t && t.dataset.id !== GL.S.heroId) GL.setHero(t.dataset.id);
  };
  document.addEventListener('focusin', onHero);
  document.addEventListener('mouseover', onHero);
})();
