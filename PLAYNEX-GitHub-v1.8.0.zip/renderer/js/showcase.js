'use strict';
// Library showcase: after a period of inactivity on the Library page, cycle through full-screen game
// banners with a short "about" and short stats. Any mouse/keyboard/controller input brings the library back.
window.GL = window.GL || {};
(function () {
  const { esc } = GL;
  let startedAt = 0, sys = { sec: null, shown: true, focused: true }, sysBusy = false, lastPad = 0;
  let mode = 'library', el = null, active = false, forced = false, idx = 0, order = [], slideTimer = null, last = Date.now(), flip = false, lastPos = null;

  const cfg = () => (GL.S && GL.S.settings) || {};
  const libDelay = () => { const s = cfg(); return s.showcaseEnabled === false ? 0 : Math.max(0, Number(s.showcaseDelay) || 0) * 1000; };
  const saverDelay = () => { const s = cfg(); return s.saverEnabled === false ? 0 : Math.max(10, Number(s.saverDelay) || 60) * 1000; };
  const slideMs = () => { const s = cfg(); return Math.max(4, Number(mode === 'saver' ? s.saverSlide : s.showcaseSlide) || 8) * 1000; };
  const eligible = () => GL.all().filter((g) => GL.art(g, 'banner') || GL.art(g, 'cover'));
  /** The playlist: game banners, online wallpapers, or both (alternating). Online ones are only placeholders here: each is fetched one at a time, just before it is shown. */
  const WEB_SLOTS = 12;
  const slides = (m) => {
    const src = m === 'saver' ? (cfg().saverSource || 'games') : 'games';
    const games = shuffle(eligible().map((g) => ({ g })));
    if (src === 'games') return games;
    const web = (n) => Array.from({ length: n }, () => ({ web: true }));
    if (src === 'web') return web(WEB_SLOTS);
    if (!games.length) return web(WEB_SLOTS);
    const out = []; games.forEach((x) => out.push(x, { web: true })); return out;   // mix: a game, then a wallpaper
  };
  const wantsWeb = () => order.some((x) => x.web);
  const shuffle = (a) => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
  const clip = (t, n) => { t = String(t || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1).replace(/[ ,.;:]+\S*$/, '') + '…' : t; };

  function ensure() {
    if (el) return el;
    el = document.createElement('div'); el.id = 'showcase'; el.setAttribute('aria-hidden', 'true');
    el.innerHTML = '<div class="sc-bg" id="scA"></div><div class="sc-bg" id="scB"></div><div class="sc-shade"></div><div class="sc-info" id="scInfo"></div><div class="sc-clock" id="scClock"><div class="sc-time"></div><div class="sc-date"></div></div><div class="sc-music" id="scMusic"></div><div class="sc-hint">Move the mouse or press any key to return</div>';
    document.body.appendChild(el);
    return el;
  }

  function stats(g) {
    const ses = GL.S.sessions.filter((s) => s.gameId === g.id);
    const out = [];
    out.push(['Played', g.playtime ? GL.dur(g.playtime, true) : 'Not yet']);
    out.push(['Last played', g.lastPlayed ? GL.ago(g.lastPlayed) : 'Never']);
    if (ses.length) out.push(['Sessions', String(ses.length)]);
    const m = g.meta || {};
    if (m.metacritic) out.push(['Score', String(m.metacritic)]);
    return out;
  }

  let curWeb = false;
  function showGame(g) {
    curWeb = false;
    const url = GL.art(g, 'banner') || GL.art(g, 'cover');
    const a = document.getElementById(flip ? 'scA' : 'scB'), b = document.getElementById(flip ? 'scB' : 'scA');
    flip = !flip;
    a.style.backgroundImage = url ? `url("${url}")` : 'none';
    a.classList.remove('kb'); void a.offsetWidth; a.classList.add('on', 'kb'); b.classList.remove('on');
    const logo = GL.art(g, 'logo'); const m = g.meta || {};
    const about = clip(m.description || m.about, 190);
    const genres = (m.genres || []).slice(0, 3);
    const info = document.getElementById('scInfo');
    info.innerHTML = `${logo ? `<img class="sc-logo" src="${esc(logo)}" alt="${esc(g.title)}">` : `<h2 class="sc-title">${esc(g.title)}</h2>`}
      ${genres.length ? `<div class="sc-genres">${genres.map((x) => `<span>${esc(x)}</span>`).join('')}</div>` : ''}
      ${about ? `<p class="sc-about">${esc(about)}</p>` : ''}
      <div class="sc-stats">${stats(g).map(([k, v]) => `<div><b>${esc(v)}</b><span>${esc(k)}</span></div>`).join('')}</div>`;
    info.classList.remove('web', 'swap'); void info.offsetWidth; info.classList.add('swap');
  }

  /** An online wallpaper: just the picture, with a small caption (title, source, size) unless turned off. */
  function showWeb(w) {
    curWeb = true;
    const a = document.getElementById(flip ? 'scA' : 'scB'), b = document.getElementById(flip ? 'scB' : 'scA');
    flip = !flip;
    a.style.backgroundImage = `url("${w.url}")`;
    a.classList.remove('kb'); void a.offsetWidth; a.classList.add('on', 'kb'); b.classList.remove('on');
    const info = document.getElementById('scInfo');
    info.innerHTML = cfg().saverWebCaption === false ? '' : `<div class="scw"><small>${esc(w.sourceName)} · ${esc(w.topic)}</small><h2>${esc(w.title)}</h2><span>${w.w} × ${w.h} <i>·</i> ${esc(w.quality)}</span></div>`;
    info.classList.add('web'); info.classList.remove('swap'); void info.offsetWidth; info.classList.add('swap');
  }
  const show = (x) => (x.w ? showWeb(x.w) : showGame(x.g));

  /* One online picture at a time: one is always being fetched ahead while the current one is on screen. */
  let webQueue = [], prefetching = null, advancing = false;
  function prefetchWeb() {
    if (prefetching || webQueue.length) return prefetching;
    prefetching = window.api.invoke('wall:next').then((w) => { prefetching = null; if (w && active) webQueue.push(w); return w; }).catch(() => { prefetching = null; return null; });
    return prefetching;
  }
  async function takeWeb() {
    if (!webQueue.length) await Promise.race([prefetchWeb(), new Promise((r) => setTimeout(r, 20000))]);
    return webQueue.shift() || null;
  }
  async function advance() {
    if (!active || !order.length || advancing) return; advancing = true;
    try {
      for (let tries = 0; tries < order.length && active; tries++) {
        idx = (idx + 1) % order.length; const x = order[idx];
        if (!x.web) { show(x); return; }
        const w = await takeWeb();
        if (w && active) { showWeb(w); prefetchWeb(); return; }
      }
      if (active && !document.getElementById('scA').classList.contains('on') && !document.getElementById('scB').classList.contains('on')) { const g = eligible()[0]; if (g) showGame(g); }   // offline and nothing shown yet
    } finally { advancing = false; }
  }

  const next = () => { advance(); };

  /** Now-playing card: shown while a song is playing, in the corner chosen in Settings. */
  function tickMusic() {
    const m = document.getElementById('scMusic'); if (!m) return;
    const st = cfg(), list = (GL.S && GL.S.music && GL.S.music.now) || [];
    const cur = list.find((x) => x.status === 'playing');
    const pos = st.saverMusicPos || 'bottom-right';
    m.dataset.pos = pos;
    m.style.setProperty('--ms', String(Math.max(0.6, Math.min(2, (Number(st.saverMusicSize) || 100) / 100))));
    // keep clear of the clock / library info / hint that may sit in the same corner
    let off = 0; const clock = document.getElementById('scClock'), info = document.getElementById('scInfo');
    if (mode === 'saver' && clock && !clock.hidden && (clock.dataset.pos || 'top-right') === pos) off = clock.offsetHeight + 22;
    if (mode === 'library' && /^bottom/.test(pos)) off = pos === 'bottom-left' ? (info ? info.offsetHeight : 0) + window.innerHeight * 0.06 + 24 : 44;
    if (mode === 'saver' && curWeb && st.saverWebCaption !== false && pos === 'bottom-left') off = (info ? info.offsetHeight : 0) + window.innerHeight * 0.07 + 24;
    m.style.setProperty('--off', off + 'px');
    const on = st.saverMusic !== false && st.musicEnabled !== false && !!cur;
    const key = on ? `${cur.appId}|${cur.title}|${cur.artist}|${cur.thumb ? 1 : 0}` : '';
    if (!on) { m.classList.remove('show'); m.dataset.key = ''; return; }
    if (m.dataset.key !== key) {
      m.dataset.key = key; m.classList.remove('show');
      m.innerHTML = `<div class="scm-art">${cur.thumb ? `<img src="${cur.thumb}" alt="">` : '<span class="eq"><i></i><i></i><i></i><i></i></span>'}</div>
        <div class="scm-t"><small><span class="eq mini"><i></i><i></i><i></i><i></i></span>${esc(cur.app)}</small><b>${esc(cur.title)}</b>${cur.artist ? `<span>${esc(cur.artist)}</span>` : ''}</div>`;
      void m.offsetWidth;
    }
    m.classList.add('show');
  }
  let musicTimer = null;

  let clockTimer = null;
  const tickClock = () => {
    const c = document.getElementById('scClock'); if (!c) return;
    const st = cfg(), now = new Date();
    c.hidden = st.saverClock === false;
    c.dataset.pos = st.saverClockPos || 'top-right';
    c.style.setProperty('--sc-size', Math.max(24, Math.min(300, Number(st.saverClockSize) || 96)) + 'px');
    const fmt = st.saverClockFmt || 'auto';
    const opts = { hour: fmt === '24' ? '2-digit' : 'numeric', minute: '2-digit' };
    if (fmt !== 'auto') opts.hour12 = fmt === '12';
    c.querySelector('.sc-time').textContent = now.toLocaleTimeString([], opts).replace(/\s?(am|pm)$/i, (m) => m.toUpperCase());
    const d = c.querySelector('.sc-date'); d.hidden = st.saverDate === false;
    d.textContent = now.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
  };
  function start(force = false, m = 'library') {
    if (active) return; forced = !!force; mode = m;
    const list = slides(m); if (!list.length) return;
    startedAt = Date.now(); order = list; idx = -1; active = true; flip = false; lastPos = null; webQueue = []; advancing = false;
    ensure(); if (wantsWeb()) prefetchWeb(); advance();
    el.classList.toggle('saver', mode === 'saver'); document.body.classList.toggle('in-saver', mode === 'saver');
    if (mode === 'saver') { tickClock(); clearInterval(clockTimer); clockTimer = setInterval(tickClock, 1000); try { window.api.invoke('app:screensaver', true); } catch (_) { /* ignore */ } }
    tickMusic(); clearInterval(musicTimer); musicTimer = setInterval(tickMusic, 1000);
    requestAnimationFrame(() => el.classList.add('on'));
    document.body.classList.add('in-showcase');
    clearInterval(slideTimer); slideTimer = setInterval(next, slideMs());
  }

  function stop(keepIdle) {
    if (!active) return; active = false; webQueue = [];
    clearInterval(slideTimer); slideTimer = null; clearInterval(clockTimer); clockTimer = null; clearInterval(musicTimer); musicTimer = null;
    el && el.classList.remove('on'); document.body.classList.remove('in-showcase', 'in-saver');
    if (mode === 'saver') { try { window.api.invoke('app:screensaver', false); } catch (_) { /* ignore */ } }
    if (!keepIdle) { last = Date.now(); if (typeof sys.sec === 'number') sys.sec = 0; }
  }

  const poke = () => { last = Date.now(); if (typeof sys.sec === 'number') sys.sec = 0; };
  const onAny = (e) => {
    if (e.type === 'mousemove') { // ignore tiny jitter
      const p = [e.clientX, e.clientY];
      if (!lastPos) { lastPos = p; if (!active) return; return; }
      if (Math.abs(p[0] - lastPos[0]) + Math.abs(p[1] - lastPos[1]) < 6) return;
      lastPos = p;
    }
    if (active && !forced && Date.now() - startedAt < 900) return; // ignore the synthetic mouse move Windows sends when entering full screen
    if (active) { stop(); if (e.type === 'keydown' || e.type === 'mousedown') { e.stopPropagation(); e.preventDefault(); } } else poke();
  };
  ['mousemove', 'mousedown', 'wheel', 'touchstart'].forEach((t) => document.addEventListener(t, onAny, true));
  document.addEventListener('keydown', onAny, true);

  // Controller activity (not seen by the OS idle timer). Buttons or a firm stick push only, so drift is ignored.
  let padSig = '';
  function padActivity() {
    try {
      const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
      const sig = pads.map((p) => p.buttons.map((b) => (b.pressed ? 1 : 0)).join('') + p.axes.map((a) => (Math.abs(a) > 0.8 ? 1 : 0)).join('')).join('|');
      if (sig !== padSig) { padSig = sig; if (/1/.test(sig)) { lastPad = Date.now(); if (active) stop(); else poke(); } }
    } catch (_) { /* no gamepad API */ }
  }

  // Idle = the shorter of: OS keyboard/mouse idle, time since controller input. Falls back to page events if the OS timer is unavailable.
  function pollSys() {
    if (sysBusy || !window.api) return; sysBusy = true;
    Promise.resolve(window.api.invoke('app:idle')).then((r) => { if (r && typeof r === 'object') sys = r; }).catch(() => {}).finally(() => { sysBusy = false; });
  }
  const idleMs = () => {
    const page = Date.now() - last;
    if (typeof sys.sec !== 'number') return page;
    return Math.min(sys.sec * 1000, lastPad ? Date.now() - lastPad : Infinity);
  };

  setInterval(() => {
    padActivity(); pollSys();
    const S = GL.S; const idle = idleMs();
    const calm = !!(S && S.view && document.getElementById('overlay').hidden && !document.hidden && sys.shown !== false);
    const playing = !!(S && S.running && Object.keys(S.running).some((id) => { const g = S.games[id]; return g && g.installed !== false && !g.hidden && !g.notGame; }));
    if (active) {
      if (forced) return;
      if (mode === 'saver') { if (!calm || playing || saverDelay() <= 0) stop(); return; }
      const sd0 = saverDelay();
      if (!calm || playing) { stop(); return; }
      if (sd0 > 0 && idle >= sd0) { stop(true); start(false, 'saver'); return; } // library slideshow hands over to the screensaver
      if (S.view.name !== 'library' || libDelay() <= 0) stop();
      return;
    }
    if (!calm || playing) return;
    const sd = saverDelay(), ld = S.view.name === 'library' ? libDelay() : 0;
    if (sd > 0 && idle >= sd) start(false, 'saver');
    else if (ld > 0 && idle >= ld) start(false, 'library');
  }, 500);
  // leaving or entering the Library counts as activity
  const origGo = GL.go; GL.go = function (...a) { poke(); if (active) stop(); return origGo.apply(this, a); };

  GL.showcase = { start, stop, get active() { return active; }, poke };
})();
