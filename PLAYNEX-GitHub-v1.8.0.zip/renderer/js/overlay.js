'use strict';
(function () {
  const ov = window.ov; const root = document.getElementById('ov');
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const I = {
    x: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    prev: '<svg viewBox="0 0 24 24"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg>', next: '<svg viewBox="0 0 24 24"><path d="M16 5h2v14h-2zM4 5v14l11-7z"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4.500v15l13-7.500z"/></svg>', pause: '<svg viewBox="0 0 24 24"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
    note: '<svg viewBox="0 0 24 24"><path d="M9 18V6l11-2v12"/><circle cx="6.500" cy="18" r="2.500"/><circle cx="17.500" cy="16" r="2.500"/></svg>',
    vdn: '<svg viewBox="0 0 24 24"><path d="M4 9.500h3.500L12 6v12l-4.500-3.500H4zM16 10.500a3 3 0 0 1 0 3"/></svg>', vup: '<svg viewBox="0 0 24 24"><path d="M4 9.500h3.500L12 6v12l-4.500-3.500H4zM16 9a4 4 0 0 1 0 6M18.500 6.500a8 8 0 0 1 0 11"/></svg>', vmute: '<svg viewBox="0 0 24 24"><path d="M4 9.500h3.500L12 6v12l-4.500-3.500H4zM16 9.500l5 5M21 9.500l-5 5"/></svg>',
    cam: '<svg viewBox="0 0 24 24"><path d="M4 8h3l1.500-2h7L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.500"/></svg>', home: '<svg viewBox="0 0 24 24"><path d="M4 11l8-7 8 7v9h-5v-6H9v6H4z"/></svg>', stop: '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
  };
  let data = null, sig = '', timer = 0, armed = 0, open = false;
  const dur = (s) => { s = Math.max(0, Math.floor(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m ${String(s % 60).padStart(2, '0')}s`; };
  const clk = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const img = (u) => (u ? `style="background-image:url('${esc(u).replace(/'/g, '%27')}')"` : '');

  function pads() { return [...(navigator.getGamepads ? navigator.getGamepads() : [])].filter((p) => p && p.connected); }
  function render() {
    const d = data; if (!d) return;
    const g = d.running[0];
    const m = (d.music && d.music.find((x) => x.status === 'playing')) || (d.music && d.music[0]) || null;
    const ps = pads();
    const s = JSON.stringify([d.running.map((r) => r.id), d.recent, m && [m.appId, m.title, m.artist, m.status, !!m.thumb], ps.map((p) => p.id), d.accent, d.musicOn, armed]);
    if (s === sig) return; sig = s;
    document.documentElement.style.setProperty('--accent', d.accent || '#3d8bff');
    const musicCard = !d.musicOn ? '<p class="empty">Music detection is turned off in Settings → Music.</p>' : m ? `<div class="music"><div class="art" ${img(m.thumb)}>${m.thumb ? '' : I.note}</div><div class="meta"><small>${esc(m.app)}${m.status === 'playing' ? '' : ' · paused'}</small><strong>${esc(m.title)}</strong><span>${esc(m.artist || '')}</span>
        <div class="ctl"><button class="rb" data-a="prev" aria-label="Previous">${I.prev}</button><button class="rb big" data-a="toggle" aria-label="Play or pause">${m.status === 'playing' ? I.pause : I.play}</button><button class="rb" data-a="next" aria-label="Next">${I.next}</button>
        <div class="vol"><button class="rb" data-v="down" aria-label="Volume down">${I.vdn}</button><button class="rb" data-v="mute" aria-label="Mute">${I.vmute}</button><button class="rb" data-v="up" aria-label="Volume up">${I.vup}</button></div></div></div></div>`
      : `<p class="empty">Nothing is playing. Start a song in Spotify, Apple Music or a browser and it will appear here with play, skip and volume controls.</p><div class="ctl"><div class="vol" style="margin-left:0"><button class="rb" data-v="down" aria-label="Volume down">${I.vdn}</button><button class="rb" data-v="mute" aria-label="Mute">${I.vmute}</button><button class="rb" data-v="up" aria-label="Volume up">${I.vup}</button></div></div>`;
    const gameCard = g ? `<div class="game"><div class="gc" ${img(g.cover)}></div><div><small>Playing now</small><b>${esc(g.title)}</b><div class="timer" id="sess">${dur((d.now - g.start) / 1000)}</div></div></div>
        <div class="acts">${d.capture ? `<button class="btn" data-a="capture">${I.cam}Screenshot</button>` : ''}<button class="btn" data-a="launcher">${I.home}Launcher</button><button class="btn danger wide${armed ? ' arm' : ''}" data-a="quit" data-id="${esc(g.id)}">${I.stop}${armed ? 'Click again to quit the game' : 'Quit game'}</button></div>`
      : `<p class="empty">No game is running right now.</p><div class="acts"><button class="btn wide" data-a="launcher">${I.home}Open launcher</button></div>`;
    const padCard = ps.length ? `<div class="pads">${ps.map((p, i) => `<div class="pad"><i></i><span>${esc(String(p.id).replace(/\s*\(.*?(vendor|product).*?\)\s*$/i, '').trim() || 'Controller')}</span></div>`).join('')}</div><p class="sub">Use the d-pad and A to click here, B to close.</p>` : '<p class="empty">No controller connected.</p>';
    const recent = d.recent.length ? `<div class="card"><h3>Jump back in</h3><div class="recent">${d.recent.map((r) => `<button class="rg" data-a="launch" data-id="${esc(r.id)}"><div class="gc" ${img(r.cover)}></div><span>${esc(r.title)}</span></button>`).join('')}</div></div>` : '';
    root.innerHTML = `<div class="wrap">
      <div class="top"><div class="brand"><div class="logo"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div>PLAYNEX</div>${g ? `<div class="now-game"><i></i><b>${esc(g.title)}</b></div>` : ''}<div class="sp"></div>
        <div class="meter" id="meter"></div><div class="clock" id="clk">${clk()}</div><button class="x" data-a="close" aria-label="Close overlay">${I.x}</button></div>
      <div class="grid"><div class="card"><h3>Now playing</h3>${musicCard}</div><div class="stack"><div class="card"><h3>${g ? 'Current game' : 'Game'}</h3>${gameCard}</div></div></div>
      <div class="row3"><div class="card"><h3>Today</h3><div class="big-n" id="today">${dur(d.today)}</div><div class="sub">Time played today</div></div><div class="card"><h3>Controllers</h3>${padCard}</div><div class="card"><h3>Shortcut</h3><div class="big-n" style="font-size:22px"><kbd>${esc(d.key)}</kbd></div><div class="sub">Press it again, or Esc, to close</div></div></div>
      ${recent}<div class="hint">Games in exclusive full-screen can hide this panel. Switch the game to borderless or windowed.</div></div>`;
    live();
  }
  function live() {
    const d = data; if (!d) return;
    const c = document.getElementById('clk'); if (c) c.textContent = clk();
    const g = d.running[0], se = document.getElementById('sess'); if (g && se) se.textContent = dur((Date.now() - g.start) / 1000);
    const mt = document.getElementById('meter'); if (mt) mt.innerHTML = `${d.sys.cpu == null ? '' : `<span>CPU <b>${d.sys.cpu}%</b></span>`}<span>RAM <b>${d.sys.mem}%</b></span>${d.sys.gpu == null ? '' : `<span>GPU <b>${d.sys.gpu}%</b></span>`}`;
    const t = document.getElementById('today'); if (t) t.textContent = dur(d.today + (g ? (Date.now() - d.now) / 1000 : 0));
  }
  async function pull() { try { data = await ov.invoke('overlay:state'); } catch (_) { return; } render(); live(); }

  function openIt() { open = true; armed = 0; sig = ''; document.body.classList.add('open'); pull(); clearInterval(timer); timer = setInterval(() => { pull(); }, 1000); setTimeout(() => { const b = root.querySelector('button[data-a]'); b && b.focus({ preventScroll: true }); }, 120); }
  function closeIt() { if (!open) return; open = false; document.body.classList.remove('open'); clearInterval(timer); }
  ov.on('overlay:open', openIt); ov.on('overlay:close', closeIt);
  const dismiss = () => { closeIt(); ov.invoke('overlay:close'); };

  document.addEventListener('click', (e) => {
    if (e.target.closest('#ov') && !e.target.closest('.card,.top,.hint') && !e.target.closest('button')) return dismiss();
    const b = e.target.closest('button'); if (!b) return;
    const a = b.dataset.a, v = b.dataset.v;
    if (v) return ov.invoke('overlay:action', 'volume', v);
    if (a === 'close') return dismiss();
    if (a === 'toggle' || a === 'next' || a === 'prev') { const m = data && data.music && (data.music.find((x) => x.status === 'playing') || data.music[0]); return ov.invoke('overlay:action', 'music', { cmd: a, appId: m && m.appId }).then(() => setTimeout(pull, 700)); }
    if (a === 'quit') { if (!armed) { armed = Date.now(); sig = ''; render(); setTimeout(() => { armed = 0; sig = ''; render(); }, 4000); return; } armed = 0; return ov.invoke('overlay:action', 'quit', b.dataset.id).then(() => setTimeout(pull, 1500)); }
    if (a === 'launch') return ov.invoke('overlay:action', 'launch', b.dataset.id);
    if (a === 'capture' || a === 'launcher') return ov.invoke('overlay:action', a);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') return dismiss();
    if (['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp'].includes(e.key)) { e.preventDefault(); step(e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : -1); }
  });
  function step(dir) {
    const list = [...root.querySelectorAll('button')]; if (!list.length) return;
    const i = list.indexOf(document.activeElement); list[(i + dir + list.length) % list.length].focus();
  }
  // Controller: d-pad moves, A clicks, B closes (this window is focused while open, so it receives pad input).
  const held = {}; let prevB = false;
  (function padLoop() {
    requestAnimationFrame(padLoop); if (!open) return;
    const p = pads()[0]; if (!p) return; const now = performance.now();
    const st = { n: p.buttons[13] && p.buttons[13].pressed || p.axes[1] > 0.6 || p.buttons[15] && p.buttons[15].pressed || p.axes[0] > 0.6, p: p.buttons[12] && p.buttons[12].pressed || p.axes[1] < -0.6 || p.buttons[14] && p.buttons[14].pressed || p.axes[0] < -0.6, a: p.buttons[0] && p.buttons[0].pressed, b: p.buttons[1] && p.buttons[1].pressed };
    for (const k of Object.keys(st)) { const h = held[k] || (held[k] = { d: false, t: 0 }); if (st[k]) { if (!h.d) { h.d = true; h.t = now + 400; fire(k); } else if ((k === 'n' || k === 'p') && now >= h.t) { h.t = now + 140; fire(k); } } else h.d = false; }
  })();
  function fire(k) { if (k === 'n') step(1); else if (k === 'p') step(-1); else if (k === 'a') { const el = document.activeElement; el && el.click && el.click(); } else if (k === 'b') dismiss(); }
})();
