'use strict';
// Controller test: one big controller picture plus live panels (sticks, triggers, raw data, vibration). P1-P4 switch between pads.
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;
  const api = window.api;
  let raf = 0, sig = '', sel = -1, ctx = null;
  const trails = {}; // per pad index -> {l:[], r:[]}
  const rumbleUntil = {}; // per pad index -> {strong, weak, until}

  const kind = (id) => (/054c|dualsense|dualshock|playstation|ps4|ps5/i.test(id) ? 'ps' : /057e|nintendo|switch|joy-?con/i.test(id) ? 'switch' : 'xbox');
  const LABELS = {
    xbox: { name: 'Xbox Controller', face: { a: 'A', b: 'B', x: 'X', y: 'Y' }, lb: 'LB', rb: 'RB', lt: 'LT / L2', rt: 'RT / R2' },
    ps: { name: 'PlayStation Controller', face: { a: '✕', b: '○', x: '□', y: '△' }, lb: 'L1', rb: 'R1', lt: 'L2', rt: 'R2' },
    switch: { name: 'Nintendo Controller', face: { a: 'B', b: 'A', x: 'Y', y: 'X' }, lb: 'L', rb: 'R', lt: 'ZL', rt: 'ZR' },
  };
  const rawId = (id) => String(id).replace(/\s*\((?=.*(?:vendor|product)).*?\)\s*$/i, '').trim() || 'Controller';
  const pads = () => [...(navigator.getGamepads ? navigator.getGamepads() : [])].filter((p) => p && p.connected);
  const names = () => (GL.S && GL.S.settings && GL.S.settings.padNames) || {};
  const pretty = (p) => names()[p.id] || LABELS[kind(p.id)].name;

  /* ------------------------------------------------------------------ controller picture */
  function diagram(p) {
    const L = LABELS[kind(p.id)];
    const face = (b, x, y, c) => `<g class="pb" data-b="${b}"><circle class="face ${c}" cx="${x}" cy="${y}" r="15"/><text x="${x}" y="${y + 5.500}" text-anchor="middle">${esc(L.face[c])}</text></g>`;
    return `<svg class="pad-svg" viewBox="0 0 560 410" aria-hidden="true">
      <defs>
        <linearGradient id="gBody" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b2c30"/><stop offset="1" stop-color="#1c1d20"/></linearGradient>
        <radialGradient id="gStick" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#6a6c72"/><stop offset="1" stop-color="#2c2d31"/></radialGradient>
      </defs>
      <g class="trg"><rect class="tr-base" x="112" y="14" width="64" height="62" rx="24"/><rect class="tr-fill" data-t="6" x="112" y="14" width="64" height="62" rx="24"/>
        <rect class="tr-base" x="384" y="14" width="64" height="62" rx="24"/><rect class="tr-fill" data-t="7" x="384" y="14" width="64" height="62" rx="24"/></g>
      <g class="pb bump" data-b="4"><rect x="96" y="82" width="96" height="26" rx="13"/><text x="144" y="100" text-anchor="middle">${esc(L.lb.split(' ')[0])}</text></g>
      <g class="pb bump" data-b="5"><rect x="368" y="82" width="96" height="26" rx="13"/><text x="416" y="100" text-anchor="middle">${esc(L.rb.split(' ')[0])}</text></g>
      <path class="body" d="M158 106 C 128 108 104 124 90 164 L 58 262 C 48 300 56 336 84 344 C 110 350 130 332 150 302 L 172 266 C 182 252 194 248 210 248 L 350 248 C 366 248 378 252 388 266 L 410 302 C 430 332 450 350 476 344 C 504 336 512 300 502 262 L 470 164 C 456 124 432 108 402 106 C 360 100 330 104 280 104 C 230 104 200 100 158 106 Z"/>
      <path class="body-hi" d="M158 112 C 130 114 110 128 98 166" />
      <g class="stk" data-s="l"><circle class="well" cx="172" cy="178" r="46"/><g class="knob-g" data-b="10"><circle class="knob" cx="172" cy="178" r="29"/><circle class="knob-in" cx="172" cy="178" r="19"/><circle class="knob-dot" cx="172" cy="178" r="4"/></g></g>
      <g class="stk" data-s="r"><circle class="well" cx="330" cy="280" r="46"/><g class="knob-g" data-b="11"><circle class="knob" cx="330" cy="280" r="29"/><circle class="knob-in" cx="330" cy="280" r="19"/><circle class="knob-dot" cx="330" cy="280" r="4"/></g></g>
      <circle class="abxy-ring" cx="394" cy="178" r="46"/>
      ${face(3, 394, 153, 'y')}${face(0, 394, 203, 'a')}${face(2, 369, 178, 'x')}${face(1, 419, 178, 'b')}
      <g class="pb guide" data-b="16"><circle cx="280" cy="136" r="19"/><path d="M270 127l20 18M290 127l-20 18" class="gx"/></g>
      <g class="pb small" data-b="8"><circle cx="238" cy="180" r="11"/><rect x="233" y="175" width="10" height="10" rx="2" class="gi"/></g>
      <g class="pb small" data-b="9"><circle cx="322" cy="180" r="11"/><path d="M316.500 176h11M316.500 180h11M316.500 184h11" class="gi"/></g>
      <g class="pb small share" data-b="17"><rect x="263" y="204" width="34" height="18" rx="9"/><path d="M280 217v-9m-4 4l4-4 4 4" class="gi"/></g>
      <g class="dpad">
        <rect class="dp-c" x="190" y="263" width="44" height="44" rx="6"/>
        <rect class="pb dp" data-b="12" x="200" y="246" width="24" height="30" rx="6"/><rect class="pb dp" data-b="13" x="200" y="294" width="24" height="30" rx="6"/>
        <rect class="pb dp" data-b="14" x="170" y="274" width="30" height="24" rx="6"/><rect class="pb dp" data-b="15" x="224" y="274" width="30" height="24" rx="6"/>
        <path class="dp-cross" d="M212 246v78M173 285h78"/>
      </g>
    </svg>`;
  }

  /* ------------------------------------------------------------------ panels */
  function head(cls, ic, title, sub, extra = '') {
    return `<div class="pn-h ${cls}"><span class="pn-i">${icon(ic)}</span><div><b>${esc(title)}</b><small>${esc(sub)}</small></div>${extra}</div>`;
  }
  function html(p, list) {
    const k = kind(p.id), L = LABELS[k];
    const tabs = [0, 1, 2, 3].map((n) => {
      const q = list.find((x) => x.index === n);
      return `<button class="ptab${q && q.index === p.index ? ' on' : ''}${q ? '' : ' off'}" ${q ? `data-act="padsel" data-i="${n}" data-focus data-k="pt-${n}"` : 'disabled'}>P${n + 1}<i class="${q ? 'live' : ''}"></i></button>`;
    }).join('');
    const axes = p.axes.map((_, n) => `<div class="axr"><span>${n}</span><div class="bar mid"><i data-ra="${n}"></i></div><em data-rv="${n}">+0.00</em></div>`).join('');
    const btns = p.buttons.map((_, n) => `<span class="bchip" data-rb="${n}">${n}</span>`).join('');
    const canRumble = !!(p.vibrationActuator || (p.hapticActuators && p.hapticActuators.length));
    const rb = (id, label, col, bars) => `<button class="rbtn" data-act="rumble" data-i="${p.index}" data-m="${id}" ${canRumble ? '' : 'disabled'} data-focus data-k="rb-${id}"><span>${label}</span><i class="rbar ${id}" style="--c:${col}">${bars}</i></button>`;
    return `<div class="pad-grid" data-i="${p.index}">
      <section class="pn pn-pad">
        <div class="pn-top"><div class="pn-title"><span class="pn-g">${icon('gamepad')}</span><div><b id="padName">${esc(pretty(p))}</b><button class="mini" data-act="padrename" data-focus data-k="pt-edit" aria-label="Rename controller" title="Rename">${icon('edit')}</button>
          <small title="${esc(p.id)}">${esc(rawId(p.id))}${p.mapping ? ` (${esc(p.mapping.toUpperCase())} GAMEPAD)` : ''}</small></div></div><div class="ptabs" role="tablist">${tabs}</div></div>
        <div class="pad-fig">${p.mapping === 'standard' ? diagram(p) : `<div class="nonstd">${icon('gamepad')}<p>This controller doesn't use the standard layout, so the picture is hidden. Every button and axis is still shown on the right.</p></div>`}</div>
      </section>
      <section class="pn pn-sticks">${head('g', 'target', 'Analog Sticks', 'Linearity, Drift & Circularity', `<button class="mini r" data-act="padreset" data-focus data-k="pt-reset" aria-label="Reset stick trails" title="Reset trails">${icon('refresh')}</button>`)}
        <div class="stick-row">${['l', 'r'].map((s) => `<div class="sp"><canvas width="240" height="240" data-sc="${s}"></canvas><b>${s === 'l' ? 'LEFT' : 'RIGHT'} STICK</b><code data-sv="${s}">+0.00, +0.00</code><em data-se="${s}">Err: —</em></div>`).join('')}</div></section>
      <section class="pn pn-trig">${head('p', 'sparkle', 'Triggers', 'Analog Pressure (0-1)')}
        <div class="trig-row">${[['6', L.lt.split(' / ')[0] + (k === 'xbox' ? ' / L2' : '')], ['7', L.rt.split(' / ')[0] + (k === 'xbox' ? ' / R2' : '')]].map(([n, lab]) => `<div class="tg"><div class="tgb"><i data-t="${n}"></i><span data-tv="${n}">0.00</span></div><b>${esc(k === 'xbox' ? (n === '6' ? 'LT / L2' : 'RT / R2') : lab)}</b></div>`).join('')}</div></section>
      <section class="pn pn-raw">${head('c', 'chart', 'Raw Data', `${p.mapping || 'unmapped'}`, `<span class="pn-r" data-hz>B:${p.buttons.length} A:${p.axes.length}</span>`)}
        <h4>AXES</h4><div class="axes">${axes}</div><h4>BUTTONS</h4><div class="bchips">${btns}</div></section>
      <section class="pn pn-vib">${head('o', 'bolt', 'Vibration Test', canRumble ? 'Dual Motor' : 'Not reported by this controller')}
        <div class="vib-vis"><i class="vm l" data-vm="l"></i><div class="vc" data-vc>${icon('vibrate')}</div><i class="vm r" data-vm="r"></i></div>
        <div class="vib-grid">${rb('heavy', 'HEAVY', '#ff8a2b', '<u></u><u></u>')}${rb('light', 'LIGHT', '#4da3ff', '<u></u>')}${rb('burst', 'BURST', '#a45bff', '<u></u><u></u><u></u>')}${rb('pulse', 'PULSE', '#ff5a5f', '<u></u><u></u><u></u><u></u>')}</div>
        ${canRumble ? '' : '<p class="vib-note">Windows only passes vibration to apps for some controllers and connections. Try USB, or an Xbox / DualSense pad.</p>'}</section>
    </div>`;
  }

  /* ------------------------------------------------------------------ live loop */
  function stop() { cancelAnimationFrame(raf); raf = 0; }
  const f2 = (v) => (v >= 0 ? '+' : '') + v.toFixed(2);

  function drawStick(canvas, tr, x, y, accent) {
    const c = canvas.getContext('2d'), W = canvas.width, R = W / 2 - 14, cx = W / 2;
    c.clearRect(0, 0, W, W);
    c.lineWidth = 2; c.strokeStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.arc(cx, cx, R, 0, 7); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,.08)'; c.beginPath(); c.arc(cx, cx, R * 0.5, 0, 7); c.stroke();
    c.beginPath(); c.moveTo(cx - R, cx); c.lineTo(cx + R, cx); c.moveTo(cx, cx - R); c.lineTo(cx, cx + R); c.stroke();
    c.fillStyle = accent; c.globalAlpha = 0.42;
    for (const q of tr) { c.beginPath(); c.arc(cx + q[0] * R, cx + q[1] * R, 2.600, 0, 7); c.fill(); }
    c.globalAlpha = 1; c.fillStyle = accent; c.beginPath(); c.arc(cx + x * R, cx + y * R, 10, 0, 7); c.fill();
    c.strokeStyle = accent; c.lineWidth = 2; c.beginPath(); c.moveTo(cx, cx); c.lineTo(cx + x * R, cx + y * R); c.stroke();
  }
  function circErr(tr) {
    const rs = tr.map((q) => Math.hypot(q[0], q[1])).filter((r) => r > 0.8);
    if (rs.length < 12) return null;
    const m = rs.reduce((a, b) => a + b, 0) / rs.length;
    return Math.sqrt(rs.reduce((a, b) => a + (b - m) * (b - m), 0) / rs.length) * 100;
  }

  function frame(now) {
    if (!GL.S || GL.S.view.name !== 'controllers') { stop(); return; }
    raf = requestAnimationFrame(frame);
    const list = pads(); const s = list.map((p) => p.index + p.id).join('|') + '|' + sel;
    if (s !== sig) { GL.views.controllers.mount(); return; }
    const root = document.querySelector('.pad-grid'); if (!root) return;
    const p = navigator.getGamepads()[+root.dataset.i]; if (!p) return;
    const st = ctx || (ctx = { n: 0, ts: 0, t0: now, hz: 0 });
    if (p.timestamp !== st.ts) { st.ts = p.timestamp; st.n++; }
    if (now - st.t0 >= 1000) { st.hz = Math.round((st.n * 1000) / (now - st.t0)); st.n = 0; st.t0 = now; const h = root.querySelector('[data-hz]'); if (h) h.textContent = `${st.hz} Hz · B:${p.buttons.length} A:${p.axes.length}`; }
    root.querySelectorAll('.pb,.knob-g').forEach((e) => { const b = p.buttons[+e.dataset.b]; e.classList.toggle('on', !!(b && b.pressed)); });
    root.querySelectorAll('[data-rb]').forEach((e) => { const b = p.buttons[+e.dataset.rb]; e.classList.toggle('on', !!(b && b.pressed)); });
    [6, 7].forEach((n) => {
      const v = p.buttons[n] ? p.buttons[n].value : 0;
      const bar = root.querySelector(`.tgb [data-t="${n}"]`); if (bar) { bar.style.transform = `scaleY(${v})`; root.querySelector(`[data-tv="${n}"]`).textContent = v.toFixed(2); }
      const sv = root.querySelector(`.tr-fill[data-t="${n}"]`); if (sv) sv.style.transform = `scaleY(${v})`;
    });
    const tr = trails[p.index] || (trails[p.index] = { l: [], r: [] });
    const accent = getComputedStyle(root).getPropertyValue('--pad').trim() || '#1fc98a';
    [['l', 0, 1], ['r', 2, 3]].forEach(([k, ax, ay]) => {
      const x = p.axes[ax] || 0, y = p.axes[ay] || 0;
      if (Math.hypot(x, y) > 0.05) { tr[k].push([x, y]); if (tr[k].length > 500) tr[k].shift(); }
      const cv = root.querySelector(`[data-sc="${k}"]`); if (cv) drawStick(cv, tr[k], x, y, accent);
      const sv = root.querySelector(`[data-sv="${k}"]`); if (sv) sv.textContent = `${f2(x)}, ${f2(y)}`;
      const e = circErr(tr[k]); const se = root.querySelector(`[data-se="${k}"]`); if (se) { se.textContent = e == null ? 'Err: —' : `Err: ${e.toFixed(1)}%`; se.className = e != null && e > 6 ? 'bad' : ''; }
      const g = root.querySelector(`.stk[data-s="${k}"] .knob-g`); if (g) g.style.transform = `translate(${(x * 12).toFixed(1)}px, ${(y * 12).toFixed(1)}px)`;
    });
    p.axes.forEach((v, n) => { const b = root.querySelector(`[data-ra="${n}"]`); if (b) { b.style.transform = `translateX(${(v * 50).toFixed(1)}%)`; root.querySelector(`[data-rv="${n}"]`).textContent = f2(v); } });
    const r = rumbleUntil[p.index], live = r && r.until > now;
    const vc = root.querySelector('[data-vc]'); if (vc) vc.classList.toggle('on', !!live);
    ['l', 'r'].forEach((m) => { const e = root.querySelector(`[data-vm="${m}"]`); if (e) e.style.setProperty('--v', live ? (m === 'l' ? r.strong : r.weak) : 0); });
  }

  GL.views.controllers = {
    html() {
      return `<section class="padtest"><div class="lib-head"><h1>Controller test <small id="padCount"></small></h1>
        <div class="lib-actions"><button class="btn" data-act="back" data-focus data-k="pt-back">${icon('back')}Back</button></div></div>
        <div id="padHost"></div></section>`;
    },
    after() { sig = ''; sel = -1; ctx = null; this.mount(); stop(); raf = requestAnimationFrame(frame); },
    mount() {
      const host = document.getElementById('padHost'); if (!host) return;
      const list = pads();
      if (!list.some((p) => p.index === sel)) sel = list.length ? list[0].index : -1;
      sig = list.map((p) => p.index + p.id).join('|') + '|' + sel; ctx = null;
      const cnt = document.getElementById('padCount'); if (cnt) cnt.textContent = list.length ? `${list.length} connected` : '';
      if (!list.length) { host.innerHTML = `<div class="empty-lib">${icon('gamepad')}<h3>No controller detected</h3><p>Connect a controller by USB or Bluetooth, then press any button. Xbox, PlayStation, Nintendo and most generic controllers work.</p></div>`; return; }
      const p = list.find((x) => x.index === sel);
      host.innerHTML = html(p, list) + `<p class="sub nav-note">Controller navigation is paused on this page. Hold <b>Select + Start</b> for 1.5 seconds (or press Esc) to leave.</p>`;
    },
  };

  const A = GL.act;
  A.controllers = () => GL.go('controllers');
  A.padsel = (d) => { sel = +d.i; GL.views.controllers.mount(); };
  A.padreset = () => { Object.keys(trails).forEach((k) => { trails[k] = { l: [], r: [] }; }); };
  A.padrename = () => {
    const b = document.getElementById('padName'); if (!b || b.querySelector('input')) return;
    const p = pads().find((x) => x.index === sel); if (!p) return;
    const inp = document.createElement('input'); inp.className = 'pname'; inp.maxLength = 32; inp.value = pretty(p);
    b.textContent = ''; b.appendChild(inp); inp.focus(); inp.select();
    const done = (save) => {
      if (!inp.isConnected) return;
      const v = inp.value.trim();
      if (save && v) { const n = { ...names() }; if (v === LABELS[kind(p.id)].name) delete n[p.id]; else n[p.id] = v; GL.S.settings.padNames = n; api.invoke('settings:set', { padNames: n }); }
      b.textContent = pretty(p);
    };
    inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') done(true); else if (e.key === 'Escape') done(false); });
    inp.addEventListener('blur', () => done(true));
  };

  const PATTERNS = {
    heavy: [{ at: 0, ms: 900, strong: 1, weak: 0.25 }],
    light: [{ at: 0, ms: 900, strong: 0, weak: 1 }],
    burst: [0, 260, 520].map((at) => ({ at, ms: 140, strong: 1, weak: 1 })),
    pulse: [0, 1, 2, 3, 4].map((i) => ({ at: i * 200, ms: 160, strong: (i + 1) / 5, weak: (i + 1) / 5 })),
  };
  A.rumble = (d) => {
    const p = navigator.getGamepads()[+d.i]; if (!p) return;
    const steps = PATTERNS[d.m] || PATTERNS.heavy;
    steps.forEach((s) => setTimeout(() => {
      const until = performance.now() + s.ms;
      rumbleUntil[p.index] = { strong: s.strong, weak: s.weak, until };
      try {
        if (p.vibrationActuator && p.vibrationActuator.playEffect) p.vibrationActuator.playEffect('dual-rumble', { startDelay: 0, duration: s.ms, strongMagnitude: s.strong, weakMagnitude: s.weak });
        else if (p.hapticActuators && p.hapticActuators[0] && p.hapticActuators[0].pulse) p.hapticActuators[0].pulse(Math.max(s.strong, s.weak), s.ms);
      } catch (_) { /* unsupported */ }
    }, s.at));
  };
})();
