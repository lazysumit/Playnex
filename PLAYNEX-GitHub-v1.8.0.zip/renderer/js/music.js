'use strict';
// Now-playing: top-bar icon + small popover with track info and transport controls.
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;
  const api = window.api;
  const sessions = () => (GL.S && GL.S.settings && GL.S.settings.musicEnabled !== false && GL.S.music && GL.S.music.now) || [];
  GL.musicPlaying = () => sessions().some((s) => s.status === 'playing');
  GL.musicTitle = () => { const s = sessions().find((x) => x.status === 'playing'); return s ? `${s.title}${s.artist ? ' — ' + s.artist : ''} (${s.app})` : 'Now playing'; };

  let pop = null;
  function html() {
    const list = sessions();
    if (!list.length) return '<div class="mp-empty">Nothing is playing right now.</div>';
    return list.slice(0, 3).map((s, i) => `<div class="mp-item ${s.status}">
      <div class="mp-art${s.thumb ? ' has-img' : ''}">${s.thumb ? `<img src="${s.thumb}" alt="" draggable="false">` : ''}<span class="eq ${s.status === 'playing' ? '' : 'still'}"><i></i><i></i><i></i><i></i></span></div>
      <div class="mp-meta"><small>${esc(s.app)}${s.status === 'paused' ? ' · paused' : ''}</small><b>${esc(s.title || 'Unknown track')}</b><span>${esc(s.artist || s.album || '')}</span></div>
      <div class="mp-ctl">
        <button data-act="musicctl" data-a="prev" data-app="${esc(s.appId)}" data-focus data-k="mp-prev-${i}" aria-label="Previous">${icon('prev')}</button>
        <button class="main" data-act="musicctl" data-a="toggle" data-app="${esc(s.appId)}" data-focus data-k="mp-tog-${i}" aria-label="${s.status === 'playing' ? 'Pause' : 'Play'}">${icon(s.status === 'playing' ? 'pause' : 'play')}</button>
        <button data-act="musicctl" data-a="next" data-app="${esc(s.appId)}" data-focus data-k="mp-next-${i}" aria-label="Next">${icon('next')}</button>
      </div></div>`).join('');
  }
  GL.musicUpdate = () => { if (pop) { if (!sessions().length) closePop(); else pop.innerHTML = html(); } };
  function closePop() { if (pop) { pop.remove(); pop = null; document.removeEventListener('mousedown', outside, true); } }
  function outside(e) { if (pop && !pop.contains(e.target) && !e.target.closest('.music-btn')) closePop(); }
  GL.act.musicpop = () => {
    if (pop) return closePop();
    pop = document.createElement('div'); pop.className = 'music-pop'; pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-label', 'Now playing');
    pop.innerHTML = html(); document.body.appendChild(pop);
    requestAnimationFrame(() => pop && pop.classList.add('in'));
    document.addEventListener('mousedown', outside, true);
  };
  GL.act.musicctl = (d) => { api.invoke('music:control', d.a, d.app); };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && pop) { closePop(); e.stopPropagation(); } }, true);
})();
