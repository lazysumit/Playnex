'use strict';
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;
  const api = window.api;
  const steamAch = {}; // gameId -> {list|error|loading}

  function sessionsFor(id) { return GL.S.sessions.filter((s) => s.gameId === id).sort((a, b) => b.start - a.start); }

  function achHtml(g) {
    const a = steamAch[g.id];
    if (!g.steamAppId) return '<p class="muted">Steam achievements are available for games matched to a Steam app.</p>';
    if (!a) return `<button class="btn" data-act="loadach" data-id="${esc(g.id)}" data-focus data-k="d-ach">${icon('trophy')}Load Steam achievements</button>`;
    if (a.loading) return '<p class="muted">Loading achievements…</p>';
    if (a.error) return `<p class="muted">${esc(a.error)}</p>`;
    const done = a.list.filter((x) => x.done).length;
    if (!a.list.length) return '<p class="muted">This game has no achievements.</p>';
    return `<div class="ach-sum"><b>${done}</b> of ${a.list.length} unlocked<div class="bar"><span style="width:${done / a.list.length * 100}%"></span></div></div>
      <ul class="ach-list">${[...a.list].sort((x, y) => (y.done - x.done) || ((y.at || 0) - (x.at || 0))).slice(0, 30).map((x) => `<li class="${x.done ? 'done' : ''}"><span>${icon(x.done ? 'trophy' : 'lock')}</span><div><b>${esc(x.name)}</b><small>${esc(x.desc)}</small></div>${x.at ? `<em>${new Date(x.at).toLocaleDateString()}</em>` : ''}</li>`).join('')}</ul>`;
  }

  /** Screenshot rail: mouse wheel scrolls sideways, arrow buttons page it, edge arrows hide when there is nothing more. */
  function railState(rail) {
    const wrap = rail.parentElement; if (!wrap) return;
    const max = rail.scrollWidth - rail.clientWidth;
    wrap.classList.toggle('can-l', rail.scrollLeft > 4); wrap.classList.toggle('can-r', rail.scrollLeft < max - 4);
  }
  function wireRail(rail) {
    rail.addEventListener('wheel', (e) => {
      const max = rail.scrollWidth - rail.clientWidth; if (max <= 4) return;
      const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
      if ((d < 0 && rail.scrollLeft <= 0) || (d > 0 && rail.scrollLeft >= max - 1)) return; // at the end: let the page scroll
      e.preventDefault(); rail.scrollLeft += d; 
    }, { passive: false });
    rail.addEventListener('scroll', () => railState(rail), { passive: true });
    rail.addEventListener('focusin', (e) => { const t = e.target.closest('.shot'); if (t) t.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' }); });
    requestAnimationFrame(() => railState(rail)); setTimeout(() => railState(rail), 400);
  }
  GL.act.railgo = (d, e, el) => {
    const rail = el.parentElement.querySelector('.rail'); if (!rail) return;
    rail.scrollBy({ left: (+d.dir) * Math.max(240, rail.clientWidth * 0.8), behavior: 'smooth' });
  };

  GL.views.game = {
    html(S) {
      const g = S.games[S.view.id];
      if (!g) return `<section class="empty-lib">${icon('search')}<h3>Game not found</h3><p>It may have been uninstalled or removed.</p><button class="btn" data-act="nav" data-view="library" data-focus data-k="nf">Back to library</button></section>`;
      const m = g.meta || {}, run = GL.isRunning(g.id);
      const ses = sessionsFor(g.id);
      const logo = GL.art(g, 'logo');
      const banner = GL.art(g, 'banner');
      const shots = (g.art && g.art.screenshots) || [];
      const thumbs = (g.art && g.art.thumbs) || shots;
      const first = ses.length ? ses[ses.length - 1].start : null;
      const longest = ses.reduce((a, s) => Math.max(a, s.duration), 0);
      const avg = ses.length ? g.playtime / ses.length : 0;
      const cols = S.collections.filter((c) => c.gameIds.includes(g.id));
      const row = (k, v) => (v ? `<div class="kv"><span>${k}</span><b>${v}</b></div>` : '');
      return `<section class="details">
        ${banner ? `<div class="d-banner"><img src="${esc(banner)}" alt=""></div>` : ''}
        <button class="btn ghost back" data-act="back" data-focus data-k="d-back">${icon('back')}Back</button>
        <header class="d-head">
          <div class="d-cover" data-game="${esc(g.id)}">${GL.cover(g)}</div>
          <div class="d-title">
            <div class="d-logo">${logo ? `<img src="${esc(logo)}" alt="">` : ''}<h1>${esc(g.title)}</h1></div>
            <div class="hi-meta">${GL.pill(g.platform)}${run ? '<span class="chip live">Playing now</span>' : ''}
              ${(m.genres || []).slice(0, 4).map((x) => `<span class="chip">${esc(x)}</span>`).join('')}
              ${m.metacritic ? `<span class="chip score" data-tip="Metacritic score">${m.metacritic}</span>` : ''}
              ${g.ratings && g.ratings.steam && g.ratings.steam.percent != null ? `<span class="chip score steam" data-tip="${esc(g.ratings.steam.desc)} on Steam">${g.ratings.steam.percent}%</span>` : ''}</div>
            <div class="hi-actions">
              <button class="btn primary big" data-act="launch" data-id="${esc(g.id)}" data-focus data-k="d-play">${icon('play')}${run ? 'Running' : g.playtime ? 'Play' : 'Start'}</button>
              <button class="btn icon big" data-act="fav" data-id="${esc(g.id)}" data-focus data-k="d-fav" aria-label="${g.favorite ? 'Remove from favourites' : 'Add to favourites'}" title="Favourite (F)">${icon(g.favorite ? 'starFill' : 'star')}</button>
              <button class="btn big" data-act="addcol" data-id="${esc(g.id)}" data-focus data-k="d-col">${icon('folder')}Collections${cols.length ? ` <b class="n">${cols.length}</b>` : ''}</button>
              <button class="btn icon big" data-act="gmenu" data-id="${esc(g.id)}" data-focus data-k="d-more" aria-label="More options">${icon('more')}</button>
            </div>
          </div>
        </header>
        <div class="d-grid">
          <div class="d-main">
            <div class="panel"><h2>About</h2>
              ${m.description ? `<p class="lead">${esc(m.description)}</p>` : `<p class="muted">No description found. Use <b>More → Identify game</b> to match this title to a store page.</p>`}
              ${m.about && m.about.length > (m.description || '').length + 40 ? `<details class="more"><summary>Read more</summary><p>${esc(m.about)}</p></details>` : ''}
            </div>
            <div class="panel" id="ratingsPanel"><h2>Ratings &amp; reviews</h2><div id="ratingsBody">${GL.ratings.html(g.ratings && g.ratings.v === 4 ? g.ratings : null, { id: g.id })}</div></div>
            ${shots.length ? `<div class="panel"><h2>Screenshots</h2><div class="rail-wrap"><button class="rail-btn l" data-act="railgo" data-dir="-1" aria-label="Previous screenshots" tabindex="-1">${icon('back')}</button><button class="rail-btn r" data-act="railgo" data-dir="1" aria-label="Next screenshots" tabindex="-1">${icon('back')}</button><div class="rail shots">${shots.map((s, i) => `<button class="shot" data-act="shot" data-i="${i}" data-id="${esc(g.id)}" data-focus data-k="shot-${i}"><img src="${esc(thumbs[i] || s)}" alt="Screenshot ${i + 1}" loading="lazy"></button>`).join('')}</div></div></div>` : ''}
            ${(() => { const caps = (GL.S.captures || []).filter((c) => c.gameId === g.id); return caps.length ? `<div class="panel"><h2>Your screenshots <small class="tag">${caps.length}</small></h2><div class="cap-grid">${caps.slice(0, 6).map((c) => `<button class="capt" data-act="capview" data-id="${esc(c.id)}" data-focus data-k="gc-${esc(c.id)}"><img src="${esc(c.url)}" alt="" loading="lazy"><span><small>${GL.dateTime(c.ts)}</small></span></button>`).join('')}</div></div>` : ''; })()}
            <div class="panel"><h2>Session history</h2>
              ${ses.length ? `<ul class="sess">${ses.slice(0, 8).map((s) => `<li><span>${GL.dateTime(s.start)}</span><b>${GL.dur(s.duration)}</b></li>`).join('')}</ul>${ses.length > 8 ? `<p class="muted">${ses.length - 8} older sessions are included in your profile statistics.</p>` : ''}` : '<p class="muted">Sessions appear here after you play. Playtime is tracked while the game runs.</p>'}
            </div>
            <div class="panel" id="achPanel"><h2>Achievements</h2><div id="achBody">${achHtml(g)}</div></div>
          </div>
          <aside class="d-side">
            <div class="panel stats4">
              <div><b>${g.playtime ? GL.dur(g.playtime) : '0 min'}</b><span>Total playtime</span></div>
              <div><b>${ses.length}</b><span>Sessions</span></div>
              <div><b>${ses.length ? GL.dur(avg) : '—'}</b><span>Average session</span></div>
              <div><b>${longest ? GL.dur(longest) : '—'}</b><span>Longest session</span></div>
            </div>
            <div class="panel"><h2>Details</h2>
              ${row('Last played', g.lastPlayed ? GL.ago(g.lastPlayed) : 'Never')}
              ${row('First played', first ? new Date(first).toLocaleDateString() : '')}
              ${row('Developer', esc((m.developers || []).join(', ')))}
              ${row('Publisher', esc((m.publishers || []).join(', ')))}
              ${row('Released', esc(m.releaseDate || ''))}
              ${row('Added', new Date(g.added).toLocaleDateString())}
              ${row('Platform', esc((GL.PLATFORM[g.platform] || {}).name || g.platform))}
              ${g.installDir ? `<div class="kv path"><span>Installed in</span><button class="linkbtn" data-act="openfolder" data-id="${esc(g.id)}" data-focus data-k="d-folder" title="${esc(g.installDir)}">${esc(g.installDir)}</button></div>` : ''}
              ${m.website ? `<div class="kv"><span>Website</span><b><a href="${esc(m.website)}" target="_blank" rel="noreferrer">Open page</a></b></div>` : ''}
            </div>
            ${cols.length ? `<div class="panel"><h2>In collections</h2><div class="hi-meta">${cols.map((c) => `<span class="chip">${esc(c.name)}</span>`).join('')}</div></div>` : ''}
          </aside>
        </div>
      </section>`;
    },
    after() {
      const S = GL.S; const g = S.games[S.view.id];
      if (g && S.settings.steamApiKey && g.steamAppId && !steamAch[g.id]) GL.act.loadach({ id: g.id });
      if (g) GL.ratings.load(g.id);
      const rail = document.querySelector('.rail.shots'); if (rail) wireRail(rail);
    },
  };

  GL.act.loadach = async (d) => {
    steamAch[d.id] = { loading: true };
    const body = document.getElementById('achBody'); if (body) body.innerHTML = achHtml(GL.S.games[d.id]);
    const r = await api.invoke('game:steamAchievements', d.id);
    steamAch[d.id] = r;
    const b2 = document.getElementById('achBody'); if (b2 && GL.S.view.id === d.id) b2.innerHTML = achHtml(GL.S.games[d.id]);
  };
  GL.act.openfolder = (d) => api.invoke('game:openFolder', d.id);
  GL.act.addcol = (d, e, el) => GL.modal.collections(GL.S.games[d.id]);
  GL.act.gmenu = (d, e, el) => { const r = el.getBoundingClientRect(); GL.modal.context(GL.S.games[d.id], r.left, r.bottom + 4); };
  GL.act.shot = (d) => GL.modal.lightbox(GL.S.games[d.id], +d.i);
})();
