'use strict';
window.GL = window.GL || {};
GL.views = GL.views || {};
GL.act = GL.act || {};
(function () {
  GL.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  GL.PLATFORM = {
    steam: { name: 'Steam', color: '#4a9fd8' }, epic: { name: 'Epic Games', color: '#c9ced6' },
    xbox: { name: 'Xbox', color: '#52b043' }, ubisoft: { name: 'Ubisoft Connect', color: '#2f8cff' },
    ea: { name: 'EA app', color: '#ff5a4d' }, battlenet: { name: 'Battle.net', color: '#2aa7ff' },
    gog: { name: 'GOG', color: '#b265e6' }, riot: { name: 'Riot Games', color: '#ff4655' },
    rockstar: { name: 'Rockstar', color: '#f5b82e' }, manual: { name: 'Scanned folder', color: '#8892a6' },
    custom: { name: 'Custom', color: '#8892a6' },
  };

  GL.dur = (sec, short) => {
    sec = Math.round(sec || 0);
    if (sec < 60) return sec <= 0 ? (short ? '0m' : '0 min') : `${sec}s`;
    const m = Math.round(sec / 60), h = Math.floor(m / 60);
    if (h === 0) return `${m}${short ? 'm' : ' min'}`;
    return `${h}h ${m % 60}m`;
  };
  GL.hours = (sec) => { const h = (sec || 0) / 3600; return h >= 100 ? Math.round(h) + 'h' : h >= 10 ? h.toFixed(0) + 'h' : h.toFixed(1) + 'h'; };

  GL.ago = (t) => {
    if (!t) return 'Never';
    const d = Date.now() - t, m = d / 60000;
    if (m < 1) return 'Just now'; if (m < 60) return `${Math.floor(m)} min ago`;
    if (m < 1440) { const h = Math.floor(m / 60); return `${h} hour${h > 1 ? 's' : ''} ago`; }
    const days = Math.floor(m / 1440);
    if (days === 1) return 'Yesterday'; if (days < 30) return `${days} days ago`;
    return new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  };
  GL.dateTime = (t) => new Date(t).toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

  GL.hue = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; };

  /** Resolve artwork: user override -> downloaded -> (cover<-header) fallbacks. */
  GL.art = (g, kind) => {
    if (!g) return '';
    const c = g.customArt && g.customArt[kind]; if (c) return c;
    const a = g.art || {};
    if (kind === 'banner') return a.banner || a.header || '';
    if (kind === 'cover') return a.cover || '';
    return a[kind] || '';
  };

  /** Cover tile: generated placeholder underneath, artwork on top (removed on load error). */
  GL.cover = (g, cls = '') => {
    const url = GL.art(g, 'cover') || GL.art(g, 'header');
    const h = GL.hue(g.title || g.id);
    return `<div class="cover ${cls}" style="--h:${h}"><span class="ph">${GL.esc(g.title)}</span>${url ? `<img src="${GL.esc(url)}" alt="" loading="lazy" decoding="async">` : ''}</div>`;
  };
  GL.square = (g) => {
    const url = GL.art(g, 'icon') || GL.art(g, 'cover') || GL.art(g, 'header');
    const h = GL.hue(g.title || g.id);
    return `<div class="cover square" style="--h:${h}"><span class="ph">${GL.esc((g.title || '?').slice(0, 2))}</span>${url ? `<img src="${GL.esc(url)}" alt="" decoding="async">` : ''}</div>`;
  };

  GL.pill = (platform) => { const p = GL.PLATFORM[platform] || { name: platform, color: '#888' }; return `<span class="pill"><i style="background:${p.color}"></i>${GL.esc(p.name)}</span>`; };

  GL.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  GL.dayStart = (t) => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };

  // Hide broken <img> so the generated placeholder shows through (error events don't bubble => capture).
  document.addEventListener('error', (e) => {
    const t = e.target;
    if (t && t.tagName === 'IMG' && !t.dataset.keep) t.remove();
  }, true);
})();
