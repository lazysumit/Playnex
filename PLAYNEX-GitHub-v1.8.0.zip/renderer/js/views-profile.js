'use strict';
// Profile & stats, split into focused tabs so each one fits on screen and tells one story.
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;
  const api = window.api;
  let range = 30;          // days shown in the Activity chart
  let ptab = 'overview';
  let tfilter = 'all';     // trophies filter
  let cfilter = 'all';     // captures filter (game id)

  const TABS = [['overview', 'Overview', 'chart'], ['activity', 'Activity', 'clock'], ['games', 'Games', 'gamepad'], ['trophies', 'Trophies', 'trophy'], ['captures', 'Captures', 'camera']];
  const DAY = 86400000;
  const dkey = (t) => { const d = new Date(t); return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate(); };
  const hourFmt = (h) => (h === 0 ? '12a' : h < 12 ? h + 'a' : h === 12 ? '12p' : h - 12 + 'p');
  const hFmt = (v) => (v >= 10 ? Math.round(v) + 'h' : v >= 1 ? (+v.toFixed(1)) + 'h' : Math.round(v * 60) + 'm');

  function perDay(days) {
    const map = {}; GL.S.sessions.forEach((s) => { const k = dkey(s.start); map[k] = (map[k] || 0) + s.duration; });
    const t0 = GL.dayStart(Date.now()); const out = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(t0 - i * DAY);
      out.push({ label: days <= 7 ? d.toLocaleDateString(undefined, { weekday: 'short' }) : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), value: (map[dkey(d)] || 0) / 3600, date: d });
    }
    return out;
  }
  function hourly() {
    const arr = Array(24).fill(0);
    GL.S.sessions.forEach((s) => { let t = s.start; const end = s.end || s.start + s.duration * 1000; while (t < end) { const next = Math.min(end, (Math.floor(t / 3600000) + 1) * 3600000); arr[new Date(t).getHours()] += (next - t) / 1000; t = next; } });
    return arr;
  }
  function weekdays() {
    const arr = Array(7).fill(0); GL.S.sessions.forEach((s) => { arr[(new Date(s.start).getDay() + 6) % 7] += s.duration; });
    return arr;
  }
  function streaks() {
    const set = new Set(GL.S.sessions.map((s) => dkey(s.start)));
    let cur = 0; let t = GL.dayStart(Date.now()); if (!set.has(dkey(t))) t -= DAY;
    while (set.has(dkey(t))) { cur++; t -= DAY; }
    const days = [...new Set(GL.S.sessions.map((s) => GL.dayStart(s.start)))].sort((a, b) => a - b);
    let best = 0, run = 0, prev = null;
    days.forEach((d) => { run = prev !== null && Math.round((d - prev) / DAY) === 1 ? run + 1 : 1; best = Math.max(best, run); prev = d; });
    return { cur, best };
  }
  const dayLabel = (t) => { const n = Math.round((GL.dayStart(Date.now()) - GL.dayStart(t)) / DAY); return n === 0 ? 'Today' : n === 1 ? 'Yesterday' : new Date(t).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }); };

  const kpi = (ic, label, value, sub, tone = '') => `<div class="kpi2 ${tone}"><span class="k-ic">${icon(ic)}</span><div><b>${value}</b><span>${esc(label)}</span>${sub ? `<small>${sub}</small>` : ''}</div></div>`;

  /* ----------------------------------------------------------------- tabs */
  function overview(S) {
    const all = GL.all();
    const total = Object.values(S.games).reduce((a, g) => a + (g.playtime || 0), 0);
    const w = perDay(7); const wSec = w.reduce((a, d) => a + d.value, 0) * 3600;
    const prev = (() => { const t0 = GL.dayStart(Date.now()) - 13 * DAY, t1 = GL.dayStart(Date.now()) - 6 * DAY; return S.sessions.filter((s) => s.start >= t0 && s.start < t1).reduce((a, s) => a + s.duration, 0); })();
    const delta = prev > 0 ? Math.round(((wSec - prev) / prev) * 100) : null;
    const st = streaks();
    const avg = S.sessions.length ? S.sessions.reduce((a, s) => a + s.duration, 0) / S.sessions.length : 0;
    const byPlat = {}; Object.values(S.games).forEach((g) => { if (g.playtime) byPlat[g.platform] = (byPlat[g.platform] || 0) + g.playtime; });
    const plat = Object.entries(byPlat).map(([p, v]) => ({ label: (GL.PLATFORM[p] || { name: p }).name, value: v }));
    const top = GL.mostPlayed(5);
    const latest = S.achievements.filter((a) => a.unlockedAt).sort((a, b) => b.unlockedAt - a.unlockedAt).slice(0, 4);
    return `<div class="g12">
      <div class="c3">${kpi('clock', 'Total playtime', GL.dur(total), `${all.filter((g) => g.playtime).length} of ${all.length} games played`)}</div>
      <div class="c3">${kpi('bolt', 'This week', GL.dur(wSec), delta === null ? 'First week of data' : `<span class="${delta >= 0 ? 'up' : 'down'}">${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta)}%</span> vs last week`)}</div>
      <div class="c3">${kpi('gamepad', 'Sessions', S.sessions.length, S.sessions.length ? `${GL.dur(avg, true)} on average` : '')}</div>
      <div class="c3">${kpi('flame', 'Daily streak', `${st.cur} day${st.cur === 1 ? '' : 's'}`, `Best: ${st.best} day${st.best === 1 ? '' : 's'}`, 'hot')}</div>

      <div class="panel c8"><div class="ph-row"><h2>Last 7 days</h2><span class="pill-note">${GL.dur(wSec, true)} total</span></div>
        ${GL.charts.bars(w.map((d) => ({ label: d.label, value: d.value, tip: `${d.date.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}: ${d.value ? GL.dur(d.value * 3600) : 'no play'}` })), { height: 250, fmt: hFmt, aria: 'Hours played per day, last 7 days' })}
      </div>
      <div class="panel c4"><h2>Where you play</h2>
        ${plat.length ? GL.charts.donut(plat, { fmt: (v) => GL.dur(v, true), centre: GL.dur(total, true), centreSub: 'all time' }) : '<p class="muted">Play a game and its platform shows up here.</p>'}
      </div>

      <div class="panel c7"><div class="ph-row"><h2>Most played</h2><button class="btn ghost sm" data-act="ptab" data-v="games" data-focus data-k="ov-games">See all</button></div>
        ${top.length ? `<ol class="toplist">${top.map((g, i) => `<li><button data-act="open" data-id="${esc(g.id)}" data-game="${esc(g.id)}" data-focus data-k="top-${esc(g.id)}"><em>${i + 1}</em><span class="mini">${GL.square(g)}</span><span class="tl-t"><b>${esc(g.title)}</b><small>${esc((GL.PLATFORM[g.platform] || {}).name || '')}</small></span><span class="tl-bar"><i style="width:${(g.playtime / top[0].playtime) * 100}%"></i></span><strong>${GL.dur(g.playtime, true)}</strong></button></li>`).join('')}</ol>` : '<p class="muted">Play something and your favourites will rank here.</p>'}
      </div>
      <div class="panel c5"><div class="ph-row"><h2>Latest trophies</h2><button class="btn ghost sm" data-act="ptab" data-v="trophies" data-focus data-k="ov-tr">See all</button></div>
        ${latest.length ? `<ul class="tr-list">${latest.map((a) => `<li><span class="tr-ic ${a.tier}">${icon(a.icon)}</span><div><b>${esc(a.name)}</b><small>${new Date(a.unlockedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} · ${a.xp} XP</small></div></li>`).join('')}</ul>` : '<p class="muted">Trophies you earn will appear here.</p>'}
      </div>
    </div>`;
  }

  function activity(S) {
    const days = perDay(range); const dayTotal = days.reduce((a, d) => a + d.value, 0); const active = days.filter((d) => d.value > 0).length;
    const hrs = hourly(); const peak = hrs.indexOf(Math.max(...hrs));
    const wd = weekdays(); const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']; const busiest = wd.indexOf(Math.max(...wd));
    const six = perDay(182);
    const sessions = [...S.sessions].sort((a, b) => b.start - a.start).slice(0, 40);
    const groups = []; sessions.forEach((s) => { const k = dkey(s.start); let g = groups[groups.length - 1]; if (!g || g.k !== k) { g = { k, t: s.start, total: 0, list: [] }; groups.push(g); } g.total += s.duration; g.list.push(s); });
    return `<div class="g12">
      <div class="panel c12"><div class="ph-row"><div><h2>Playtime per day</h2><p class="sub tight">${dayTotal ? `${hFmt(dayTotal)} across ${active} active day${active === 1 ? '' : 's'}` : 'No playtime recorded in this period yet.'}</p></div>
        <div class="seg" role="group" aria-label="Range">${[7, 30, 90].map((d) => `<button class="${range === d ? 'on' : ''}" data-act="range" data-v="${d}" data-focus data-k="r-${d}">${d} days</button>`).join('')}</div></div>
        ${GL.charts.bars(days.map((d) => ({ label: d.label, value: d.value, tip: `${d.date.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}: ${d.value ? GL.dur(d.value * 3600) : 'no play'}` })), { height: 200, fmt: hFmt, labelEvery: range === 7 ? 1 : range === 30 ? 5 : 10, aria: `Hours played per day, last ${range} days` })}
        ${GL.charts.table(['Day', 'Hours'], days.filter((d) => d.value > 0).map((d) => [d.date.toLocaleDateString(), d.value.toFixed(2)]))}
      </div>
      <div class="panel c12"><h2>Last 6 months</h2>${GL.charts.heatmap(six, { fmt: (v) => GL.dur(v * 3600, true) })}</div>
      <div class="panel c6"><h2>Time of day</h2><p class="sub tight">${S.sessions.length ? `You play most around ${hourFmt(peak)}.` : 'Shows when you usually play.'}</p>
        ${GL.charts.bars(hrs.map((v, h) => ({ label: hourFmt(h), value: v / 3600, tip: `${hourFmt(h)}: ${GL.dur(v)}` })), { height: 130, fmt: hFmt, labelEvery: 3, aria: 'Hours played by time of day' })}</div>
      <div class="panel c6"><h2>Day of week</h2><p class="sub tight">${S.sessions.length ? `${names[busiest]} is your busiest day.` : 'Shows which days you play most.'}</p>
        ${GL.charts.bars(wd.map((v, i) => ({ label: names[i], value: v / 3600, tip: `${names[i]}: ${GL.dur(v)}` })), { height: 130, fmt: hFmt, aria: 'Hours played by weekday' })}</div>
      <div class="panel c12"><h2>Session history</h2>
        ${groups.length ? groups.map((g) => `<div class="day-g"><div class="day-h"><b>${esc(dayLabel(g.t))}</b><span>${GL.dur(g.total, true)}</span></div><ul class="sess">${g.list.map((s) => { const gm = S.games[s.gameId]; return `<li><span class="sg">${gm ? `<span class="mini">${GL.square(gm)}</span>` : ''}<b>${esc(gm ? gm.title : 'Removed game')}</b></span><span>${new Date(s.start).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}</span><b>${GL.dur(s.duration, true)}</b></li>`; }).join('')}</ul></div>`).join('') : '<p class="muted">Your gaming history will appear here.</p>'}
      </div>
    </div>`;
  }

  function gamesTab(S) {
    const played = GL.all().filter((g) => g.playtime > 0).sort((a, b) => b.playtime - a.playtime);
    const unplayed = GL.all().length - played.length;
    const cnt = {}; S.sessions.forEach((s) => { cnt[s.gameId] = (cnt[s.gameId] || 0) + 1; });
    const total = played.reduce((a, g) => a + g.playtime, 0) || 1;
    return `<div class="panel c12 flush">
      ${played.length ? `<div class="gl-head"><span></span><span>Game</span><span>Share of playtime</span><span>Playtime</span><span>Sessions</span><span>Last played</span></div>
      <ul class="gl-rows">${played.map((g) => `<li><button data-act="open" data-id="${esc(g.id)}" data-game="${esc(g.id)}" data-focus data-k="gl-${esc(g.id)}">
        <span class="mini lg">${GL.square(g)}</span><span class="tl-t"><b>${esc(g.title)}</b>${GL.pill(g.platform)}</span>
        <span class="tl-bar"><i style="width:${Math.max(2, (g.playtime / played[0].playtime) * 100)}%"></i><u>${Math.round(g.playtime / total * 100)}%</u></span>
        <strong>${GL.dur(g.playtime)}</strong><span>${cnt[g.id] || 0}</span><span>${g.lastPlayed ? GL.ago(g.lastPlayed) : '—'}</span></button></li>`).join('')}</ul>` : '<p class="muted pad">No playtime recorded yet. Launch a game from here and it will be tracked automatically.</p>'}
      ${unplayed ? `<p class="foot-note">${unplayed} game${unplayed === 1 ? '' : 's'} in your library ${unplayed === 1 ? 'hasn\'t' : 'haven\'t'} been played yet.</p>` : ''}
    </div>`;
  }

  function trophies(S) {
    const list = S.achievements; const done = list.filter((a) => a.unlockedAt);
    const tier = (t) => ({ d: done.filter((a) => a.tier === t).length, n: list.filter((a) => a.tier === t).length });
    const shown = list.filter((a) => (tfilter === 'all' ? true : tfilter === 'done' ? a.unlockedAt : !a.unlockedAt))
      .sort((a, b) => (b.unlockedAt ? 1 : 0) - (a.unlockedAt ? 1 : 0) || (b.unlockedAt || 0) - (a.unlockedAt || 0) || (b.cur / b.target) - (a.cur / a.target));
    return `<div class="g12">
      <div class="c4">${['bronze', 'silver', 'gold', 'platinum'].map((t) => { const x = tier(t); return `<div class="tier-card ${t}"><span class="tr-ic ${t}">${icon(t === 'platinum' ? 'diamond' : 'trophy')}</span><div><b>${x.d}<small> / ${x.n}</small></b><span>${t[0].toUpperCase() + t.slice(1)}</span></div></div>`; }).join('')}</div>
      <div class="panel c8"><div class="ph-row"><h2>${done.length} of ${list.length} unlocked</h2>
        <div class="seg" role="group" aria-label="Filter">${[['all', 'All'], ['done', 'Unlocked'], ['todo', 'Locked']].map(([v, l]) => `<button class="${tfilter === v ? 'on' : ''}" data-act="tfilter" data-v="${v}" data-focus data-k="tf-${v}">${l}</button>`).join('')}</div></div>
        <div class="bar"><span style="width:${list.length ? done.length / list.length * 100 : 0}%"></span></div>
        <div class="ach-grid">${shown.map((a) => `
          <div class="ach ${a.tier} ${a.unlockedAt ? 'done' : ''}" tabindex="0" data-focus data-k="a-${a.id}" data-tip="${esc(a.desc)}">
            <span class="ai">${icon(a.icon)}${a.unlockedAt ? '' : `<i class="lk">${icon('lock')}</i>`}</span>
            <div><b>${esc(a.name)}</b><small>${a.unlockedAt ? 'Unlocked ' + new Date(a.unlockedAt).toLocaleDateString() : esc(a.desc)}</small>
            ${a.unlockedAt ? '' : `<div class="bar sm"><span style="width:${Math.min(100, a.cur / a.target * 100)}%"></span></div>`}</div><em>${a.xp} XP</em></div>`).join('') || '<p class="muted">Nothing here.</p>'}</div>
      </div></div>`;
  }

  function captures(S) {
    const caps = (S.captures || []);
    const ids = [...new Set(caps.map((c) => c.label))];
    const shown = caps.filter((c) => cfilter === 'all' || c.label === cfilter);
    return `<div class="panel c12"><div class="ph-row"><div><h2>Screenshots</h2><p class="sub tight">Press <kbd>${esc(S.settings.captureKey || 'F11')}</kbd> any time — in a game or in the launcher — to capture the screen.</p></div>
      <div class="btn-row nm"><button class="btn" data-act="capture" data-focus data-k="cp-take">${icon('camera')}Take screenshot</button><button class="btn ghost" data-act="capfolder" data-focus data-k="cp-folder">${icon('folder')}Open folder</button></div></div>
      ${ids.length > 1 ? `<div class="seg wrap" role="group" aria-label="Filter by game"><button class="${cfilter === 'all' ? 'on' : ''}" data-act="cfilter" data-v="all" data-focus data-k="cf-all">All</button>${ids.map((l, i) => `<button class="${cfilter === l ? 'on' : ''}" data-act="cfilter" data-v="${esc(l)}" data-focus data-k="cf-${i}">${esc(l)}</button>`).join('')}</div>` : ''}
      ${shown.length ? `<div class="cap-grid">${shown.map((c) => `<button class="capt" data-act="capview" data-id="${esc(c.id)}" data-focus data-k="cap-${esc(c.id)}"><img src="${esc(c.url)}" alt="Screenshot of ${esc(c.label)}" loading="lazy"><span><b>${esc(c.label)}</b><small>${GL.dateTime(c.ts)}</small></span></button>`).join('')}</div>`
        : `<div class="empty-note">${icon('camera')}<b>No screenshots yet</b><p>Press ${esc(S.settings.captureKey || 'F11')} while playing and your captures are saved here and to your Pictures folder.</p></div>`}
    </div>`;
  }

  const BODY = { overview, activity, games: gamesTab, trophies, captures };

  GL.views.profile = {
    html(S) {
      const lv = S.level || { level: 1, xp: 0, base: 0, next: 100, title: 'Newcomer' };
      const pct = Math.max(0, Math.min(100, ((lv.xp - lv.base) / Math.max(1, lv.next - lv.base)) * 100));
      const av = S.profile.avatar ? `<img src="${esc(S.profile.avatar)}" alt="">` : esc((S.profile.name || 'P').slice(0, 1).toUpperCase());
      return `<section class="profile2">
        <header class="pf-card">
          ${GL.charts.ring(pct, `<button class="p-av sm" data-act="editprofile" data-focus data-k="p-av" aria-label="Edit profile">${av}</button>`, 128)}
          <div class="pf-id"><h1>${esc(S.profile.name)}</h1><p><span class="lvl">Level ${lv.level}</span>${esc(lv.title)}</p>
            <small>${lv.xp - lv.base} / ${lv.next - lv.base} XP to level ${lv.level + 1}</small></div>
          <button class="btn" data-act="editprofile" data-focus data-k="pf-edit">${icon('edit')}Edit profile</button>
        </header>
        <nav class="pf-tabs" aria-label="Profile sections">${TABS.map(([id, l, ic]) => `<button class="${ptab === id ? 'on' : ''}" data-act="ptab" data-v="${id}" data-focus data-k="pt-${id}">${icon(ic)}${l}</button>`).join('')}</nav>
        <div class="pf-body" id="pfBody">${BODY[ptab](S)}</div>
      </section>`;
    },
  };

  const swap = () => { const b = document.getElementById('pfBody'); if (!b) return GL.render(); const sc = document.getElementById('main').scrollTop; b.innerHTML = BODY[ptab](GL.S); document.querySelectorAll('.pf-tabs button').forEach((x) => x.classList.toggle('on', x.dataset.v === ptab)); GL.animate(b, 'fade-up'); document.getElementById('main').scrollTop = sc; };

  const A = GL.act;
  A.ptab = (d) => { if (ptab === d.v) return; ptab = d.v; swap(); const k = document.querySelector(`.pf-tabs [data-v="${d.v}"]`); k && k.focus({ preventScroll: true }); };
  A.range = (d) => { range = +d.v; swap(); const k = document.querySelector(`[data-k="r-${range}"]`); k && k.focus({ preventScroll: true }); };
  A.tfilter = (d) => { tfilter = d.v; swap(); const k = document.querySelector(`[data-k="tf-${d.v}"]`); k && k.focus({ preventScroll: true }); };
  A.cfilter = (d) => { cfilter = d.v; swap(); };
  A.editprofile = () => GL.modal.profile();
  A.capture = () => api.invoke('capture:take');
  A.capfolder = () => api.invoke('capture:openFolder');
  A.capview = (d) => {
    const c = (GL.S.captures || []).find((x) => x.id === d.id); if (!c) return;
    GL.modal.open(`<div class="modal lb"><img src="${esc(c.url)}" alt="Screenshot of ${esc(c.label)}">
      <div class="lb-bar"><span><b>${esc(c.label)}</b> · ${GL.dateTime(c.ts)}</span>
        <button class="btn" data-act="capshow" data-id="${esc(c.id)}" data-focus data-k="cv-show">${icon('folder')}Show in folder</button>
        <button class="btn danger" data-act="capdel" data-id="${esc(c.id)}" data-focus data-k="cv-del">${icon('trash')}Delete</button>
        <button class="btn" data-act="closemodal" data-focus data-k="cv-x">Close</button></div></div>`);
  };
  A.capshow = (d) => api.invoke('capture:show', d.id);
  A.capdel = async (d) => { await api.invoke('capture:delete', d.id); GL.modal.close(); };
})();
