'use strict';
// Spatial focus navigation shared by keyboard arrows and gamepad.
window.GL = window.GL || {};
(function () {
  const SEL = '[data-focus]';
  const isField = (el) => el && (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) || el.isContentEditable);

  function scope() { const o = document.getElementById('overlay'); return !o.hidden && o.firstElementChild ? o : document; }
  function items() {
    return [...scope().querySelectorAll(SEL)].filter((el) => {
      if (el.disabled) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
    });
  }

  function focusEl(el, smooth = true) {
    if (!el) return;
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: 'center', inline: 'center', behavior: smooth ? 'smooth' : 'auto' });
  }

  function move(dir) {
    if (GL.showcase) GL.showcase.poke();
    const list = items();
    if (!list.length) return false;
    let cur = document.activeElement;
    if (!cur || !cur.matches || !cur.matches(SEL) || !list.includes(cur)) {
      // Start from the main content's first item (or the first nav tab if none).
      const first = list.find((e) => e.closest('#main, #overlay')) || list[0];
      focusEl(first); return true;
    }
    const a = cur.getBoundingClientRect();
    const ac = { x: a.left + a.width / 2, y: a.top + a.height / 2 };
    let best = null;
    for (const el of list) {
      if (el === cur) continue;
      const b = el.getBoundingClientRect();
      const bc = { x: b.left + b.width / 2, y: b.top + b.height / 2 };
      const dx = bc.x - ac.x, dy = bc.y - ac.y;
      let main, cross, ok;
      if (dir === 'right') { ok = b.left >= a.right - a.width * 0.35 && dx > 4; main = dx; cross = Math.abs(dy); }
      else if (dir === 'left') { ok = b.right <= a.left + a.width * 0.35 && dx < -4; main = -dx; cross = Math.abs(dy); }
      else if (dir === 'down') { ok = b.top >= a.bottom - a.height * 0.35 && dy > 4; main = dy; cross = Math.abs(dx); }
      else { ok = b.bottom <= a.top + a.height * 0.35 && dy < -4; main = -dy; cross = Math.abs(dx); }
      if (!ok) continue;
      const score = main + cross * 2.4;
      if (!best || score < best.score) best = { el, score };
    }
    if (best) { focusEl(best.el); return true; }
    return false;
  }

  GL.nav = { move, items, focusEl, isField };

  document.addEventListener('keydown', (e) => {
    if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey) return;
    const dirs = { ArrowRight: 'right', ArrowLeft: 'left', ArrowDown: 'down', ArrowUp: 'up' };
    if (dirs[e.key] && !isField(document.activeElement)) {
      if (move(dirs[e.key])) e.preventDefault();
    } else if ((e.key === 'Enter' || e.key === ' ') && document.activeElement && document.activeElement.matches && document.activeElement.matches('[data-focus]:not(button):not(a):not(input):not(select):not(textarea)')) {
      e.preventDefault(); document.activeElement.click();
    }
  });

  /* ------------------------------------------------------------ gamepad */
  const held = {}; let connected = false, padCount = 0;
  function pollPad() {
    requestAnimationFrame(pollPad);
    if (!(GL.S && GL.S.settings && GL.S.settings.controller)) return;
    const pads = (navigator.getGamepads && navigator.getGamepads()) || [];
    const pad = [...pads].find((p) => p && p.connected);
    const cnt = [...pads].filter((p) => p && p.connected).length;
    if (!!pad !== connected || cnt !== padCount) { const joined = cnt > padCount; connected = !!pad; padCount = cnt; GL.onController && GL.onController(connected, pad && pad.id, cnt, joined); }
    if (!pad) return;
    const now = performance.now();
    // Controller test page: the pad is being tested, not used to navigate. Hold Select + Start for 1.5 s to leave.
    if (GL.S.view && GL.S.view.name === 'controllers') {
      const both = pad.buttons[8] && pad.buttons[8].pressed && pad.buttons[9] && pad.buttons[9].pressed;
      if (both) { if (!held._exit) held._exit = now; else if (now - held._exit > 1500) { held._exit = 0; GL.back(); } } else held._exit = 0;
      Object.keys(held).forEach((k) => { if (k !== '_exit' && held[k]) held[k].down = true; });
      return;
    }
    held._exit = 0;
    const b = (i) => pad.buttons[i] && pad.buttons[i].pressed;
    const ax = pad.axes[0] || 0, ay = pad.axes[1] || 0;
    const state = {
      up: b(12) || ay < -0.55, down: b(13) || ay > 0.55, left: b(14) || ax < -0.55, right: b(15) || ax > 0.55,
      a: b(0), b: b(1), x: b(2), y: b(3), lb: b(4), rb: b(5), select: b(8), start: b(9),
    };
    for (const k of Object.keys(state)) {
      const h = held[k] || (held[k] = { down: false, next: 0 });
      if (state[k]) {
        const repeat = ['up', 'down', 'left', 'right'].includes(k);
        if (!h.down) { h.down = true; h.next = now + 380; fire(k); } else if (repeat && now >= h.next) { h.next = now + 110; fire(k); }
      } else h.down = false;
    }
  }
  function fire(k) {
    document.body.classList.add('using-pad');
    if (['up', 'down', 'left', 'right'].includes(k)) { if (!isField(document.activeElement)) move(k); else document.activeElement.blur(); return; }
    GL.onPad && GL.onPad(k);
  }
  window.addEventListener('mousemove', () => document.body.classList.remove('using-pad'));
  window.addEventListener('keydown', () => document.body.classList.remove('using-pad'));
  requestAnimationFrame(pollPad);
})();
