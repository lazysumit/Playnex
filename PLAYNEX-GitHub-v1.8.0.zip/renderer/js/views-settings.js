'use strict';
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;
  const api = window.api;
  const set = (patch) => api.invoke('settings:set', patch);
  let tab = 'appearance';

  const TABS = [
    ['appearance', 'Appearance', 'palette', 'Theme, colours, background'],
    ['library', 'Library', 'library', 'Platforms and folders'],
    ['screensaver', 'Screensaver', 'monitor', 'Idle slideshow, clock and music'],
    ['launcher', 'Launcher', 'gamepad', 'Startup, tray, notifications'],
    ['controls', 'Controls', 'keyboard', 'Screenshots, keyboard, controller'],
    ['remote', 'Remote', 'phone', 'Phone control, shut down, restart'],
    ['music', 'Music', 'music', 'Music apps and now playing'],
    ['integrations', 'Integrations', 'external', 'Artwork and Steam'],
    ['data', 'Data', 'folder', 'Backup and about'],
  ];

  /* ---- building blocks ---- */
  const group = (title, body, hint = '') => `<section class="sgroup">${title ? `<header><h2>${title}</h2>${hint ? `<p>${hint}</p>` : ''}</header>` : ''}<div class="scard">${body}</div></section>`;
  const row = (label, hint, control, cls = '') => `<div class="srow ${cls}"><div class="s-lab"><b>${label}</b>${hint ? `<small>${hint}</small>` : ''}</div><div class="s-ctl">${control}</div></div>`;
  const toggle = (key, on) => `<label class="tgl"><input type="checkbox" role="switch" data-set="${key}" ${on ? 'checked' : ''} data-focus data-k="s-${key}"><i></i></label>`;
  const swRow = (key, label, hint, on) => row(label, hint, toggle(key, on));
  const kbd = (...k) => k.map((x) => `<kbd>${esc(x)}</kbd>`).join('<span class="plus">+</span>');

  /* ---- sections ---- */
  function appearance(S) {
    const st = S.settings;
    const themes = [...GL.PRESETS, ...st.customThemes];
    const modes = [['dark', 'Dark', 'moon'], ['light', 'Light', 'sun'], ['system', 'Match Windows', 'settings']];
    const walls = [['dynamic', 'Game artwork', 'The background follows the game you highlight.'], ['custom', 'My image', 'Use your own picture.'], ['none', 'Plain', 'A calm gradient, no artwork.']];
    return group('Colour mode', `<div class="choice3">${modes.map(([v, l, ic]) => `<button class="choice mode-${v}${st.themeMode === v ? ' on' : ''}" data-act="mode" data-v="${v}" data-focus data-k="m-${v}"><span class="mock"><i></i><i></i><i></i></span><span class="c-t">${icon(ic)}${l}</span></button>`).join('')}</div>`) +
      group('Theme', `<div class="themes2">${themes.map((t) => `<button class="theme2${st.themeId === t.id ? ' on' : ''}" data-act="pickTheme" data-id="${esc(t.id)}" data-focus data-k="th-${esc(t.id)}" style="--a:${t.accent};--b:${t.bg}"><span class="tp"><i class="tp-bar"></i><i class="tp-tile"></i><i class="tp-tile"></i><i class="tp-btn"></i></span><b>${esc(t.name)}</b>${st.themeId === t.id ? `<span class="ck">${icon('check')}</span>` : ''}${t.custom ? `<span class="x" data-act="deltheme" data-id="${esc(t.id)}" role="button" aria-label="Delete theme">${icon('close')}</span>` : ''}</button>`).join('')}</div>
        <form class="theme-make" id="themeForm"><b>Create your own</b>
          <label>Name<input name="name" maxlength="20" placeholder="My theme" data-focus data-k="th-name"></label>
          <label>Accent<input type="color" name="accent" value="#ff7a45" data-focus data-k="th-accent"></label>
          <label>Background<input type="color" name="bg" value="#0a0d16" data-focus data-k="th-bg"></label>
          <button class="btn primary" type="submit" data-focus data-k="th-save">Save theme</button></form>`) +
      group('Background', `<div class="choice3">${walls.map(([v, l, h]) => `<button class="choice wall-${v}${st.wallpaper === v ? ' on' : ''}" data-act="wall" data-v="${v}" data-focus data-k="w-${v}"><span class="mock wall"><i></i></span><span class="c-t"><b>${l}</b><small>${h}</small></span></button>`).join('')}</div>
        ${row('Custom image', st.customBackground ? 'A custom image is set.' : 'Pick a picture from your PC.', `<div class="btn-row nm"><button class="btn" data-act="pickbg" data-focus data-k="bg-pick">${icon('image')}Choose image</button>${st.customBackground ? '<button class="btn ghost" data-act="clearbg" data-focus data-k="bg-clear">Remove</button>' : ''}</div>`)}
        ${row('Light mode brightness', 'Lower is softer and easier on the eyes. Only affects the light theme.', `<input class="rng" type="range" min="0" max="100" step="5" value="${st.lightTone == null ? 40 : st.lightTone}" data-range="lightTone" data-focus data-k="s-lighttone" aria-label="Light mode brightness">`)}
        ${row('Glass effect', 'How frosted the Home shelf and stats pill look. Higher is glassier.', `<input class="rng" type="range" min="0" max="100" step="5" value="${st.glassLevel == null ? 60 : st.glassLevel}" data-range="glassLevel" data-focus data-k="s-glass" aria-label="Glass effect">`)}
        ${row('Dimming', 'Darken the background so text stays readable.', `<input class="rng" type="range" min="0" max="0.9" step="0.05" value="${st.bgDim}" data-range="bgDim" data-focus data-k="s-dim" aria-label="Dimming">`)}
        ${row('Blur', 'Soften the background artwork.', `<input class="rng" type="range" min="0" max="24" step="1" value="${st.bgBlur}" data-range="bgBlur" data-focus data-k="s-blur" aria-label="Blur">`)}`);
  }

  function library(S) {
    const st = S.settings;
    return group('Platforms to detect', `<div class="plat2">${Object.keys(GL.PLATFORM).filter((p) => p !== 'manual' && p !== 'custom').map((p) => `<label class="plat2-i"><i style="background:${GL.PLATFORM[p].color}"></i><span>${esc(GL.PLATFORM[p].name)}</span><span class="tgl"><input type="checkbox" role="switch" data-plat="${p}" ${st.platforms[p] !== false ? 'checked' : ''} data-focus data-k="sp-${p}"><i></i></span></label>`).join('')}</div>`, 'Turn off launchers you don\'t use to make scans faster.') +
      group('Scanned folders', `${st.scanFolders.length ? `<ul class="folders">${st.scanFolders.map((f, i) => `<li><span>${icon('folder')}${esc(f)}</span><button class="btn ghost sm" data-act="rmfolder" data-i="${i}" data-focus data-k="sf-${i}" aria-label="Remove folder">${icon('trash')}</button></li>`).join('')}</ul>` : '<p class="muted pad-s">No folders added yet. Add a folder that contains games installed outside a launcher.</p>'}
        <div class="btn-row pad-s"><button class="btn" data-act="scanfolder" data-focus data-k="sf-add">${icon('plus')}Add folder</button><button class="btn" data-act="addgame" data-focus data-k="sf-exe">${icon('plus')}Add a program</button><button class="btn primary" data-act="scan" data-focus data-k="sf-scan">${icon('refresh')}Scan now</button></div>`) +
      group('', swRow('scanOnStartup', 'Scan when the app starts', 'Finds newly installed or removed games automatically.', st.scanOnStartup));
  }

  const SRC_NAME = { wallhaven: 'Wallhaven', bing: 'Bing', wallpapercave: 'WallpaperCave', wallhalla: 'Wallhalla' };
  const wallStatus = (S) => {
    const w = S.wall || { diag: {}, busy: false, found: 0, shown: 0, active: 0, fetchedAt: 0 };
    const chips = Object.keys(w.diag || {}).map((k) => { const d = w.diag[k]; const txt = d.error ? `couldn't reach it (${esc(d.error)})` : d.found ? `${d.found} available${d.shown ? ` · ${d.shown} shown` : ''}${d.failed ? ` · ${d.failed} skipped` : ''}` : 'nothing found'; return `<span class="wd ${d.error ? 'bad' : d.found ? 'ok' : 'meh'}">${SRC_NAME[k] || k}: ${txt}</span>`; }).join('');
    return `${w.busy ? 'Checking the sources…' : w.found ? `${w.found} pictures available online${w.fetchedAt ? ` · checked ${GL.ago(w.fetchedAt)}` : ''}` : 'Not checked yet'} · ${(w.active || 0) + (w.saved || 0)} on this PC right now${w.folder ? `<br><code class="wpath">${GL.esc ? GL.esc(w.folder) : w.folder}</code>` : ''}<span class="wds">${chips}</span>`;
  };

  function screensaver(S) {
    const st = S.settings; const wl = S.wall || { diag: {}, busy: false };
    return group('Library showcase', swRow('showcaseEnabled', 'Idle showcase in the library', 'After a pause, the library fades into a slideshow of your game banners with a short description and stats. Move the mouse or press any key to leave it.', st.showcaseEnabled) +
        row('Start after', 'How long with no activity before it begins.', `<select class="sel" data-num="showcaseDelay" data-focus data-k="s-scdelay" aria-label="Start after">${[[5, '5 seconds'], [10, '10 seconds'], [15, '15 seconds'], [30, '30 seconds'], [60, '1 minute'], [120, '2 minutes'], [300, '5 minutes']].map(([v, l]) => `<option value="${v}" ${+st.showcaseDelay === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        row('Time per game', 'How long each banner stays on screen.', `<select class="sel" data-num="showcaseSlide" data-focus data-k="s-scslide" aria-label="Time per game">${[[5, '5 seconds'], [8, '8 seconds'], [10, '10 seconds'], [15, '15 seconds'], [20, '20 seconds'], [30, '30 seconds']].map(([v, l]) => `<option value="${v}" ${+st.showcaseSlide === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        row('Preview', 'See it right now.', `<button class="btn" data-act="showcasenow" data-focus data-k="s-showcase-now">${icon('play')}Preview showcase</button>`)) +
      group('Screensaver pictures', row('Pictures to show', 'What the full-screen screensaver plays. Online pictures are fetched one at a time while it runs. The Library showcase always uses your game banners.', `<select class="sel" data-text="saverSource" data-focus data-k="s-src" aria-label="Pictures to show">${[['games', 'Library game banners'], ['web', 'Online wallpapers'], ['mix', 'Both, mixed']].map(([v, l]) => `<option value="${v}" ${(st.saverSource || 'games') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        row('Minimum quality', 'Only 16:9 pictures at least this sharp are used.', `<select class="sel" data-text="saverWebQuality" data-focus data-k="s-wq" aria-label="Minimum quality">${[['2k', '2K QHD · 2560 × 1440'], ['4k', '4K UHD · 3840 × 2160']].map(([v, l]) => `<option value="${v}" ${(st.saverWebQuality || '2k') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        swRow('saverWebKeep', 'Keep downloaded pictures', 'Off: pictures are deleted the moment the launcher closes. On: they stay on this PC, so the screensaver still works when you are offline.', st.saverWebKeep === true) +
        (st.saverWebKeep === true ? row('Keep up to', 'When this many are saved, each new picture replaces the oldest one, which is deleted.', `<select class="sel" data-num="saverWebCap" data-focus data-k="s-wcap" aria-label="Keep up to">${[[20, '20 pictures'], [40, '40 pictures'], [80, '80 pictures']].map(([val, l]) => `<option value="${val}" ${(Number(st.saverWebCap) || 40) === val ? 'selected' : ''}>${l}</option>`).join('')}</select>`) : '') +
        swRow('saverWebCaption', 'Show picture title', 'Title, source and resolution in the corner of online wallpapers.', st.saverWebCaption !== false) +
        row('Online pictures', wallStatus(S), `<div class="btn-row"><button class="btn" data-act="wallcheck" data-focus data-k="s-wchk" ${wl.busy ? 'disabled' : ''}>${icon('refresh')}${wl.busy ? 'Checking…' : 'Check sources'}</button><button class="btn" data-act="wallopen" data-focus data-k="s-wopen">${icon('folder')}Open folder</button><button class="btn" data-act="wallclear" data-focus data-k="s-wclr">${icon('trash')}Delete pictures</button></div>`)) +
      group('Online sources', swRow('saverWebWallhaven', 'Wallhaven', 'Official wallpaper API. Reliable, huge 4K and 2K collection.', st.saverWebWallhaven !== false) +
        swRow('saverWebBing', 'Bing daily photos', 'Bing\'s picture of the day, in 4K. Landscapes, wildlife and places.', st.saverWebBing !== false) +
        swRow('saverWebCave', 'WallpaperCave', 'Reads the site\'s pages (it has no API), so it can stop working if the site changes.', st.saverWebCave !== false) +
        swRow('saverWebHalla', 'Wallhalla', 'Reads the site\'s pages (it has no API), so it can stop working if the site changes.', st.saverWebHalla !== false)) +
      group('Topics', [['Gaming', 'Gaming', 1], ['Nature', 'Nature', 1], ['Animals', 'Animals', 1], ['Space', 'Space', 0], ['Cars', 'Cars', 0], ['Cities', 'Cities', 0]].map(([k, l, d]) => swRow('saverCat' + k, l, '', st['saverCat' + k] == null ? !!d : st['saverCat' + k])).join(''), 'Used by Wallhaven and WallpaperCave. Everything is family-friendly.') +
      group('Screensaver', swRow('saverEnabled', 'Full-screen screensaver', 'After a longer pause anywhere in the launcher, everything hides and your game banners play full screen with a short description and stats. Move the mouse or press any key to leave. It never starts while a game is running.', st.saverEnabled) +
        row('Start after', 'How long with no activity before it begins.', `<select class="sel" data-num="saverDelay" data-focus data-k="s-sdelay" aria-label="Screensaver start after">${[[30, '30 seconds'], [60, '1 minute'], [120, '2 minutes'], [300, '5 minutes'], [600, '10 minutes'], [900, '15 minutes']].map(([v, l]) => `<option value="${v}" ${+st.saverDelay === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        row('Time per game', 'How long each banner stays on screen.', `<select class="sel" data-num="saverSlide" data-focus data-k="s-sslide" aria-label="Screensaver time per game">${[[5, '5 seconds'], [8, '8 seconds'], [12, '12 seconds'], [20, '20 seconds']].map(([v, l]) => `<option value="${v}" ${+st.saverSlide === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        swRow('saverClock', 'Show clock', 'Display the time over the banners.', st.saverClock !== false) +
        row('Clock size', 'Make the time smaller or larger.', `<input class="rng" type="range" min="40" max="220" step="4" value="${st.saverClockSize || 96}" data-range="saverClockSize" data-focus data-k="s-clocksize" aria-label="Clock size">`) +
        swRow('saverDate', 'Show date', 'Show the day and date under the time.', st.saverDate !== false) +
        row('Clock position', 'Where the clock sits on the screen.', `<select class="sel" data-text="saverClockPos" data-focus data-k="s-clockpos" aria-label="Clock position">${[['top-right', 'Top right'], ['top-left', 'Top left'], ['bottom-right', 'Bottom right'], ['bottom-left', 'Bottom left'], ['center', 'Centre']].map(([v, l]) => `<option value="${v}" ${st.saverClockPos === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        row('Time format', '', `<select class="sel" data-text="saverClockFmt" data-focus data-k="s-clockfmt" aria-label="Time format">${[['auto', 'Match Windows'], ['12', '12-hour'], ['24', '24-hour']].map(([v, l]) => `<option value="${v}" ${st.saverClockFmt === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        swRow('saverMusic', 'Show music while playing', 'Shows the song, artist and cover on the screensaver and the Library showcase while something is playing.', st.saverMusic !== false) +
        row('Music position', 'Which corner the music card uses. It moves aside if it shares a corner with the clock.', `<select class="sel" data-text="saverMusicPos" data-focus data-k="s-mpos" aria-label="Music position">${[['bottom-right', 'Bottom right'], ['bottom-left', 'Bottom left'], ['top-right', 'Top right'], ['top-left', 'Top left'], ['bottom-center', 'Bottom centre']].map(([v, l]) => `<option value="${v}" ${(st.saverMusicPos || 'bottom-right') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`) +
        row('Music size', 'Make the music card smaller or larger.', `<input class="rng" type="range" min="70" max="200" step="10" value="${st.saverMusicSize || 100}" data-range="saverMusicSize" data-focus data-k="s-msize" aria-label="Music size">`) +
        row('Preview', 'See it right now.', `<button class="btn" data-act="savernow" data-focus data-k="s-saver-now">${icon('play')}Preview screensaver</button>`));
  }

  function remote(S) {
    const st = S.settings, r = S.remote || {}, pw = S.power || {};
    const when = (t) => (t ? new Date(t).toLocaleDateString([], { day: 'numeric', month: 'short' }) + ' ' + new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'never');
    const pending = pw.pending && pw.pending.at > Date.now() - 1000;
    let phone = swRow('remoteEnabled', 'Allow my phone to connect', 'Starts a small server on this PC that only phones on your own network (or your own VPN) can reach. It is off until you turn it on, and every phone needs a one-time code.', st.remoteEnabled === true);
    if (st.remoteEnabled === true) {
      phone += r.error ? row('Problem', esc(r.error), '') : '';
      phone += row('Address', 'Open this on your phone\'s browser (same Wi-Fi, or through your VPN) and add it to the home screen. Windows may ask to allow PLAYNEX through the firewall: choose Private networks.', (r.urls && r.urls.length ? `<div class="addrs">${r.urls.map((u) => `<code class="wpath">${esc(u)}</code>`).join('')}</div>` : '<span class="muted">Starting…</span>'));
      phone += row('Port', 'Change it only if another program already uses it.', `<select class="sel" data-num="remotePort" data-focus data-k="s-rport" aria-label="Port">${[47600, 47601, 47602, 8787, 8090].map((p) => `<option value="${p}" ${(Number(st.remotePort) || 47600) === p ? 'selected' : ''}>${p}</option>`).join('')}</select>`);
      phone += r.pairing
        ? row('Pairing code', 'Type this on your phone within 3 minutes. It works once.', `<div class="pcode">${esc(r.pairing.code)}</div><button class="btn" data-act="remotecancelpair" data-focus data-k="s-rcancel">Cancel</button>`)
        : row('Pair a phone', r.locked ? 'Too many wrong codes. Try again in a few minutes.' : 'Shows a one-time code to type on your phone.', `<button class="btn" data-act="remotepair" data-focus data-k="s-rpair" ${r.locked ? 'disabled' : ''}>${icon('phone')}Pair a phone</button>`);
      phone += swRow('remotePower', 'Allow shut down and restart from the phone', 'You always get 10 seconds to cancel. Screenshot, music and quit game stay available either way.', st.remotePower !== false);
    }
    const devices = st.remoteEnabled === true || (r.devices && r.devices.length)
      ? group('Paired phones', (r.devices && r.devices.length ? r.devices.map((d, n) => row(esc(d.name), `Paired ${when(d.created)} · last seen ${when(d.lastSeen)}`, `<button class="btn" data-act="remoterevoke" data-id="${esc(d.id)}" data-focus data-k="s-rdev-${n}">Remove</button>`)).join('') : row('No phones paired', 'Pair one above.', '')), 'A removed phone loses access straight away.') : '';
    const power = group('Power', (pending ? row(pw.pending.action === 'restart' ? 'Restarting…' : 'Shutting down…', 'The PC is counting down. You can still cancel.', `<button class="btn" data-act="powercancel" data-focus data-k="s-pcancel">Cancel</button>`) : '') +
      row('Shut down', 'Turns this PC off after a 10-second countdown.', `<button class="btn danger" data-act="powerrun" data-kind="shutdown" data-focus data-k="s-pshut">${icon('power')}Shut down</button>`) +
      row('Restart', 'Restarts this PC after a 10-second countdown.', `<button class="btn" data-act="powerrun" data-kind="restart" data-focus data-k="s-prestart">${icon('refresh')}Restart</button>`) +
      swRow('powerForce', 'Force-close open apps', 'Off: Windows asks apps to close and may wait if one has unsaved work. On: apps are closed without asking, so unsaved work is lost.', st.powerForce === true), 'Works from this screen and from your phone.');
    return power + group('Phone remote', phone, 'See what is running, take a screenshot, control music and quit a game from your phone.') + devices;
  }

  function launcher(S) {
    const st = S.settings;
    return group('Startup & window', swRow('closeToTray', 'Keep running in the tray when closed', 'Playtime keeps tracking in the background. Quit from the tray icon.', st.closeToTray) +
      swRow('startMinimized', 'Start minimised to the tray', '', st.startMinimized) + swRow('launchAtLogin', 'Start with Windows', '', st.launchAtLogin)) +
      group('Notifications', swRow('notifications', 'Desktop notifications', 'Session summaries, new games, screenshots and achievements.', st.notifications));
  }

  function controls(S) {
    const st = S.settings;
    const keys = ['F11', 'F12', 'F9', 'PrintScreen', 'Ctrl+Shift+S'];
    const sc = [[['1'], 'Home'], [['2'], 'Library'], [['3'], 'Profile'], [['4'], 'Settings'], [['/'], 'Search'], [['P'], 'Play selected game'], [['F'], 'Favourite'], [['T'], 'Dark / light'], [['F10'], 'Full screen'], [['Esc'], 'Back'], [['?'], 'All shortcuts']];
    const pad = [[['A'], 'Select'], [['B'], 'Back'], [['X'], 'Favourite'], [['Y'], 'Search'], [['LB'], 'Previous tab'], [['RB'], 'Next tab'], [['Start'], 'Play']];
    return group('Controller', row('Controller test', 'See every button, stick and trigger live, test vibration, and check each connected controller.', `<button class="btn" data-act="controllers" data-focus data-k="s-padtest">${icon('gamepad')}Open controller test</button>`)) + group('In-game overlay', swRow('overlayEnabled', 'Enable the overlay', 'Press the shortcut while you play to open a panel over your game: music (play, skip, volume, album art), the current game with its session timer, screenshot, quit game, recent games, controllers and CPU / RAM. Works over windowed and borderless games; exclusive full-screen games hide it.', st.overlayEnabled !== false) +
      row('Shortcut', 'Works anywhere in Windows, even while the launcher is in the background.', `<select class="sel" data-text="overlayKey" data-focus data-k="s-ovkey" aria-label="Overlay shortcut">${['Ctrl+Shift+G', 'Ctrl+Alt+G', 'Ctrl+Shift+Tab', 'Alt+Z', 'F9', 'F8'].map((k) => `<option ${(st.overlayKey || 'Ctrl+Shift+G') === k ? 'selected' : ''}>${k}</option>`).join('')}</select>`) +
      row('Preview', 'Open it now to see what it looks like.', `<button class="btn" data-act="overlaynow" data-focus data-k="s-ovnow">${icon('play')}Open overlay</button>`)) + group('Screenshots', swRow('captureEnabled', 'Screenshot hotkey', 'Works while a game is running, even when the launcher is in the background.', st.captureEnabled) +
      row('Hotkey', 'Pick a key that doesn\'t clash with your games.', `<select class="sel" data-text="captureKey" data-focus data-k="s-capkey" aria-label="Screenshot hotkey">${keys.map((k) => `<option ${st.captureKey === k ? 'selected' : ''}>${k}</option>`).join('')}</select>`) +
      swRow('captureSound', 'Play the notification sound', '', st.captureSound) +
      row('Saved to', 'Pictures › PLAYNEX › (game name)', `<div class="btn-row nm"><button class="btn" data-act="capfolder" data-focus data-k="cp-folder">${icon('folder')}Open folder</button><button class="btn" data-act="capture" data-focus data-k="cp-test">${icon('camera')}Test capture</button></div>`),
    'Games running in exclusive full-screen can show black. Switch the game to borderless or windowed if that happens.') +
      group('Controller', swRow('controller', 'Controller navigation', 'Use a gamepad to move around, select and launch games.', st.controller) +
        `<div class="keys-grid pad-s">${pad.map(([k, l]) => `<div><span>${kbd(...k)}</span><em>${l}</em></div>`).join('')}</div>`) +
      group('Keyboard shortcuts', `<div class="keys-grid pad-s">${sc.map(([k, l]) => `<div><span>${kbd(...k)}</span><em>${l}</em></div>`).join('')}<div><span>${kbd(st.captureKey || 'F11')}</span><em>Screenshot</em></div></div>`);
  }

  function integrations(S) {
    const st = S.settings;
    return group('SteamGridDB', `${row('API key', 'Optional. Better covers, banners and logos for games that aren\'t on Steam. Free key at steamgriddb.com › Preferences › API.', `<input class="txt" type="password" data-text="steamGridDbKey" value="${esc(st.steamGridDbKey)}" placeholder="Paste key" autocomplete="off" data-focus data-k="i-sgdb">`, 'stack')}`) +
      group('Ratings & reviews', row('RAWG API key', 'Optional. Adds RAWG player ratings. Metacritic and Steam reviews work without any key. Free key at rawg.io/apidocs.', `<input class="txt" type="password" data-text="rawgKey" value="${esc(st.rawgKey)}" placeholder="Paste key" autocomplete="off" data-focus data-k="i-rawg">`)) +
      group('Steam achievements', `${row('Web API key', 'Optional. Shows your Steam achievements on game pages (your Steam game details must be public).', `<input class="txt" type="password" data-text="steamApiKey" value="${esc(st.steamApiKey)}" placeholder="steamcommunity.com/dev/apikey" autocomplete="off" data-focus data-k="i-key">`, 'stack')}${row('SteamID64', '', `<input class="txt" type="text" data-text="steamId" value="${esc(st.steamId)}" placeholder="7656119…" autocomplete="off" data-focus data-k="i-sid">`, 'stack')}`) +
      group('Artwork', row('Find missing artwork', 'Covers, banners, logos and screenshots are matched automatically using the Steam store.', `<div class="btn-row nm"><button class="btn" data-act="refreshall" data-focus data-k="i-fill">${icon('refresh')}Find missing</button><button class="btn" data-act="refreshforce" data-focus data-k="i-force">Re-download all</button></div>`));
  }

  function data(S) {
    return group('Your data', row('Data folder', 'Library, playtime and settings are stored on this PC only.', `<button class="btn" data-act="opendata" data-focus data-k="d-open">${icon('folder')}Open</button>`) +
      row('Backup', 'Save everything to a single file.', `<button class="btn" data-act="export" data-focus data-k="d-export">${icon('external')}Export backup</button>`)) +
      group('About', swRow('showBrand', 'Show PLAYNEX name on the top bar', 'Shows the PLAYNEX name next to the logo. Off keeps only the logo.', S.settings.showBrand === true) +
        row('PLAYNEX ' + (S.version || ''), `EVERY GAME. ONE DESTINATION · ${GL.all().length} games · ${S.sessions.length} sessions recorded`, `<button class="btn danger" data-act="quit" data-focus data-k="d-quit">Quit PLAYNEX</button>`));
  }

  function music(S) {
    const st = S.settings, m = S.music || {}, apps = [...(m.installed || []), ...(st.musicApps || []).map((a) => ({ ...a, custom: true }))];
    const now = (m.now || []).filter((x) => x.status === 'playing')[0] || (m.now || [])[0];
    const list = apps.length ? apps.map((a) => `<div class="srow mapp"><div class="s-lab"><span class="m-dot" style="background:${esc(a.color || 'var(--accent)')}"></span><b>${esc(a.name)}</b><small>${a.custom ? 'Added by you' : 'Detected on this PC'}</small></div>
        <div class="s-ctl"><button class="btn" data-act="musiclaunch" data-id="${esc(a.id)}" data-focus data-k="m-l-${esc(a.id)}">${icon('play')}Open</button>${a.custom ? `<button class="btn icon" data-act="musicremove" data-id="${esc(a.id)}" data-focus data-k="m-r-${esc(a.id)}" aria-label="Remove ${esc(a.name)}">${icon('trash')}</button>` : ''}</div></div>`).join('')
      : `<div class="srow"><div class="s-lab"><b>No music apps found yet</b><small>Press Detect again, or add your player by hand.</small></div></div>`;
    return group('Now playing', swRow('musicEnabled', 'Show what\'s playing', 'A small music icon appears at the top while something is playing. Click it for track info and play, pause and skip.', st.musicEnabled !== false) +
        swRow('musicBrowser', 'Include browser players', 'Picks up SoundCloud, YouTube Music and other web players running in Chrome, Edge or Firefox.', st.musicBrowser !== false) +
        swRow('musicArtLookup', 'Find album art online', 'If a player does not provide a cover, look the song up on Apple\'s public iTunes Search. Only the artist and song name are sent.', st.musicArtLookup !== false) +
        (() => { const d = (GL.S.music && GL.S.music.diag) || null; return d ? row('Album art status', 'From the player, from online lookup, and the last problem seen.', `<span class="sub">${d.fromApp} from player · ${d.fromLookup} online${d.lastError ? ' · ' + esc(d.lastError) : ''}</span>`) : ''; })() +
        row('Right now', now ? esc(now.app) : 'Nothing is playing.', now ? `<b class="m-now">${esc(now.title)}${now.artist ? ' · ' + esc(now.artist) : ''}</b>` : '<span class="muted">—</span>') ) +
      group('Music apps', list + row('', 'Add any player PLAYNEX did not find, or find them again.', `<button class="btn" data-act="musicadd" data-focus data-k="m-add">${icon('plus')}Add music app</button><button class="btn" data-act="musicdetect" data-focus data-k="m-det">${icon('refresh')}Detect again</button>`))
      + (m.available === false ? group('', row('Windows only', 'Now playing and app detection need Windows.', '')) : '');
  }

  const BODY = { appearance, library, screensaver, launcher, controls, remote, music, integrations, data };

  GL.views.settings = {
    html(S) {
      const cur = TABS.find((t) => t[0] === tab);
      return `<section class="settings2"><div class="s2-wrap">
        <aside class="s2-nav"><h1>Settings</h1><nav aria-label="Settings sections">${TABS.map(([id, l, ic, d]) => `<button class="${tab === id ? 'on' : ''}" data-act="stab" data-v="${id}" data-focus data-k="st-${id}"><span class="s-ic">${icon(ic)}</span><span><b>${l}</b><small>${d}</small></span></button>`).join('')}</nav></aside>
        <div class="s2-body" id="sBody"><h2 class="s2-title">${cur[1]}</h2>${BODY[tab](S)}</div></div></section>`;
    },
    after() { bind(); },
    patch() { /* settings apply live; refresh the visible section in place */
      const b = document.getElementById('sBody'); if (!b) return;
      const act = document.activeElement; const k = act && act.dataset && act.dataset.k;
      const sc = document.getElementById('main').scrollTop;
      b.innerHTML = `<h2 class="s2-title">${TABS.find((t) => t[0] === tab)[1]}</h2>` + BODY[tab](GL.S); bind(); document.getElementById('main').scrollTop = sc;
      if (k) { const el = b.querySelector(`[data-k="${CSS.escape(k)}"]`); el && el.focus({ preventScroll: true }); }
    },
  };

  function bind() {
    const root = document.getElementById('sBody'); if (!root) return;
    root.querySelectorAll('[data-set]').forEach((el) => el.addEventListener('change', () => set({ [el.dataset.set]: el.checked })));
    root.querySelectorAll('[data-plat]').forEach((el) => el.addEventListener('change', () => { set({ platforms: { [el.dataset.plat]: el.checked } }); }));
    root.querySelectorAll('[data-num]').forEach((el) => el.addEventListener('change', () => set({ [el.dataset.num]: Number(el.value) })));
    root.querySelectorAll('[data-num]').forEach((el) => el.addEventListener('change', () => set({ [el.dataset.num]: Number(el.value) })));
    root.querySelectorAll('[data-text]').forEach((el) => el.addEventListener('change', () => set({ [el.dataset.text]: el.value.trim() })));
    root.querySelectorAll('[data-range]').forEach((el) => {
      el.addEventListener('input', () => { const v = +el.value; GL.S.settings[el.dataset.range] = v; GL.applyTheme(); });
      el.addEventListener('change', () => set({ [el.dataset.range]: +el.value }));
    });
    const f = document.getElementById('themeForm');
    f && f.addEventListener('submit', (e) => {
      e.preventDefault();
      const d = new FormData(f); const name = String(d.get('name') || '').trim() || 'Custom';
      const t = { id: 'custom-' + Date.now().toString(36), name, accent: d.get('accent'), bg: d.get('bg'), custom: true };
      set({ customThemes: [...GL.S.settings.customThemes, t], themeId: t.id });
    });
  }

  const A = GL.act;
  A.stab = (d) => {
    if (tab === d.v) return; tab = d.v;
    const b = document.getElementById('sBody'); if (!b) return GL.render();
    b.innerHTML = `<h2 class="s2-title">${TABS.find((t) => t[0] === tab)[1]}</h2>` + BODY[tab](GL.S); bind();
    document.querySelectorAll('.s2-nav button').forEach((x) => x.classList.toggle('on', x.dataset.v === tab));
    GL.animate(b, 'fade-up'); document.getElementById('main').scrollTop = 0;
    const k = document.querySelector(`.s2-nav [data-v="${tab}"]`); k && k.focus({ preventScroll: true });
  };
  A.overlaynow = () => { setTimeout(() => api.invoke('overlay:toggle'), 300); };
  A.wallcheck = () => { api.invoke('wall:check'); };
  A.wallopen = async () => { const r = await api.invoke('wall:open'); if (r && r.error) GL.toast({ title: 'Could not open folder', body: r.error, type: 'library' }); };
  A.wallclear = async () => { await api.invoke('wall:clear'); GL.toast({ title: 'Pictures deleted', body: 'Downloaded wallpapers were removed from this PC.', type: 'library' }); };
  A.savernow = () => { setTimeout(() => GL.showcase && GL.showcase.start(true, 'saver'), 250); };
  A.showcasenow = () => { GL.go('library'); setTimeout(() => GL.showcase && GL.showcase.start(true), 350); };
  A.mode = (d) => set({ themeMode: d.v });
  A.pickTheme = (d) => set({ themeId: d.id });
  A.deltheme = (d, e) => { e.stopPropagation(); const S = GL.S.settings; set({ customThemes: S.customThemes.filter((t) => t.id !== d.id), themeId: S.themeId === d.id ? 'midnight' : S.themeId }); };
  A.wall = (d) => set({ wallpaper: d.v });
  A.pickbg = () => api.invoke('settings:setBackground', 'pick');
  A.clearbg = () => api.invoke('settings:setBackground', 'clear');
  A.rmfolder = (d) => api.invoke('library:removeFolder', GL.S.settings.scanFolders[+d.i]);
  A.refreshall = () => { api.invoke('library:refreshAll', {}); GL.toast({ title: 'Looking for artwork', body: 'Covers and details will appear as they download.', type: 'library' }); };
  A.refreshforce = () => { api.invoke('library:refreshAll', { force: true }); GL.toast({ title: 'Re-downloading artwork', body: 'This can take a minute for large libraries.', type: 'library' }); };
  A.opendata = () => api.invoke('app:openDataDir');
  A.export = async () => { const ok = await api.invoke('app:exportData'); if (ok === true) GL.toast({ title: 'Backup saved', body: '', type: 'library' }); };
  A.musiclaunch = (d) => api.invoke('music:launch', d.id);
  A.musicadd = () => api.invoke('music:add');
  A.musicremove = (d) => api.invoke('music:remove', d.id);
  A.musicdetect = async () => { GL.toast({ title: 'Music', body: 'Looking for music apps…', type: 'info' }); await api.invoke('music:detect'); };
  A.remotepair = async () => { const r = await api.invoke('remote:pair'); if (!r) GL.toast({ title: 'Pairing locked', body: 'Too many wrong codes. Try again in a few minutes.', type: 'error' }); };
  A.remotecancelpair = () => api.invoke('remote:cancelPair');
  A.remoterevoke = (d) => api.invoke('remote:revoke', d.id);
  A.powerrun = async (d) => { const r = await api.invoke('power:run', d.kind); if (r && !r.ok && !r.cancelled) GL.toast({ title: d.kind === 'restart' ? 'Could not restart' : 'Could not shut down', body: r.error || 'Windows refused the request.', type: 'error' }); };
  A.powercancel = async () => { const r = await api.invoke('power:cancel'); GL.toast({ title: r && r.ok ? 'Cancelled' : 'Nothing to cancel', body: '', type: 'info' }); };
  A.quit = () => api.invoke('app:quit');
})();
