'use strict';
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;
  const api = window.api;

  const SORTS = [['name', 'Name'], ['playtime', 'Playtime'], ['lastPlayed', 'Last played'], ['added', 'Date added'], ['platform', 'Platform']];

  function filtered() {
    const S = GL.S, f = S.lib, st = S.settings;
    let list = f.hidden ? GL.hiddenGames() : GL.all();
    const q = f.q.trim().toLowerCase();
    if (q) list = list.filter((g) => (g.title + ' ' + (GL.PLATFORM[g.platform] || {}).name + ' ' + ((g.meta && g.meta.genres) || []).join(' ') + ' ' + ((g.meta && g.meta.developers) || []).join(' ')).toLowerCase().includes(q));
    if (f.platform !== 'all') list = list.filter((g) => g.platform === f.platform);
    if (f.collection !== 'all') { const c = S.collections.find((x) => x.id === f.collection); const ids = new Set(c ? c.gameIds : []); list = list.filter((g) => ids.has(g.id)); }
    if (f.fav) list = list.filter((g) => g.favorite);
    const dir = st.libDir === 'desc' ? -1 : 1;
    const key = st.libSort || 'name';
    list.sort((a, b) => {
      let r;
      if (key === 'name') r = a.title.localeCompare(b.title, undefined, { sensitivity: 'base', numeric: true });
      else if (key === 'platform') r = (a.platform + a.title).localeCompare(b.platform + b.title);
      else r = (a[key] || 0) - (b[key] || 0);
      return r * dir || a.title.localeCompare(b.title);
    });
    return list;
  }

  function hiddenHtml(list) {
    if (!list.length) return `<div class="empty-lib">${icon('eyeOff')}<h3>No hidden games</h3><p>Games you hide from the library will show up here so you can bring them back.</p></div>`;
    return `<div class="hid-note">${icon('eyeOff')}Showing hidden games. They stay out of Home, Stats and the screensaver until you show them again.</div><div class="list" role="list">${list.map((g) => `<div class="lrow hid" role="listitem">
      <span class="l-ic">${GL.square(g)}</span><span class="l-t"><b>${esc(g.title)}</b>${GL.pill(g.platform)}</span>
      <button class="btn" data-act="unhide" data-id="${esc(g.id)}" data-focus data-k="uh-${esc(g.id)}">${icon('eye')}Show in library</button></div>`).join('')}</div>`;
  }

  function gridHtml(list) {
    const S = GL.S;
    if (S.lib.hidden) return hiddenHtml(list);
    if (!list.length) {
      const any = GL.all().length;
      return `<div class="empty-lib">${icon('search')}<h3>${any ? 'No games match your filters' : 'No games yet'}</h3><p>${any ? 'Try a different search, or clear the filters.' : 'Scan this PC or add a game to get started.'}</p>
        ${any ? '<button class="btn" data-act="clearfilters" data-focus data-k="lf-clear">Clear filters</button>' : '<button class="btn primary" data-act="scan" data-focus data-k="lf-scan">Scan for games</button>'}</div>`;
    }
    if (S.settings.libView === 'list') {
      return `<div class="list" role="list">${list.map((g) => `<button class="lrow" role="listitem" data-act="open" data-id="${esc(g.id)}" data-game="${esc(g.id)}" data-focus data-k="l-${esc(g.id)}">
        <span class="l-ic">${GL.square(g)}</span><span class="l-t"><b>${esc(g.title)}${g.favorite ? ` <i class="fav-i">${icon('starFill')}</i>` : ''}</b>${GL.pill(g.platform)}</span>
        <span class="l-p" data-act="launch" data-id="${esc(g.id)}" role="button" aria-label="Play ${esc(g.title)}">${icon('play')}</span></button>`).join('')}</div>`;
    }
    return `<div class="grid-lib">${list.map((g) => GL.card(g, 'g')).join('')}</div>`;
  }

  function counts() { const m = {}; GL.all().forEach((g) => { m[g.platform] = (m[g.platform] || 0) + 1; }); return m; }

  GL.views.library = {
    html(S) {
      const f = S.lib, st = S.settings, c = counts(), total = GL.all().length;
      const list = filtered();
      return `<section class="library">
        <div class="lib-head"><h1>Library <small id="libCount">${f.hidden ? list.length + ' hidden' : list.length + (list.length !== total ? ' of ' + total : '') + ' game' + (total === 1 ? '' : 's')}</small></h1>
          <div class="lib-actions"><button class="btn" data-act="scan" data-focus data-k="lib-scan">${icon('refresh')}Scan</button><button class="btn" data-act="ratingslookup" data-focus data-k="lib-rt">${icon('search')}Ratings</button><button class="btn" data-act="addgame" data-focus data-k="lib-add">${icon('plus')}Add game</button></div></div>
        <div class="toolbar">
          <label class="search">${icon('search')}<input id="libSearch" type="search" placeholder="Search games, genres, developers" value="${esc(f.q)}" autocomplete="off" data-focus data-k="lib-q"></label>
          <label class="sel"><span>Sort</span><select id="libSort" data-focus data-k="lib-sort">${SORTS.map(([v, l]) => `<option value="${v}"${st.libSort === v ? ' selected' : ''}>${l}</option>`).join('')}</select></label>
          <button class="btn icon" data-act="libdir" data-focus data-k="lib-dir" aria-label="${st.libDir === 'desc' ? 'Descending' : 'Ascending'}" title="${st.libDir === 'desc' ? 'Descending' : 'Ascending'}"><span class="dir${st.libDir === 'desc' ? ' desc' : ''}">↑</span></button>
          ${S.collections.length ? `<label class="sel"><span>Collection</span><select id="libCol" data-focus data-k="lib-col"><option value="all">All games</option>${S.collections.map((x) => `<option value="${esc(x.id)}"${f.collection === x.id ? ' selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>` : ''}
          <button class="btn toggle${f.fav ? ' on' : ''}" data-act="libfav" data-focus data-k="lib-fav" aria-pressed="${f.fav}">${icon(f.fav ? 'starFill' : 'star')}Favourites</button>
          ${(GL.hiddenGames().length || f.hidden) ? `<button class="btn toggle glass-btn${f.hidden ? ' on' : ''}" data-act="libhidden" data-focus data-k="lib-hid" aria-pressed="${!!f.hidden}" title="Show hidden games">${icon(f.hidden ? 'eyeOff' : 'eye')}Hidden<b>${GL.hiddenGames().length}</b></button>` : ''}
          <div class="seg" role="group" aria-label="View"><button class="${st.libView !== 'list' ? 'on' : ''}" data-act="libview" data-v="grid" data-focus data-k="lib-vg" aria-label="Grid">${icon('grid')}</button><button class="${st.libView === 'list' ? 'on' : ''}" data-act="libview" data-v="list" data-focus data-k="lib-vl" aria-label="List">${icon('list')}</button></div>
          ${st.libView !== 'list' ? `<input id="libSize" class="range" type="range" min="130" max="260" step="10" value="${st.tileSize}" aria-label="Cover size" data-focus data-k="lib-size">` : ''}
        </div>
        <div class="chips" role="group" aria-label="Platform">
          <button class="chipbtn${f.platform === 'all' ? ' on' : ''}" data-act="libplat" data-v="all" data-focus data-k="lp-all">All<b>${total}</b></button>
          ${Object.keys(c).sort((a, b) => c[b] - c[a]).map((p) => `<button class="chipbtn${f.platform === p ? ' on' : ''}" data-act="libplat" data-v="${p}" data-focus data-k="lp-${p}"><i style="background:${(GL.PLATFORM[p] || {}).color}"></i>${esc((GL.PLATFORM[p] || { name: p }).name)}<b>${c[p]}</b></button>`).join('')}
        </div>
        <div id="libGrid">${gridHtml(list)}</div>
      </section>`;
    },
    after() {
      const S = GL.S;
      const q = document.getElementById('libSearch');
      q && q.addEventListener('input', () => { S.lib.q = q.value; GL.views.library.grid(); });
      const sort = document.getElementById('libSort');
      sort && sort.addEventListener('change', () => api.invoke('settings:set', { libSort: sort.value }));
      const col = document.getElementById('libCol');
      col && col.addEventListener('change', () => { S.lib.collection = col.value; GL.views.library.grid(); });
      const size = document.getElementById('libSize');
      size && size.addEventListener('input', () => { document.documentElement.style.setProperty('--tile', size.value + 'px'); });
      size && size.addEventListener('change', () => api.invoke('settings:set', { tileSize: +size.value }));
    },
    grid() {
      const list = filtered(), total = GL.all().length;
      document.getElementById('libGrid').innerHTML = gridHtml(list);
      const c = document.getElementById('libCount'); if (c) c.textContent = GL.S.lib.hidden ? `${list.length} hidden` : `${list.length}${list.length !== total ? ' of ' + total : ''} game${total === 1 ? '' : 's'}`;
    },
  };

  const A = GL.act;
  A.libplat = (d) => { GL.S.lib.platform = d.v; GL.render(); };
  A.libhidden = () => { GL.S.lib.hidden = !GL.S.lib.hidden; GL.render(); };
  A.unhide = async (d) => { const g = GL.S.games[d.id]; await api.invoke('game:update', d.id, { hidden: false }); if (g) GL.toast({ title: g.title, body: 'Back in your library.', type: 'library' }); };
  A.libfav = () => { GL.S.lib.fav = !GL.S.lib.fav; GL.render(); };
  A.libview = (d) => api.invoke('settings:set', { libView: d.v });
  A.libdir = () => api.invoke('settings:set', { libDir: GL.S.settings.libDir === 'desc' ? 'asc' : 'desc' });
  A.clearfilters = () => { GL.S.lib = { q: '', platform: 'all', collection: 'all', fav: false, hidden: false }; GL.render(); };
})();
