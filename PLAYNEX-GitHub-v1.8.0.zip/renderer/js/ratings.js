'use strict';
/** Ratings & reviews: score rings + critic/player review tabs (game details) and the "look up any game" dialog. */
(() => {
  const GL = window.GL, { esc, icon } = GL, api = window.api;
  const tone = (s) => (s >= 75 ? 'good' : s >= 50 ? 'mid' : 'bad');
  const loading = {};
  const CIRC = 2 * Math.PI * 38;

  const ring = (pct, label, big, sub, url, k, extra = '') => `<a class="gauge ${tone(pct)}" ${url ? `data-act="openurl" data-url="${esc(url)}"` : ''} data-focus data-k="${k}" style="--p:${Math.max(2, Math.min(100, pct))};--c:${CIRC.toFixed(1)}">
      <svg viewBox="0 0 90 90" aria-hidden="true"><circle class="trk" cx="45" cy="45" r="38"/><circle class="val" cx="45" cy="45" r="38"/></svg>
      <b>${big}</b><span>${esc(label)}</span><small>${sub}</small>${extra}</a>`;

  const scoreBadge = (sc, kind) => (sc == null ? '<i class="sb none">–</i>' : `<i class="sb ${tone(kind === 'user' ? sc * 10 : sc)}">${Number.isInteger(sc) ? sc : sc.toFixed(1)}</i>`);
  const metaCard = (x) => `<article class="rv">${scoreBadge(x.score, x.kind)}<div><header><b>${esc(x.who || (x.kind === 'critic' ? 'Critic' : 'Player'))}</b>${x.author && x.kind === 'critic' ? `<span>${esc(x.author)}</span>` : ''}${x.date ? `<span>${esc(String(x.date).slice(0, 10))}</span>` : ''}</header><p>${esc(x.quote)}${x.quote.length >= 380 ? '…' : ''}</p></div></article>`;
  const steamCard = (x) => `<article class="rv"><i class="sb ${x.up ? 'good' : 'bad'} thumb">${icon(x.up ? 'check' : 'close')}</i><div><header><b>${x.up ? 'Recommended' : 'Not recommended'}</b><span class="src">Steam</span>${x.hours ? `<span>${x.hours} h played</span>` : ''}${x.votes ? `<span>${x.votes} helpful</span>` : ''}</header><p>${esc(x.text)}${x.text.length >= 320 ? '…' : ''}</p></div></article>`;

  function html(r, opts = {}) {
    if (!r) return '<div class="rt-skel"><i></i><i></i><i></i></div>';
    if (r.error) return `<p class="muted">${esc(r.error)}</p>`;
    const c = r.critic, s = r.steam, w = r.rawg, rv = r.reviews || { critic: [], user: [] };
    if (!c && !s && !w) return `<div class="rt-empty">${icon('search')}<b>No ratings found</b><span>Check the spelling, or try the game's full official name.</span></div>`;
    const plats = (c && c.platforms) || [];
    const hero = c ? `<div class="hero-score ${tone(c.score)}" style="--p:${c.score};--c:${CIRC.toFixed(1)}">
        <a class="ring-wrap" ${c.url ? `data-act="openurl" data-url="${esc(c.url)}"` : ''} data-focus data-k="rt-mc" aria-label="Open on Metacritic"><svg viewBox="-8 -8 106 106" aria-hidden="true"><circle class="trk" cx="45" cy="45" r="38"/><circle class="val" cx="45" cy="45" r="38"/></svg><b>${c.score}</b></a>
        <h4>Metacritic${c.headline ? ` · ${esc(c.headline)}` : ''}</h4><strong>${esc(c.word)}</strong><small>${c.count ? `Based on ${c.count} critic reviews` : 'Critic score'}</small></div>` : '';
    const prcCard = (pct, big, label, sub, url, k) => `<a class="prc ${tone(pct)}" ${url ? `data-act="openurl" data-url="${esc(url)}"` : ''} data-focus data-k="${k}" style="--p:${Math.max(2, Math.min(100, pct))};--c:${(2 * Math.PI * 15).toFixed(1)}"><svg viewBox="-3 -3 36 36" aria-hidden="true"><circle class="trk" cx="15" cy="15" r="15"/><circle class="val" cx="15" cy="15" r="15"/></svg><div><b>${big}</b><span>${esc(label)}</span><small>${sub}</small></div></a>`;
    const ratingCards = [];
    if (s) ratingCards.push(prcCard(s.percent || 0, s.percent == null ? '–' : s.percent + '%', 'Steam users', `${esc(s.desc || 'Reviews')} · ${s.total.toLocaleString()}`, s.url, 'rt-st'));
    if (w && w.rating) ratingCards.push(prcCard(w.rating * 20, w.rating.toFixed(1) + '/5', 'RAWG players', `${w.count.toLocaleString()} ratings`, w.url, 'rt-rw'));
    const platTiles = plats.map((x) => `<div class="plat ${tone(x.score)}${x.platform === 'PC' ? ' me' : ''}"><div class="pt"><b>${esc(x.platform)}</b>${x.platform === 'PC' ? '<em>Your version</em>' : ''}<small>${x.count ? `${x.count} critic reviews` : 'Critic score'}</small></div><i class="sb ${tone(x.score)}">${x.score}</i><span class="bar"><i style="width:${x.score}%"></i></span></div>`).join('');
    const n = plats.length, cols = n <= 3 ? Math.max(1, n) : n === 4 ? 2 : n <= 6 ? 3 : 4;
    const side = `${plats.length ? `<h4 class="rt-h">All platforms</h4><div class="plats" data-n="${n <= 2 ? 'xl' : n <= 6 ? 'lg' : 'md'}" style="--cols:${cols}">${platTiles}</div>` : ''}${ratingCards.length ? `${plats.length ? '<h4 class="rt-h">Player ratings</h4>' : ''}<div class="prcs">${ratingCards.join('')}</div>` : ''}`;
    const top = c ? `<div class="rt-top"><div class="rt-hero">${hero}</div><div class="rt-side">${side}</div></div>` : `<div class="rt-side solo">${side}</div>`;
    const critics = rv.critic || [];
    const players = [...(rv.user || []), ...((s && s.reviews) || []).map((x) => ({ ...x, steam: true }))];
    const hasC = critics.length > 0, hasP = players.length > 0, first = hasC ? 'critic' : 'user';
    const tabs = hasC || hasP ? `<div class="rt-tabs" role="tablist">
        ${hasC ? `<button role="tab" class="${first === 'critic' ? 'on' : ''}" data-act="rttab" data-p="critic" data-focus data-k="rt-tc">Critic reviews<b>${critics.length}</b></button>` : ''}
        ${hasP ? `<button role="tab" class="${first === 'user' ? 'on' : ''}" data-act="rttab" data-p="user" data-focus data-k="rt-tp">Player reviews<b>${players.length}</b></button>` : ''}</div>
      ${hasC ? `<div class="rt-pane${first === 'critic' ? ' on' : ''}" data-p="critic">${critics.map(metaCard).join('')}</div>` : ''}
      ${hasP ? `<div class="rt-pane${first === 'user' ? ' on' : ''}" data-p="user">${players.map((x) => (x.steam ? steamCard(x) : metaCard(x))).join('')}</div>` : ''}`
      : `<p class="muted rt-note">Written reviews weren't available for this game right now.</p>`;
    const ago = r.fetchedAt ? `<small>Updated ${GL.ago(r.fetchedAt)}${r.stale ? ' · offline, showing saved data' : ''}</small>` : '<small></small>';
    return `<div class="rtx">${top}${tabs}${opts.noRefresh ? '' : `<div class="rt-foot">${ago}<button class="btn sm" data-act="refreshratings" data-id="${esc(opts.id || '')}" data-focus data-k="rt-refresh">${icon('refresh')}Refresh</button></div>`}</div>`;
  }

  async function load(id, force) {
    const g = GL.S.games[id]; if (!g || loading[id]) return;
    const body = () => document.getElementById('ratingsBody');
    const ok = g.ratings && g.ratings.v === 4;
    if (!force && ok && body()) body().innerHTML = html(g.ratings, { id });
    if (!force && ok && Date.now() - g.ratings.fetchedAt < 3 * 864e5) return;
    loading[id] = true;
    if (body() && (force || !ok)) body().innerHTML = html(null);
    const r = await api.invoke('game:ratings', id, !!force).catch((e) => ({ error: String(e) }));
    loading[id] = false;
    if (body() && GL.S.view.id === id) body().innerHTML = html(r, { id });
  }
  GL.act.refreshratings = (d) => load(d.id, true);
  GL.act.openurl = (d) => window.open(d.url, '_blank');
  GL.act.rttab = (d, e, el) => {
    const root = el.closest('.rtx'); if (!root) return;
    root.querySelectorAll('.rt-tabs button').forEach((b) => b.classList.toggle('on', b === el));
    root.querySelectorAll('.rt-pane').forEach((p) => p.classList.toggle('on', p.dataset.p === d.p));
  };

  /* ------------------------------------------------------------ look up any game */
  const RK = 'gl.ratingsRecent';
  const recent = () => { try { return JSON.parse(localStorage.getItem(RK) || '[]'); } catch (_) { return []; } };
  const remember = (q) => { try { localStorage.setItem(RK, JSON.stringify([q, ...recent().filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 6))); } catch (_) { /* ignore */ } };

  function lookup(prefill) {
    const rec = recent();
    GL.modal.open(`<div class="modal rtm"><button class="icon-btn rtm-x" data-act="closemodal" aria-label="Close" data-focus data-k="m-x">${icon('close')}</button>
      <div class="rtm-hero"><div class="rtm-glow"></div>
        <h2>Ratings <em>lookup</em></h2><p>Metacritic scores and critic reviews, Steam player reviews, and more. For any game.</p>
        <form id="rtForm" class="rtm-search">${icon('search')}<input name="q" value="${esc(prefill || '')}" placeholder="Search a game, e.g. Need for Speed Heat" autocomplete="off" spellcheck="false" data-focus data-k="rt-q" data-autofocus><button class="btn primary" type="submit" data-focus data-k="rt-go">Look up</button></form>
        <div class="rtm-recent" id="rtRecent">${rec.map((x) => `<button type="button" data-act="rtpick" data-q="${esc(x)}" data-focus data-k="rr-${esc(x.slice(0, 12))}">${esc(x)}</button>`).join('')}</div>
      </div>
      <div id="rtRes" class="rtm-body"><div class="rt-empty">${icon('star')}<b>Find out what people think</b><span>Type a game name above and press Enter.</span></div></div></div>`);
    document.getElementById('rtForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const q = String(new FormData(e.target).get('q') || '').trim(); if (!q) return;
      const box = document.getElementById('rtRes'); box.innerHTML = `<div class="rt-skel big"><i></i><i></i><i></i></div>`;
      const r = await api.invoke('ratings:search', q).catch((x) => ({ error: String(x) }));
      if (!box.isConnected) return;
      if (r && (r.critic || r.steam || r.rawg)) remember(q);
      const cover = r && r.steamAppId ? `https://cdn.cloudflare.steamstatic.com/steam/apps/${r.steamAppId}/header.jpg` : '';
      box.innerHTML = `${r && !r.error ? `<div class="rtm-title">${cover ? `<img src="${esc(cover)}" alt="" onerror="this.remove()">` : ''}<div><small>Results for</small><h3>${esc(r.title || q)}</h3></div></div>` : ''}${html(r, { noRefresh: true })}`;
    });
    if (prefill) document.getElementById('rtForm').requestSubmit();
  }
  GL.act.ratingslookup = () => lookup();
  GL.act.rtpick = (d) => { const i = document.querySelector('#rtForm input[name=q]'); if (i) { i.value = d.q; document.getElementById('rtForm').requestSubmit(); } };
  GL.ratings = { html, load, lookup };
})();
