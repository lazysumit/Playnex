'use strict';
window.GL = window.GL || {};
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const api = window.api;
  const S = GL.S = {
    games: {}, collections: [], sessions: [], settings: { platforms: {}, customThemes: [] }, profile: { name: 'Player One' },
    notifications: [], running: {}, achievements: [], level: null, platforms: {}, meta: {}, systemDark: true, isFullscreen: false,
    view: { name: 'home', id: null }, hist: [], heroId: null,
    lib: { q: '', platform: 'all', collection: 'all', fav: false }, scan: null, pad: false,
  };
  GL.views = GL.views || {};
  GL.act = GL.act || {};

  /* ------------------------------------------------------------ selectors */
  GL.hiddenGames = () => Object.values(S.games).filter((g) => g.installed !== false && g.hidden && !g.notGame);
  GL.all = () => Object.values(S.games).filter((g) => g.installed !== false && !g.hidden);
  GL.byRecent = (n) => GL.all().filter((g) => g.lastPlayed).sort((a, b) => b.lastPlayed - a.lastPlayed).slice(0, n);
  GL.mostPlayed = (n) => GL.all().filter((g) => g.playtime > 0).sort((a, b) => b.playtime - a.playtime).slice(0, n);
  GL.favorites = () => GL.all().filter((g) => g.favorite).sort((a, b) => a.title.localeCompare(b.title));
  GL.newest = (n) => GL.all().sort((a, b) => b.added - a.added).slice(0, n);
  GL.isRunning = (id) => !!S.running[id];

  /* ---------------------------------------------------------------- themes */
  GL.PRESETS = [
    { id: 'midnight', name: 'Midnight', accent: '#3d8bff', bg: '#05070e' },
    { id: 'aurora', name: 'Aurora', accent: '#2ee6c5', bg: '#030f0e' },
    { id: 'crimson', name: 'Crimson', accent: '#ff4d63', bg: '#0e0508' },
    { id: 'violet', name: 'Violet', accent: '#a190ff', bg: '#09061a' },
    { id: 'amber', name: 'Amber', accent: '#ffb02e', bg: '#100a03' },
    { id: 'mono', name: 'Mono', accent: '#e8eaf0', bg: '#07080a' },
    { id: 'ocean', name: 'Ocean', accent: '#2bb8ff', bg: '#03101a' },
    { id: 'emerald', name: 'Emerald', accent: '#34d27b', bg: '#04120a' },
    { id: 'sunset', name: 'Sunset', accent: '#ff7a45', bg: '#140805' },
    { id: 'sakura', name: 'Sakura', accent: '#ff8fc0', bg: '#130810' },
    { id: 'cyber', name: 'Cyber', accent: '#ff2ea6', bg: '#07041a' },
    { id: 'forest', name: 'Forest', accent: '#8bc34a', bg: '#070d06' },
    { id: 'ice', name: 'Ice', accent: '#9be7ff', bg: '#060d14' },
    { id: 'gold', name: 'Gold', accent: '#f5c542', bg: '#0d0b05' },
    { id: 'ruby', name: 'Ruby', accent: '#e0245e', bg: '#10040a' },
    { id: 'lavender', name: 'Lavender', accent: '#c4a8ff', bg: '#0b0714' },
    { id: 'teal', name: 'Teal', accent: '#14b8a6', bg: '#031311' },
    { id: 'nord', name: 'Nord', accent: '#88c0d0', bg: '#0c1118' },
    { id: 'dracula', name: 'Dracula', accent: '#bd93f9', bg: '#0f1018' },
    { id: 'coral', name: 'Coral', accent: '#ff6b6b', bg: '#130707' },
    { id: 'steel', name: 'Steel', accent: '#7f95b2', bg: '#090c11' },
    { id: 'lime', name: 'Lime', accent: '#c6f135', bg: '#0b1004' },
    { id: 'sapphire', name: 'Sapphire', accent: '#4f7cff', bg: '#040a1c' },
    { id: 'synthwave', name: 'Synthwave', accent: '#ff5fd2', bg: '#12062a' },
    { id: 'matrix', name: 'Matrix', accent: '#3dff7a', bg: '#020a04' },
    { id: 'mocha', name: 'Mocha', accent: '#d6a36b', bg: '#120c08' },
    { id: 'rosegold', name: 'Rose Gold', accent: '#f2a9a0', bg: '#140b0c' },
    { id: 'graphite', name: 'Graphite', accent: '#9aa3b2', bg: '#0c0d10' },
    { id: 'mint', name: 'Mint', accent: '#7ff0c8', bg: '#04100d' },
    { id: 'bloodmoon', name: 'Blood Moon', accent: '#ff3b3b', bg: '#0a0203' },
    { id: 'twilight', name: 'Twilight', accent: '#7b8cff', bg: '#0a0b1e' },
    { id: 'peach', name: 'Peach', accent: '#ffb38a', bg: '#150b07' },
    { id: 'electric', name: 'Electric', accent: '#00e5ff', bg: '#02111a' },
    { id: 'bubblegum', name: 'Bubblegum', accent: '#ff7eb6', bg: '#16091a' },
    { id: 'olive', name: 'Olive', accent: '#b5c26a', bg: '#0b0d06' },
    { id: 'indigo', name: 'Indigo', accent: '#6a5cff', bg: '#07051c' },
  ];
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const toHex = (a) => '#' + a.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, t) => { const A = hex(a), B = hex(b); return toHex(A.map((v, i) => v + (B[i] - v) * t)); };
  const lum = (h) => { const [r, g, b] = hex(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  GL.mix = mix;

  GL.applyTheme = () => {
    const st = S.settings;
    const mode = st.themeMode === 'system' ? (S.systemDark ? 'dark' : 'light') : st.themeMode;
    const t = [...GL.PRESETS, ...(st.customThemes || [])].find((x) => x.id === st.themeId) || GL.PRESETS[0];
    const r = document.documentElement;
    r.dataset.theme = mode;
    document.body.classList.toggle('show-brand', st.showBrand === true);   // PLAYNEX name next to the logo (off by default)
    const accent = mode === 'light' && lum(t.accent) > 0.6 ? mix(t.accent, '#000000', 0.45) : t.accent;
    // Light mode: a soft mid-tone instead of near-white. lightTone 0 = softest, 100 = brightest.
    const tone = Math.max(0, Math.min(100, st.lightTone == null ? 40 : st.lightTone)) / 100;
    const lbg = mix('#aeb7c7', '#eef1f6', tone);
    const bg = mode === 'dark' ? t.bg : mix(lbg, t.accent, 0.05);
    const bg2 = mode === 'dark' ? mix(t.bg, t.accent, 0.16) : mix(mix('#98a3b6', '#dde3ee', tone), t.accent, 0.14);
    const set = (k, v) => r.style.setProperty(k, v);
    set('--accent', accent); set('--bg', bg); set('--bg2', bg2);
    if (GL._accentSent !== accent && /^#[0-9a-f]{6}$/i.test(accent)) { GL._accentSent = accent; try { api.invoke('ui:accent', accent).catch(() => {}); } catch (_) { /* ignore */ } }
    if (mode === 'light') {
      const [r, g, b] = hex(bg).map(Math.round);
      set('--shade-a', `rgba(${r},${g},${b},${(0.62 + tone * 0.3).toFixed(2)})`);
      set('--panel', `rgba(${Math.min(255, r + 14)},${Math.min(255, g + 14)},${Math.min(255, b + 14)},${(0.5 + tone * 0.28).toFixed(2)})`);
      set('--glass', `rgba(${Math.min(255, r + 10)},${Math.min(255, g + 10)},${Math.min(255, b + 10)},0.78)`);
    } else { ['--shade-a', '--panel', '--glass'].forEach((k) => r.style.removeProperty(k)); }
    set('--accent-ink', lum(accent) > 0.42 ? '#06080d' : '#ffffff');
    set('--accent-soft', mix(bg, accent, 0.22));
    set('--gl', String((st.glassLevel == null ? 60 : st.glassLevel) / 100));
    set('--dim', String(st.bgDim == null ? 0.5 : st.bgDim)); set('--blur', (st.bgBlur || 0) + 'px');
    set('--tile', (st.tileSize || 170) + 'px');
  };

  /* ------------------------------------------------------------ background */
  let bgCur = null, flip = false;
  GL.setBg = (url) => {
    if (url === bgCur) return; bgCur = url;
    const a = $('#bgA'), b = $('#bgB');
    const apply = () => {
      flip = !flip; const on = flip ? a : b, off = flip ? b : a;
      on.style.backgroundImage = url ? `url("${url}")` : 'none';
      on.classList.add('on'); off.classList.remove('on');
    };
    if (!url) return apply();
    const im = new Image(); im.onload = apply; im.onerror = () => { if (bgCur === url) { bgCur = null; } }; im.src = url;
  };
  GL.refreshBg = () => {
    const st = S.settings;
    let url = null;
    if (st.wallpaper === 'custom') url = st.customBackground;
    else if (st.wallpaper === 'dynamic') {
      // The game details page draws its own banner header on a plain background, so it looks the same in every mode.
      if (S.view.name !== 'game') {
        const g = S.games[S.heroId] || GL.byRecent(1)[0] || GL.all()[0];
        url = g ? GL.art(g, 'banner') || GL.art(g, 'cover') : null;
      }
    }
    document.body.classList.toggle('has-bg', !!url);
    GL.setBg(url);
  };

  /* ------------------------------------------------------------- navigation */
  const TABS = [['home', 'Home', 'home'], ['library', 'Library', 'library'], ['profile', 'Profile', 'profile']];
  GL.go = (name, id = null, opts = {}) => {
    if (S.view.name === name && S.view.id === id && !opts.force) return;
    if (!opts.replace) S.hist.push({ ...S.view, scroll: $('#main').scrollTop });
    if (S.hist.length > 40) S.hist.shift();
    S.view = { name, id };
    GL.modal && GL.modal.close();
    GL.render({ top: true });
  };
  GL.back = () => {
    const prev = S.hist.pop();
    if (!prev) { if (S.view.name !== 'home') { S.view = { name: 'home', id: null }; GL.render({ top: true }); } return; }
    S.view = { name: prev.name, id: prev.id };
    GL.render({ top: true, scroll: prev.scroll });
  };

  /** Restart a CSS animation class on an element (fade-up, rail-in, ...). */
  GL.animate = (el, name) => {
    if (!el) return; const c = 'anim-' + name;
    el.classList.remove(c); void el.offsetWidth; el.classList.add(c);
    el.addEventListener('animationend', () => el.classList.remove(c), { once: true });
  };
  const ORDER = ['home', 'library', 'game', 'profile', 'settings', 'controllers'];
  let lastView = null;

  let rendering = false;
  GL.render = (o = {}) => {
    if (rendering) return; rendering = true;
    try {
      const main = $('#main'); const v = GL.views[S.view.name] || GL.views.home;
      const sc = o.top ? (o.scroll || 0) : main.scrollTop;
      const fk = document.activeElement && document.activeElement.dataset && document.activeElement.dataset.k;
      const changed = lastView !== null && lastView !== S.view.name;
      const dir = changed && S.view.name === 'game' ? 'up' : changed && lastView === 'game' ? 'down' : ORDER.indexOf(S.view.name) >= ORDER.indexOf(lastView) ? 'right' : 'left';
      main.className = 'view-' + S.view.name;
      main.innerHTML = v.html(S);
      if (changed && o.top) { main.dataset.dir = dir; main.classList.add('enter'); void main.offsetWidth; main.addEventListener('animationend', () => main.classList.remove('enter'), { once: true }); }
      lastView = S.view.name;
      main.scrollTop = sc;
      v.after && v.after(S);
      renderChrome();
      GL.refreshBg();
      if (fk && !o.top) { const el = main.querySelector(`[data-k="${CSS.escape(fk)}"]`); if (el) el.focus({ preventScroll: true }); }
      else if (o.top && GL.pad !== false && document.body.classList.contains('using-pad')) { const first = GL.nav.items().find((e) => main.contains(e)); first && first.focus({ preventScroll: true }); }
    } finally { rendering = false; }
  };
  const softRender = GL.debounce(() => GL.render(), 140);

  function renderChrome() {
    const cur = S.view.name === 'game' ? 'library' : S.view.name;
    const tabsEl = $('#tabs');
    let pill = tabsEl.querySelector('.tab-pill');
    if (!pill) { pill = document.createElement('i'); pill.className = 'tab-pill'; tabsEl.prepend(pill); }
    tabsEl.querySelectorAll('.tab').forEach((t) => t.remove());
    tabsEl.insertAdjacentHTML('beforeend', TABS.map(([id, label, ic]) => `<button class="tab${cur === id ? ' on' : ''}" data-act="nav" data-view="${id}" data-focus data-k="tab-${id}" aria-current="${cur === id}">${GL.icon(ic)}<span>${label}</span></button>`).join(''));
    requestAnimationFrame(() => { const on = tabsEl.querySelector('.tab.on'); if (!on) { pill.style.opacity = 0; return; } pill.style.opacity = 1; pill.style.width = on.offsetWidth + 'px'; pill.style.transform = `translateX(${on.offsetLeft}px)`; });
    const unread = S.notifications.filter((n) => !n.read).length;
    const av = S.profile.avatar ? `<img src="${GL.esc(S.profile.avatar)}" alt="">` : GL.esc((S.profile.name || 'P').slice(0, 1).toUpperCase());
    const win = api.platform === 'win32' || true;
    $('#topRight').innerHTML = `
      <button class="icon-btn" data-act="search" data-focus data-k="t-search" title="Search (Ctrl+K)" aria-label="Search">${GL.icon('search')}</button>
      <button class="icon-btn" data-act="capture" data-focus data-k="t-cap" title="Screenshot (${GL.esc(S.settings.captureKey || 'F11')})" aria-label="Take screenshot">${GL.icon('camera')}</button>
      <button class="icon-btn" data-act="notifs" data-focus data-k="t-bell" title="Notifications" aria-label="Notifications">${GL.icon('bell')}${unread ? `<b class="dot">${unread > 9 ? '9+' : unread}</b>` : ''}</button>
      ${GL.musicPlaying() ? `<button class="icon-btn music-btn" data-act="musicpop" data-focus data-k="t-music" title="${GL.esc(GL.musicTitle())}" aria-label="Now playing"><span class="eq"><i></i><i></i><i></i><i></i></span></button>` : ''}
      ${S.pad ? `<button class="pad-chip" data-act="controllers" data-focus data-k="t-pad" title="Controller test${S.padCount > 1 ? ' (' + S.padCount + ' connected)' : ''}" aria-label="Controller test">${GL.icon('gamepad')}${S.padCount > 1 ? `<b>${S.padCount}</b>` : ''}</button>` : ''}
      <span class="clock" id="clock">${clock()}</span>
      <button class="avatar" data-act="nav" data-view="profile" data-focus data-k="t-avatar" title="${GL.esc(S.profile.name)}" aria-label="Profile">${av}</button>
      <button class="icon-btn" data-act="nav" data-view="settings" data-focus data-k="t-settings" title="Settings (Ctrl+,)" aria-label="Settings">${GL.icon('settings')}</button>
      <div class="wc"><button data-act="fullscreen" title="Full screen (F10)" aria-label="Full screen">${GL.icon('fullscreen')}</button><button data-act="winmin" aria-label="Minimise">${GL.icon('min')}</button><button data-act="winmax" aria-label="Maximise">${GL.icon('max')}</button><button class="x" data-act="winclose" aria-label="Close">${GL.icon('close')}</button></div>`;
    renderScan();
  }
  const clock = () => new Date().toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  setInterval(() => { const c = $('#clock'); if (c) c.textContent = clock(); }, 20000);

  function renderScan() {
    let bar = $('#scanBar');
    const s = S.scan;
    if (!s || s.state === 'done') { bar && bar.remove(); return; }
    if (!bar) { bar = document.createElement('div'); bar.id = 'scanBar'; document.body.appendChild(bar); }
    const pct = s.total ? Math.round((s.done || 0) / s.total * 100) : 5;
    bar.innerHTML = `<span>${GL.icon('refresh', 'spin')} Scanning for games${s.name ? ' — ' + GL.esc(s.name) : ''}</span><i><b style="width:${pct}%"></b></i>`;
  }

  /* ----------------------------------------------------------------- toasts */
  GL.toast = (n) => {
    const box = $('#toasts'); const el = document.createElement('div');
    el.className = 'toast ' + (n.type || 'info');
    const ic = n.type === 'achievement' ? 'trophy' : n.type === 'error' ? 'close' : n.type === 'launch' ? 'play' : n.type === 'library' ? 'library' : 'bell';
    el.innerHTML = `<span class="ti">${GL.icon(ic)}</span><div><b>${GL.esc(n.title)}</b><p>${GL.esc(n.body || '')}</p></div>`;
    box.appendChild(el);
    requestAnimationFrame(() => el.classList.add('in'));
    setTimeout(() => { el.classList.remove('in'); setTimeout(() => el.remove(), 350); }, n.type === 'achievement' ? 6000 : 3800);
    while (box.children.length > 4) box.firstChild.remove();
  };

  /* ---------------------------------------------------------------- tooltip */
  const tip = document.createElement('div'); tip.id = 'tip'; document.body.appendChild(tip);
  document.addEventListener('mouseover', (e) => {
    const t = e.target.closest && e.target.closest('[data-tip]');
    if (!t) { tip.classList.remove('on'); return; }
    tip.textContent = t.dataset.tip; tip.classList.add('on');
    const r = t.getBoundingClientRect();
    tip.style.left = Math.max(8, Math.min(innerWidth - tip.offsetWidth - 8, r.left + r.width / 2 - tip.offsetWidth / 2)) + 'px';
    tip.style.top = Math.max(8, r.top - tip.offsetHeight - 8) + 'px';
  });

  /* ----------------------------------------------------------------- actions */
  const A = GL.act;
  A.nav = (d) => GL.go(d.view);
  A.open = (d) => GL.go('game', d.id);
  A.back = () => GL.back();
  A.launch = (d) => GL.launch(d.id);
  A.fav = (d) => api.invoke('game:update', d.id, { favorite: !S.games[d.id].favorite });
  A.search = () => { GL.go('library'); setTimeout(() => { const i = $('#libSearch'); i && i.focus(); }, 30); };
  A.notifs = () => GL.modal.notifications();
  A.fullscreen = () => api.invoke('app:fullscreen');
  A.winmin = () => api.invoke('win:minimize');
  A.winmax = () => api.invoke('win:maximize');
  A.winclose = () => api.invoke('win:close');
  A.scan = () => GL.scan();
  A.addgame = () => GL.modal.addGame();
  A.shortcuts = () => GL.modal.shortcuts();
  A.theme = () => api.invoke('settings:set', { themeMode: document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark' });

  GL.launch = async (id) => {
    const g = S.games[id]; if (!g) return;
    if (GL.isRunning(id)) { GL.toast({ title: g.title, body: 'Already running.', type: 'info' }); return; }
    const r = await api.invoke('game:launch', id);
    if (r && r.error) GL.toast({ title: 'Launch failed', body: r.error, type: 'error' });
  };
  GL.scan = async () => {
    if (S.scan && S.scan.state !== 'done') return;
    S.scan = { state: 'start' }; renderScan();
    const r = await api.invoke('library:scan');
    if (r && r.error) GL.toast({ title: 'Scan failed', body: r.error, type: 'error' });
    else if (r && !r.busy && !r.added) GL.toast({ title: 'Library is up to date', body: `${r.total} game${r.total === 1 ? '' : 's'} installed.`, type: 'library' });
  };

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const fn = GL.act[el.dataset.act];
    if (fn) { e.preventDefault(); fn(el.dataset, e, el); }
  });
  document.addEventListener('contextmenu', (e) => {
    const el = e.target.closest('[data-game]');
    if (el && S.games[el.dataset.game]) { e.preventDefault(); GL.modal.context(S.games[el.dataset.game], e.clientX, e.clientY); }
  });

  /* ---------------------------------------------------------- keyboard & pad */
  const focusedGame = () => { const el = document.activeElement; const id = el && el.closest && el.closest('[data-game]'); return id ? S.games[id.dataset.game] : null; };
  GL.focusedGame = focusedGame;
  const tabOrder = ['home', 'library', 'profile'];
  const cycleTab = (d) => { const cur = tabOrder.indexOf(S.view.name === 'game' ? 'library' : S.view.name); const n = tabOrder[(Math.max(0, cur) + d + tabOrder.length) % tabOrder.length]; GL.go(n); };

  document.addEventListener('keydown', (e) => {
    const inField = GL.nav.isField(document.activeElement);
    const k = e.key;
    if (k === 'Escape') {
      if (!$('#overlay').hidden) { GL.modal.close(); e.preventDefault(); return; }
      if (inField) { document.activeElement.blur(); return; }
      GL.back(); return;
    }
    if (e.ctrlKey && !e.shiftKey && !e.altKey) {
      if (k === 'k' || k === 'f') { e.preventDefault(); A.search(); return; }
      if (k === '1') return GL.go('home'); if (k === '2') return GL.go('library'); if (k === '3') return GL.go('profile'); if (k === '4' || k === ',') return GL.go('settings');
      if (k === 'r') { e.preventDefault(); GL.scan(); return; }
      if (k === 'n') { e.preventDefault(); A.addgame(); return; }
      if (k === 'Enter') { const g = focusedGame() || S.games[S.view.id]; if (g) GL.launch(g.id); return; }
    }
    if (k === 'F10') { e.preventDefault(); api.invoke('app:fullscreen'); return; }
    if (inField || e.ctrlKey || e.altKey || e.metaKey) return;
    if (k === '/') { e.preventDefault(); A.search(); } else if (k === '?') A.shortcuts();
    else if (k === 'f' || k === 'F') { const g = focusedGame() || S.games[S.view.id]; if (g) api.invoke('game:update', g.id, { favorite: !g.favorite }); }
    else if (k === 'p' || k === 'P') { const g = focusedGame() || S.games[S.view.id]; if (g) GL.launch(g.id); }
    else if (k === 't' || k === 'T') A.theme();
    else if (k === 'Backspace') { GL.back(); }
  });

  GL.onController = (c, id, n) => { S.pad = c; S.padCount = n || (c ? 1 : 0); renderChrome(); GL.toast({ title: c ? 'Controller connected' : 'Controller disconnected', body: c ? String(id || '').replace(/\(.*?Vendor.*?\)/i, '').trim().slice(0, 48) + (n > 1 ? ` · ${n} connected` : '') : '', type: 'info' }); };
  GL.onPad = (b) => {
    if (GL.showcase) GL.showcase.poke();
    const el = document.activeElement;
    if (b === 'a') { if (el && el !== document.body && el.click) el.click(); else GL.nav.move('down'); }
    else if (b === 'b') { if (!$('#overlay').hidden) GL.modal.close(); else GL.back(); }
    else if (b === 'x') { const g = focusedGame() || S.games[S.view.id]; if (g) api.invoke('game:update', g.id, { favorite: !g.favorite }); }
    else if (b === 'y') A.search();
    else if (b === 'lb') cycleTab(-1); else if (b === 'rb') cycleTab(1);
    else if (b === 'start') { const g = focusedGame() || S.games[S.view.id] || S.games[S.heroId]; if (g) GL.launch(g.id); }
    else if (b === 'select') A.shortcuts();
  };

  /* ------------------------------------------------------------------- state */
  api.on('state:patch', (p) => {
    Object.assign(S, p);
    if (Object.keys(p).every((k) => k === 'music' || k === 'version' || k === 'wall')) { renderChrome(); GL.musicUpdate && GL.musicUpdate(); if (S.view.name === 'settings' && GL.views.settings.patch) GL.views.settings.patch(); return; }
    if (p.settings || 'systemDark' in p) GL.applyTheme();
    if ('isFullscreen' in p) document.body.classList.toggle('fs', p.isFullscreen);
    if (p.games && S.heroId && !S.games[S.heroId]) S.heroId = null;
    if (p.settings && S.view.name === 'settings') return GL.views.settings.patch ? GL.views.settings.patch() : softRender();
    softRender();
  });
  api.on('toast', (n) => GL.toast(n));
  api.on('capture:flash', (c) => {
    const f = document.createElement('div'); f.className = 'shutter'; document.body.appendChild(f); setTimeout(() => f.remove(), 600);
    const box = $('#toasts'); const el = document.createElement('button'); el.className = 'toast cap-toast';
    el.innerHTML = `<img src="${GL.esc(c.url)}" alt=""><div><b>Screenshot saved</b><p>${GL.esc(c.label)}</p></div>`;
    el.onclick = () => { GL.go('profile'); setTimeout(() => GL.act.ptab({ v: 'captures' }), 60); el.remove(); };
    box.appendChild(el); requestAnimationFrame(() => el.classList.add('in'));
    setTimeout(() => { el.classList.remove('in'); setTimeout(() => el.remove(), 350); }, 4200);
  });
  api.on('fullscreen', (f) => document.body.classList.toggle('fs', !!f));
  api.on('scan:progress', (p) => {
    S.scan = p.state === 'start' ? { state: 'start', done: 0, total: 0 } : { ...S.scan, ...p };
    if (p.state === 'done') { S.scan = { state: 'done' }; setTimeout(softRender, 0); }
    renderScan();
  });

  async function boot() {
    const st = await api.invoke('state:get');
    Object.assign(S, st);
    GL.applyTheme();
    document.body.classList.toggle('fs', !!S.isFullscreen);
    GL.render({ top: true });
  }
  GL.boot = boot;
  boot();
})();
