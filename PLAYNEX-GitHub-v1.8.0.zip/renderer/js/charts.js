'use strict';
// Lightweight HTML/CSS charts (no dependencies). Single-series charts use the theme accent;
// categorical series use the validated 8-slot palette in a fixed order (see --series-* in CSS).
window.GL = window.GL || {};
(function () {
  const esc = (s) => GL.esc(s);

  /** Vertical bars. items: [{label, value, tip}] ; fmt(value) -> axis text ; labelEvery: show every nth x label */
  function bars(items, { height = 170, fmt = (v) => v, labelEvery = 1, aria = 'Bar chart' } = {}) {
    const max = Math.max(1e-9, ...items.map((i) => i.value));
    const nice = niceMax(max);
    const ticks = [nice, nice / 2, 0];
    return `<div class="chart" role="img" aria-label="${esc(aria)}" style="--ch:${height}px">
      <div class="y">${ticks.map((t) => `<span>${esc(fmt(t))}</span>`).join('')}</div>
      <div class="plot"><div class="grid"><i></i><i></i><i></i></div>
        <div class="bars">${items.map((i) => `<div class="b" data-tip="${esc(i.tip || i.label + ': ' + fmt(i.value))}"><span style="height:${Math.max(i.value > 0 ? 2 : 0, (i.value / nice) * 100)}%"></span></div>`).join('')}</div>
        <div class="x">${items.map((i, k) => `<em>${k % labelEvery === 0 ? esc(i.label) : ''}</em>`).join('')}</div>
      </div></div>`;
  }

  function niceMax(v) {
    if (v <= 0) return 1;
    const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p;
    return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p;
  }

  /** Horizontal ranked bars. items: [{label, value, sub, html, tip}] */
  function hbars(items, { fmt = (v) => v } = {}) {
    const max = Math.max(1e-9, ...items.map((i) => i.value));
    return `<ol class="hbars">${items.map((i) => `<li data-tip="${esc(i.tip || i.label + ': ' + fmt(i.value))}">
      <div class="hb-l">${i.html || ''}<b>${esc(i.label)}</b></div>
      <div class="hb-t"><span style="width:${(i.value / max) * 100}%"></span></div><div class="hb-v">${esc(fmt(i.value))}</div></li>`).join('')}</ol>`;
  }

  /** One stacked bar with a legend row; segments get a 2px surface gap. items: [{label, value}] (max 8 + Other) */
  function stacked(items, { fmt = (v) => v } = {}) {
    const total = items.reduce((a, i) => a + i.value, 0) || 1;
    let list = items.filter((i) => i.value > 0).sort((a, b) => b.value - a.value);
    if (list.length > 8) { const rest = list.slice(7); list = [...list.slice(0, 7), { label: 'Other', value: rest.reduce((a, i) => a + i.value, 0), other: true }]; }
    return `<div class="stack" role="img" aria-label="Share by platform">
      <div class="st-bar">${list.map((i, k) => `<span data-tip="${esc(i.label)}: ${esc(fmt(i.value))} (${Math.round(i.value / total * 100)}%)" style="flex:${i.value};background:${i.other ? 'var(--muted)' : `var(--series-${k + 1})`}"></span>`).join('')}</div>
      <ul class="st-leg">${list.map((i, k) => `<li><i style="background:${i.other ? 'var(--muted)' : `var(--series-${k + 1})`}"></i>${esc(i.label)}<b>${esc(fmt(i.value))}</b></li>`).join('')}</ul></div>`;
  }

  /** Accessible table alternative. */
  function table(head, rows) {
    return `<details class="tbl"><summary>View as table</summary><table><thead><tr>${head.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></details>`;
  }


  /** Calendar heatmap (one hue, 5 steps). days: [{date:Date, value:hours}] oldest->newest, ends today. */
  function heatmap(days, { fmt = (v) => v } = {}) {
    if (!days.length) return '';
    const first = days[0].date.getDay();            // pad so columns start on Sunday
    const cells = [...Array(first).fill(null), ...days];
    const weeks = Math.ceil(cells.length / 7);
    const max = Math.max(1e-9, ...days.map((d) => d.value));
    const lvl = (v) => (v <= 0 ? 0 : Math.min(4, 1 + Math.floor((v / max) * 3.999)));
    const months = []; let last = -1;
    for (let w = 0; w < weeks; w++) { const c = cells.slice(w * 7, w * 7 + 7).find(Boolean); if (c && c.date.getMonth() !== last) { last = c.date.getMonth(); months.push(`<em style="grid-column:${w + 1}">${c.date.toLocaleDateString(undefined, { month: 'short' })}</em>`); } }
    return `<div class="heat" role="img" aria-label="Playtime heatmap, last ${weeks} weeks" style="--w:${weeks}">
      <div class="heat-m">${months.join('')}</div>
      <div class="heat-g">${cells.map((d) => (d ? `<i class="l${lvl(d.value)}" data-tip="${esc(d.date.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }))}: ${d.value ? esc(fmt(d.value)) : 'no play'}"></i>` : '<i class="x"></i>')).join('')}</div>
      <div class="heat-k"><span>Less</span><i class="l0"></i><i class="l1"></i><i class="l2"></i><i class="l3"></i><i class="l4"></i><span>More</span></div></div>`;
  }

  /** Donut with centre label + legend. items: [{label, value}] */
  function donut(items, { fmt = (v) => v, centre = '', centreSub = '' } = {}) {
    const total = items.reduce((a, i) => a + i.value, 0) || 1;
    let list = items.filter((i) => i.value > 0).sort((a, b) => b.value - a.value);
    if (list.length > 8) { const rest = list.slice(7); list = [...list.slice(0, 7), { label: 'Other', value: rest.reduce((a, i) => a + i.value, 0), other: true }]; }
    const R = 52, C = 2 * Math.PI * R, gap = list.length > 1 ? 3 : 0; let off = 0;
    const segs = list.map((i, k) => {
      const len = Math.max(0, (i.value / total) * C - gap); const el = `<circle r="${R}" cx="70" cy="70" fill="none" stroke="${i.other ? 'var(--muted)' : `var(--series-${k + 1})`}" stroke-width="16" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-off}" data-tip="${esc(i.label)}: ${esc(fmt(i.value))} (${Math.round(i.value / total * 100)}%)"/>`;
      off += (i.value / total) * C; return el;
    }).join('');
    return `<div class="donut"><svg viewBox="0 0 140 140" role="img" aria-label="Playtime share by platform"><g transform="rotate(-90 70 70)">${segs}</g>
        <text x="70" y="68" text-anchor="middle" class="d-big">${esc(centre)}</text><text x="70" y="86" text-anchor="middle" class="d-sub">${esc(centreSub)}</text></svg>
      <ul class="st-leg">${list.map((i, k) => `<li><i style="background:${i.other ? 'var(--muted)' : `var(--series-${k + 1})`}"></i>${esc(i.label)}<b>${esc(fmt(i.value))}</b></li>`).join('')}</ul></div>`;
  }

  /** Progress ring. pct 0-100; inner html goes in the middle. */
  function ring(pct, inner, size = 132) {
    const R = 54, C = 2 * Math.PI * R;
    return `<div class="ring" style="width:${size}px;height:${size}px"><svg viewBox="0 0 128 128" aria-hidden="true"><circle cx="64" cy="64" r="${R}" fill="none" stroke="var(--surface-3)" stroke-width="9"/>
      <circle cx="64" cy="64" r="${R}" fill="none" stroke="var(--accent)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${(pct / 100) * C} ${C}" transform="rotate(-90 64 64)"/></svg><div class="ring-in">${inner}</div></div>`;
  }

  GL.charts = { bars, hbars, stacked, table, heatmap, donut, ring };
})();
