'use strict';
window.GL = window.GL || {};
(function () {
  const { esc, icon } = GL;
  const api = window.api;
  const $ = (s) => document.querySelector(s);
  let returnFocus = null, onClose = null;

  function open(html, { cls = '', close } = {}) {
    const o = $('#overlay');
    returnFocus = document.activeElement; onClose = close || null;
    o.hidden = false;
    o.innerHTML = `<div class="scrim" data-act="closemodal"></div>${html.replace('<div class="modal', `<div class="modal ${cls}`)}`;
    const first = o.querySelector('[data-autofocus]') || o.querySelector('[data-focus]');
    first && setTimeout(() => first.focus({ preventScroll: true }), 30);
    return o;
  }
  function close() {
    const o = $('#overlay'); if (o.hidden) return;
    o.hidden = true; o.innerHTML = '';
    const f = onClose; onClose = null; f && f();
    if (returnFocus && document.contains(returnFocus)) returnFocus.focus({ preventScroll: true });
  }
  const head = (t, sub) => `<header class="m-head"><h2>${esc(t)}</h2>${sub ? `<p>${esc(sub)}</p>` : ''}<button class="icon-btn" data-act="closemodal" aria-label="Close" data-focus data-k="m-x">${icon('close')}</button></header>`;

  /* ----------------------------------------------------------- context menu */
  function context(g, x, y) {
    const S = GL.S;
    const items = [
      ['launch', 'play', GL.isRunning(g.id) ? 'Running' : 'Play'],
      ['open', 'library', 'Game details'],
      ['fav', g.favorite ? 'starFill' : 'star', g.favorite ? 'Remove from favourites' : 'Add to favourites'],
      ['addcol', 'folder', 'Collections…'],
      ['edit', 'edit', 'Edit game…'],
      ['identify', 'search', 'Identify game…'],
      ['refreshart', 'refresh', 'Refresh artwork'],
      ['openfolder', 'external', 'Show install folder'],
      g.hidden ? ['unhide', 'eye', 'Show in library'] : ['hide', 'trash', g.platform === 'custom' ? 'Remove from library' : 'Hide from library'],
    ];
    const o = open(`<div class="ctx" style="left:0;top:0" role="menu">${items.map(([a, ic, l]) => `<button role="menuitem" data-act="ctx" data-a="${a}" data-id="${esc(g.id)}" data-focus data-k="cx-${a}">${icon(ic)}${esc(l)}</button>`).join('')}</div>`, { cls: 'ctx-wrap' });
    const m = o.querySelector('.ctx');
    m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, x)) + 'px';
    m.style.top = Math.max(8, Math.min(innerHeight - m.offsetHeight - 8, y)) + 'px';
  }
  GL.act.ctx = async (d) => {
    const g = GL.S.games[d.id]; close();
    switch (d.a) {
      case 'launch': return GL.launch(d.id);
      case 'open': return GL.go('game', d.id);
      case 'fav': return api.invoke('game:update', d.id, { favorite: !g.favorite });
      case 'addcol': return collections(g);
      case 'edit': return edit(g);
      case 'identify': return identify(g);
      case 'refreshart': api.invoke('game:refreshMeta', d.id, { force: true }); return GL.toast({ title: g.title, body: 'Refreshing artwork…', type: 'library' });
      case 'openfolder': return api.invoke('game:openFolder', d.id);
      case 'unhide': await api.invoke('game:update', d.id, { hidden: false }); return GL.toast({ title: g.title, body: 'Back in your library.', type: 'library' });
      case 'hide': await api.invoke('game:remove', d.id); if (GL.S.view.name === 'game') GL.back(); return GL.toast({ title: g.title, body: g.platform === 'custom' ? 'Removed from library.' : 'Hidden. Rescanning will not bring it back.', type: 'library' });
    }
  };

  /* ------------------------------------------------------------ collections */
  function collections(g) {
    const S = GL.S;
    open(`<div class="modal sm">${head('Collections', g.title)}
      <div class="m-body">${S.collections.length ? `<div class="checks">${S.collections.map((c) => `<label class="check"><input type="checkbox" data-act="togglecol" data-cid="${esc(c.id)}" data-gid="${esc(g.id)}" ${c.gameIds.includes(g.id) ? 'checked' : ''} data-focus data-k="col-${esc(c.id)}"><i></i><span>${esc(c.name)}<small>${c.gameIds.length} game${c.gameIds.length === 1 ? '' : 's'}</small></span></label>`).join('')}</div>` : '<p class="muted">No collections yet. Collections group games however you like — “Co-op nights”, “Backlog”, “Racing”.</p>'}
      <form class="inline-form" id="newCol"><label>New collection<input name="name" maxlength="28" placeholder="Collection name" required data-focus data-k="col-new" ${S.collections.length ? '' : 'data-autofocus'}></label><button class="btn primary" type="submit" data-focus data-k="col-add">Create</button></form></div></div>`);
    const f = $('#newCol');
    f.addEventListener('submit', async (e) => {
      e.preventDefault(); const name = new FormData(f).get('name').trim(); if (!name) return;
      const list = await api.invoke('collection:save', { name, gameIds: [g.id] });
      GL.S.collections = list; collections(GL.S.games[g.id]);
    });
  }
  document.addEventListener('change', async (e) => {
    const t = e.target.closest && e.target.closest('[data-act="togglecol"]');
    if (t) await api.invoke('collection:toggleGame', t.dataset.cid, t.dataset.gid);
  });

  /* ------------------------------------------------------------------ edit */
  function edit(g) {
    const l = g.launch || {}; const isExe = l.type === 'exe';
    const art = (kind, label) => `<div class="art-edit"><span>${label}</span><div class="btn-row"><button class="btn" data-act="setart" data-id="${esc(g.id)}" data-kind="${kind}" data-focus data-k="ea-${kind}">${icon('image')}Choose</button>${g.customArt && g.customArt[kind] ? `<button class="btn ghost" data-act="clearart" data-id="${esc(g.id)}" data-kind="${kind}" data-focus data-k="ec-${kind}">Reset</button>` : ''}</div></div>`;
    open(`<div class="modal">${head('Edit game', g.title)}
      <form class="m-body" id="editForm">
        <label class="field">Title<input name="title" value="${esc(g.title)}" maxlength="100" required data-focus data-k="e-title" data-autofocus></label>
        ${isExe ? `<label class="field">Program<div class="with-btn"><input name="exe" value="${esc(l.target || '')}" data-focus data-k="e-exe"><button type="button" class="btn" data-act="browseexe" data-focus data-k="e-browse">Browse</button></div></label>` : ''}
        ${isExe ? `<label class="field">Launch options<input name="args" value="${esc(l.args || '')}" placeholder="-windowed -skipintro" data-focus data-k="e-args"></label>` : `<p class="sub">This game starts through its launcher, so program and launch options are managed there.</p>`}
        <div class="art-edits">${art('cover', 'Cover')}${art('banner', 'Banner')}${art('logo', 'Logo')}${art('icon', 'Icon')}</div>
        <footer class="m-foot"><button class="btn" type="button" data-act="closemodal" data-focus data-k="e-cancel">Cancel</button><button class="btn primary" type="submit" data-focus data-k="e-save">Save changes</button></footer>
      </form></div>`);
    const f = $('#editForm');
    f.addEventListener('submit', async (e) => {
      e.preventDefault(); const d = new FormData(f);
      const patch = { title: d.get('title') };
      if (isExe) { patch.launchExe = d.get('exe').trim(); patch.launchArgs = d.get('args'); }
      const titleChanged = patch.title.trim() !== g.title;
      await api.invoke('game:update', g.id, patch);
      if (titleChanged) api.invoke('game:refreshMeta', g.id, { force: true });
      close();
    });
  }
  GL.act.browseexe = async () => { const p = await api.invoke('dialog:pickExe'); if (p) { const i = document.querySelector('#editForm [name=exe]'); if (i) i.value = p; } };
  GL.act.setart = async (d) => { await api.invoke('game:setArt', d.id, d.kind, 'pick'); const g = GL.S.games[d.id]; setTimeout(() => edit(GL.S.games[d.id] || g), 150); };
  GL.act.clearart = async (d) => { await api.invoke('game:setArt', d.id, d.kind, 'clear'); setTimeout(() => edit(GL.S.games[d.id]), 150); };

  /* -------------------------------------------------------------- identify */
  async function identify(g) {
    open(`<div class="modal">${head('Identify game', 'Pick the store page that matches this game to fetch the right artwork and details.')}
      <div class="m-body"><form class="inline-form" id="idForm"><label>Search by name<input name="q" value="${esc(g.title)}" data-focus data-k="id-q" data-autofocus></label><button class="btn primary" type="submit" data-focus data-k="id-go">Search</button></form>
      <div id="idRes" class="matches"><p class="muted">Searching…</p></div></div></div>`);
    const run = async (q) => {
      const res = await api.invoke('game:matches', q);
      const box = $('#idRes'); if (!box) return;
      box.innerHTML = Array.isArray(res) && res.length ? res.map((r) => `<button class="match" data-act="applymatch" data-id="${esc(g.id)}" data-app="${esc(r.appId)}" data-focus data-k="mt-${esc(r.appId)}">${r.image ? `<img src="${esc(r.image)}" alt="">` : ''}<span><b>${esc(r.name)}</b><small>Steam app ${esc(r.appId)}</small></span></button>`).join('') : '<p class="muted">No matches found. Try a shorter or different name.</p>';
    };
    run(g.title);
    $('#idForm').addEventListener('submit', (e) => { e.preventDefault(); run(new FormData(e.target).get('q')); });
  }
  GL.act.applymatch = async (d) => { await api.invoke('game:applyMatch', d.id, d.app); close(); GL.toast({ title: 'Game identified', body: 'Downloading artwork and details…', type: 'library' }); };

  /* --------------------------------------------------------------- add game */
  function addGame() {
    open(`<div class="modal sm">${head('Add a game', 'Add any program on this PC: emulators, standalone games, or tools.')}
      <form class="m-body" id="addForm">
        <label class="field">Program<div class="with-btn"><input name="exe" placeholder="C:\\Games\\MyGame\\game.exe" required data-focus data-k="a-exe" data-autofocus><button type="button" class="btn" data-act="browseexe2" data-focus data-k="a-browse">Browse</button></div></label>
        <label class="field">Title <small>(optional)</small><input name="title" placeholder="Detected from the file name" maxlength="100" data-focus data-k="a-title"></label>
        <label class="field">Launch options <small>(optional)</small><input name="args" placeholder="-windowed" data-focus data-k="a-args"></label>
        <footer class="m-foot"><button class="btn" type="button" data-act="scanfolder" data-focus data-k="a-folder">${icon('folder')}Scan a folder instead</button><button class="btn primary" type="submit" data-focus data-k="a-add">Add game</button></footer>
      </form></div>`);
    $('#addForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const d = new FormData(e.target);
      const r = await api.invoke('library:addCustom', { exe: d.get('exe').trim(), title: d.get('title').trim() || undefined, args: d.get('args').trim() });
      if (r && r.error) return GL.toast({ title: 'Could not add game', body: r.error, type: 'error' });
      close(); GL.toast({ title: 'Game added', body: 'Fetching artwork and details…', type: 'library' });
    });
  }
  GL.act.browseexe2 = async () => { const p = await api.invoke('dialog:pickExe'); if (p) { const i = document.querySelector('#addForm [name=exe]'); if (i) { i.value = p; const t = document.querySelector('#addForm [name=title]'); } } };

  /* -------------------------------------------------------------- shortcuts */
  function shortcuts() {
    const rows = [
      ['Navigate', [['Arrow keys / D-pad', 'Move focus'], ['Enter / A', 'Select'], ['Esc / B', 'Back or close'], ['LB / RB', 'Previous / next tab']]],
      ['Go to', [['Ctrl+1', 'Home'], ['Ctrl+2', 'Library'], ['Ctrl+3', 'Profile'], ['Ctrl+4 or Ctrl+,', 'Settings'], ['/ or Ctrl+K or Y', 'Search']]],
      ['Games', [['P or Start', 'Play focused game'], ['Ctrl+Enter', 'Play'], ['F or X', 'Toggle favourite'], ['Right-click', 'Game menu'], ['Ctrl+N', 'Add a game'], ['Ctrl+R', 'Rescan library']]],
      ['Window', [['F10', 'Full screen'], ['F11', 'Screenshot'], ['T', 'Switch dark / light'], ['?', 'This list']]],
    ];
    open(`<div class="modal">${head('Keyboard & controller')}<div class="m-body keys">${rows.map(([t, l]) => `<section><h3>${t}</h3>${l.map(([k, d]) => `<div class="kv"><span>${d}</span><b>${k.split(' or ').map((x) => `<kbd>${esc(x)}</kbd>`).join(' or ')}</b></div>`).join('')}</section>`).join('')}</div></div>`);
  }

  /* ---------------------------------------------------------- notifications */
  function notifications() {
    const S = GL.S;
    const ic = { achievement: 'trophy', error: 'close', session: 'clock', library: 'library', launch: 'play' };
    open(`<div class="modal side">${head('Notifications')}
      <div class="m-body">${S.notifications.length ? `<ul class="notifs">${S.notifications.map((n) => `<li class="${n.read ? '' : 'new'}"><span class="ti">${icon(ic[n.type] || 'bell')}</span><div><b>${esc(n.title)}</b><p>${esc(n.body)}</p><small>${GL.ago(n.ts)}</small></div></li>`).join('')}</ul>
        <footer class="m-foot"><button class="btn" data-act="clearnotifs" data-focus data-k="n-clear">Clear all</button></footer>` : '<p class="muted">You are all caught up.</p>'}</div></div>`);
    if (S.notifications.some((n) => !n.read)) api.invoke('notifications:read');
  }
  GL.act.clearnotifs = async () => { await api.invoke('notifications:clear'); close(); };

  /* --------------------------------------------------------------- lightbox */
  function lightbox(g, i) {
    const shots = (g.art && g.art.screenshots) || []; if (!shots.length) return;
    let n = i;
    open(`<div class="modal lb"><img id="lbImg" alt=""><button class="lb-nav prev" data-act="lbprev" data-focus data-k="lb-p" aria-label="Previous">${icon('back')}</button><button class="lb-nav next" data-act="lbnext" data-focus data-k="lb-n" aria-label="Next">${icon('back')}</button><button class="icon-btn lb-x" data-act="closemodal" data-focus data-k="lb-x" aria-label="Close">${icon('close')}</button><span class="lb-c" id="lbC"></span></div>`);
    const show = () => { $('#lbImg').src = shots[n]; $('#lbC').textContent = `${n + 1} / ${shots.length}`; };
    GL.act.lbprev = () => { n = (n - 1 + shots.length) % shots.length; show(); };
    GL.act.lbnext = () => { n = (n + 1) % shots.length; show(); };
    show();
  }

  /* ---------------------------------------------------------------- profile */
  function profile() {
    const p = GL.S.profile;
    open(`<div class="modal sm">${head('Edit profile')}<form class="m-body" id="pForm">
      <label class="field">Display name<input name="name" maxlength="24" value="${esc(p.name)}" required data-focus data-k="pf-name" data-autofocus></label>
      <div class="art-edit"><span>Picture</span><div class="btn-row"><button type="button" class="btn" data-act="pickavatar" data-focus data-k="pf-av">${icon('image')}Choose image</button>${p.avatar ? '<button type="button" class="btn ghost" data-act="clearavatar" data-focus data-k="pf-avc">Remove</button>' : ''}</div></div>
      <footer class="m-foot"><button class="btn" type="button" data-act="closemodal" data-focus data-k="pf-c">Cancel</button><button class="btn primary" type="submit" data-focus data-k="pf-s">Save</button></footer></form></div>`);
    $('#pForm').addEventListener('submit', async (e) => { e.preventDefault(); await api.invoke('profile:set', { name: new FormData(e.target).get('name') }); close(); });
  }
  GL.act.pickavatar = async () => { await api.invoke('profile:setAvatar', 'pick'); setTimeout(profile, 150); };
  GL.act.clearavatar = async () => { await api.invoke('profile:setAvatar', 'clear'); setTimeout(profile, 150); };

  GL.act.closemodal = () => close();
  GL.modal = { open, close, context, collections, edit, identify, addGame, shortcuts, notifications, lightbox, profile };
})();
