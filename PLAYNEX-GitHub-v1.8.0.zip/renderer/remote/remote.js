'use strict';
// PLAYNEX Remote: the phone side. Talks only to the PC it was loaded from.
(function () {
  const $ = (s) => document.querySelector(s);
  const app = $('#app'), sheet = $('#sheet'), viewer = $('#viewer');
  const KEY = 'plx.token';
  const store = { get() { try { return localStorage.getItem(KEY) || ''; } catch (_) { return ''; } }, set(v) { try { localStorage.setItem(KEY, v); } catch (_) { /* ignore */ } }, del() { try { localStorage.removeItem(KEY); } catch (_) { /* ignore */ } } };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const I = {
    shot: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',
    prev: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg>',
    next: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 5h2v14h-2zM4 5l11 7L4 19z"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4l13 8L7 20z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
    power: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3v9"/><path d="M6.3 6.8a8 8 0 1 0 11.4 0"/></svg>',
    restart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.5-5.8"/><path d="M20 4v5h-5"/></svg>',
    stop: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
  };

  let st = null, online = false, skew = 0, timer = null, busy = {}, lastShot = null, errMsg = '';
  const imgs = new Map();      // path -> object URL

  async function api(path, opts = {}) {
    const headers = { Authorization: 'Bearer ' + store.get() };
    if (opts.body) headers['Content-Type'] = 'application/json';
    const r = await fetch(path, { method: opts.method || 'GET', headers, body: opts.body ? JSON.stringify(opts.body) : undefined, cache: 'no-store' });
    if (r.status === 401) { throw Object.assign(new Error('unpaired'), { unpaired: true }); }
    if (opts.blob) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.blob(); }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(j.error || 'HTTP ' + r.status), { status: r.status });
    return j;
  }
  async function image(path) {
    if (imgs.has(path)) return imgs.get(path);
    try { const u = URL.createObjectURL(await api(path, { blob: true })); imgs.set(path, u); return u; } catch (e) { if (e.unpaired) throw e; return null; }
  }
  const dur = (ms) => { const m = Math.max(0, Math.floor(ms / 60000)); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };

  /* ---------------------------------------------------------------- pairing */
  function pairScreen(msg) {
    const guess = /Android/i.test(navigator.userAgent) ? 'Android phone' : /iPhone|iPad/i.test(navigator.userAgent) ? 'iPhone' : 'Phone';
    app.innerHTML = `<div class="top"><img src="icon-192.png" alt=""><b>PLAYNEX</b></div>
      <div class="pair"><h1>Pair with your PC</h1>
      <p>On your PC open PLAYNEX, go to Settings, Remote, and press <b>Pair a phone</b>. Then type the 6-digit code here.</p>
      ${msg ? `<div class="err">${esc(msg)}</div>` : ''}
      <label class="field"><span>Pairing code</span><input id="code" class="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000"></label>
      <label class="field"><span>Name for this phone</span><input id="pname" maxlength="40" value="${esc(guess)}"></label>
      <button class="btn primary block" data-act="pair">Connect</button></div>`;
    const c = $('#code'); if (c) c.focus();
  }
  async function doPair() {
    const code = ($('#code').value || '').replace(/\D/g, ''); const name = $('#pname').value.trim() || 'Phone';
    if (code.length !== 6) return pairScreen('Enter the 6-digit code shown on your PC.');
    try {
      const r = await fetch('/api/pair', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code, name }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return pairScreen(j.error || 'Could not pair.');
      store.set(j.token); st = null; start();
    } catch (_) { pairScreen('Could not reach the PC. Check that you are on the same Wi-Fi (or connected through your VPN).'); }
  }

  /* ---------------------------------------------------------------- dashboard */
  const meter = (label, v) => `<div class="meter"><div class="l"><span>${label}</span><span>${v == null ? '—' : v + '%'}</span></div><div class="bar"><i data-w="${v == null ? 0 : v}" class="${v != null && v >= 90 ? 'hot' : ''}"></i></div></div>`;

  function render() {
    if (!st) return;
    const now = Date.now() + skew;
    const run = st.running || [];
    const mus = (st.music || [])[0];
    const pend = st.power && st.power.pending && st.power.pending.at > now - 1000 ? st.power.pending : null;
    const allowed = !st.power || st.power.allowed !== false;
    app.innerHTML = `
      <div class="top"><img src="icon-192.png" alt=""><b>PLAYNEX</b><div class="st"><span class="dot ${online ? 'on' : 'off'}"></span>${online ? esc(st.pc || 'Connected') : 'PC not reachable'}</div></div>
      ${errMsg ? `<div class="err">${esc(errMsg)}</div>` : ''}
      ${pend ? `<div class="banner"><span>${pend.action === 'restart' ? 'Restarting' : 'Shutting down'} in <b id="cd">${Math.max(0, Math.ceil((pend.at - now) / 1000))}</b> s</span><button class="btn" data-act="cancelpower">Cancel</button></div>` : ''}
      <div class="card"><h2>Now playing</h2>
        ${run.length ? run.map((g) => `<div class="game"><div class="cover" data-cover="${esc(g.id)}">${esc((g.title || '?')[0])}</div><div class="meta"><b>${esc(g.title)}</b><span>Playing for ${dur(now - g.start)}</span></div><button class="btn danger" data-act="quit" data-id="${esc(g.id)}" data-title="${esc(g.title)}" aria-label="Quit ${esc(g.title)}">${I.stop}Quit</button></div>`).join('') : '<div class="muted">No game is running on your PC.</div>'}
      </div>
      <div class="card"><h2>Screenshot</h2>
        <button class="btn primary block" data-act="shot" ${busy.shot ? 'disabled' : ''}>${I.shot}${busy.shot ? 'Capturing…' : 'Take screenshot'}</button>
        ${lastShot ? `<div class="shot" data-act="view"><img src="${lastShot.url}" alt="Latest screenshot"><small>${esc(lastShot.label)} · ${new Date(lastShot.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small></div>` : '<p class="muted note">Captures what is on your PC screen right now. A copy is also saved on the PC.</p>'}
      </div>
      <div class="card"><h2>Music</h2>
        ${mus ? `<div class="music"><div class="art">${mus.thumb ? `<img src="${esc(mus.thumb)}" alt="">` : ''}</div><div class="t"><b>${esc(mus.title || 'Unknown track')}</b><span class="muted">${esc(mus.artist || mus.app || '')}</span></div></div>
        <div class="ctl"><button class="btn" data-act="music" data-c="prev" data-app="${esc(mus.appId)}" aria-label="Previous">${I.prev}</button><button class="btn main" data-act="music" data-c="toggle" data-app="${esc(mus.appId)}" aria-label="${mus.status === 'playing' ? 'Pause' : 'Play'}">${mus.status === 'playing' ? I.pause : I.play}</button><button class="btn" data-act="music" data-c="next" data-app="${esc(mus.appId)}" aria-label="Next">${I.next}</button></div>`
          : '<div class="muted">Nothing is playing on your PC.</div>'}
      </div>
      <div class="card"><h2>PC</h2>${meter('CPU', st.sys && st.sys.cpu)}${meter('Memory', st.sys && st.sys.mem)}${meter('GPU', st.sys && st.sys.gpu)}</div>
      <div class="card"><h2>Power</h2>
        <div class="row"><button class="btn" data-act="power" data-k="restart" ${allowed ? '' : 'disabled'}>${I.restart}Restart</button><button class="btn danger" data-act="power" data-k="shutdown" ${allowed ? '' : 'disabled'}>${I.power}Shut down</button></div>
        <p class="muted note">${allowed ? 'You get 10 seconds to cancel. A PC that is shut down cannot be turned back on from here.' : 'Power actions from the phone are turned off in PLAYNEX on the PC (Settings, Remote).'}</p>
      </div>
      <div class="footer">Paired as ${esc(st.device || 'this phone')} · PLAYNEX ${esc(st.version || '')}<br><button class="link" data-act="unpair">Unpair this phone</button></div>`;
    app.querySelectorAll('.bar i').forEach((el) => { el.style.width = el.dataset.w + '%'; });
    app.querySelectorAll('[data-cover]').forEach(async (el) => { const u = await image('/api/cover/' + el.dataset.cover).catch(() => null); if (u && el.isConnected) el.innerHTML = `<img src="${u}" alt="">`; });
  }

  async function poll() {
    clearTimeout(timer);
    if (!store.get()) return pairScreen();
    try {
      const j = await api('/api/status'); st = j; online = true; skew = (j.now || Date.now()) - Date.now(); errMsg = '';
      render();
    } catch (e) {
      if (e.unpaired) { store.del(); st = null; return pairScreen('This phone is no longer paired. Pair it again.'); }
      online = false; if (st) render(); else app.innerHTML = '<div class="top"><img src="icon-192.png" alt=""><b>PLAYNEX</b></div><div class="card"><h2>PC not reachable</h2><div class="muted">Make sure your PC is on, PLAYNEX is running, and you are on the same Wi-Fi (or connected through your VPN).</div></div>';
    }
    timer = setTimeout(poll, document.hidden ? 15000 : online ? 3000 : 6000);
  }
  function start() { clearTimeout(timer); poll(); }
  document.addEventListener('visibilitychange', () => { if (!document.hidden && store.get()) start(); });
  setInterval(() => { const cd = $('#cd'); if (cd && st && st.power && st.power.pending) cd.textContent = Math.max(0, Math.ceil((st.power.pending.at - (Date.now() + skew)) / 1000)); }, 500);

  /* ---------------------------------------------------------------- actions */
  function ask(title, text, okLabel, danger) {
    return new Promise((resolve) => {
      sheet.hidden = false;
      sheet.innerHTML = `<div class="box" role="dialog" aria-modal="true"><h3>${esc(title)}</h3><p>${esc(text)}</p><div class="row"><button class="btn" data-s="no">Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-s="yes">${esc(okLabel)}</button></div></div>`;
      const done = (v) => { sheet.hidden = true; sheet.innerHTML = ''; sheet.onclick = null; resolve(v); };
      sheet.onclick = (e) => { const b = e.target.closest('[data-s]'); if (b) done(b.dataset.s === 'yes'); else if (e.target === sheet) done(false); };
    });
  }
  const run = async (fn) => { try { errMsg = ''; await fn(); } catch (e) { if (e.unpaired) { store.del(); return pairScreen('This phone is no longer paired.'); } errMsg = e.message || 'Something went wrong'; } await poll(); };

  const ACT = {
    pair: doPair,
    shot: () => { busy.shot = true; render(); return run(async () => {
      try { const r = await api('/api/screenshot', { method: 'POST', body: {} }); const blob = await api('/api/capture/' + r.id, { blob: true }); lastShot = { url: URL.createObjectURL(blob), blob, label: r.label || 'Screenshot', ts: r.ts || Date.now() }; } finally { busy.shot = false; }
    }); },
    view: () => {
      if (!lastShot) return; viewer.hidden = false;
      viewer.innerHTML = `<img src="${lastShot.url}" alt="Screenshot"><div class="row"><a class="btn primary" href="${lastShot.url}" download="playnex-screenshot.png">Save</a><button class="btn" data-act="closeview">Close</button></div>`;
    },
    closeview: () => { viewer.hidden = true; viewer.innerHTML = ''; },
    music: (el) => run(() => api('/api/music', { method: 'POST', body: { cmd: el.dataset.c, appId: el.dataset.app } })),
    quit: async (el) => { if (await ask('Quit ' + el.dataset.title + '?', 'The game will be closed on your PC. Unsaved progress will be lost.', 'Quit game', true)) run(() => api('/api/quit-game', { method: 'POST', body: { id: el.dataset.id } })); },
    power: async (el) => {
      const k = el.dataset.k; const restart = k === 'restart';
      if (await ask(restart ? 'Restart the PC?' : 'Shut down the PC?', `${restart ? 'It will restart' : 'It will turn off'} in 10 seconds. You can cancel until then. Open games and apps will be closed.`, restart ? 'Restart' : 'Shut down', true)) run(() => api('/api/power', { method: 'POST', body: { action: k } }));
    },
    cancelpower: () => run(() => api('/api/power', { method: 'POST', body: { action: 'cancel' } })),
    unpair: async () => { if (await ask('Unpair this phone?', 'You will need a new pairing code from the PC to connect again.', 'Unpair', true)) { try { await api('/api/unpair', { method: 'POST', body: {} }); } catch (_) { /* ignore */ } store.del(); st = null; clearTimeout(timer); pairScreen(); } },
  };
  document.addEventListener('click', (e) => { const el = e.target.closest('[data-act]'); if (el && ACT[el.dataset.act]) ACT[el.dataset.act](el); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target && e.target.id === 'code') doPair(); });

  start();
})();
