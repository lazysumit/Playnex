'use strict';
// Privacy guard: fails if the project (or the finished installer contents) contains details of the computer it was built on.
//   node tools/privacy-check.js          scans the source files
//   node tools/privacy-check.js --dist   also scans dist/win-unpacked (the app that goes into the installer) and the installer name
// Looks for: this PC's user name, home folder, computer name, user-profile paths, e-mail addresses, private network addresses, MAC addresses.
const fs = require('fs');
const os = require('os');
const path = require('path');

const root = path.join(__dirname, '..');
const dist = process.argv.includes('--dist');
const SKIP_DIRS = new Set(['node_modules', 'dist', '.git', '_legacy']);
const TEXT = /\.(js|json|html|css|md|bat|yml|yaml|txt|svg|cmd|ps1|nsh)$/i;
const SELF = path.join(__dirname, 'privacy-check.js');

// --- this machine's own identifiers (computed, never stored anywhere) ---
const GENERIC = new Set(['root', 'user', 'users', 'admin', 'administrator', 'runner', 'node', 'test', 'default', 'public', 'guest', 'system', 'claude', 'ubuntu']);
const own = new Set();
const add = (v, min = 4) => { v = String(v || '').trim(); if (v.length >= min && !GENERIC.has(v.toLowerCase())) own.add(v); };
try { add(os.userInfo().username); } catch (_) { /* ignore */ }
add(os.hostname()); add(process.env.COMPUTERNAME); add(process.env.USERNAME); add(process.env.USER); add(process.env.USERDOMAIN); add(process.env.LOGNAME);
const home = os.homedir(); if (home && home.length > 6 && !/^[\\/]?(root|home)?$/i.test(home)) own.add(home);

// a name only counts when it sits in a path or an address (\\name\\, /name/, user@name, name@host), so a user name like "Game" never trips on the words "PLAYNEX"
const esc = (v) => v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const ownHit = (text) => { const t = text.toLowerCase(); for (const v of own) { const l = v.toLowerCase(); if (/[\\/]/.test(l) ? t.includes(l) : new RegExp('(?:[\\\\/:@]|^)' + esc(l) + '(?:[\\\\/@:]|$)').test(t)) return v; } return null; };
const rx = [
  ['user-profile path', /[A-Za-z]:\\+Users\\+(?!Public\b|Default\b|%|<|\{|\$)[^\\/\s"'`]+/g],
  ['home path', /\/(?:home|Users)\/(?!runner\b|user\b|<|\{|\$)[A-Za-z0-9._-]{2,}\//g],
  ['root/tmp session path', /\/(?:root\/\.|tmp\/claude)/g],
  ['e-mail address', /[A-Za-z0-9._%+-]+@(?!example\.|users\.noreply\.github\.com)[A-Za-z0-9-]+\.[A-Za-z]{2,}/g],
  ['private network address', /\b(?:192\.168|10\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}\b/g],
  ['MAC address', /\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b/g],
];

const findings = [];
function scanText(file, text, withRegex, pathsOnly) {
  const lines = text.split(/\r?\n/);
  lines.forEach((line, i) => {
    const o = ownHit(line); if (o) findings.push([file, i + 1, 'this computer\'s name/user/home', mask(o)]);
    if (withRegex) for (const [label, re] of (pathsOnly ? rx.slice(0, 3) : rx)) { re.lastIndex = 0; const m = re.exec(line); if (m) findings.push([file, i + 1, label, mask(m[0])]); }
  });
}
const mask = (v) => (v.length <= 4 ? '****' : v.slice(0, 2) + '…' + v.slice(-2));

function walk(dir, fn) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP_DIRS.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, fn); else fn(p);
  }
}

// 1) the project files
walk(root, (p) => {
  if (p === SELF || !TEXT.test(p) || fs.statSync(p).size > 2e6) return;
  // npm's lock file lists third-party packages (maintainer e-mails, deprecation notices): check it only for this PC's own details and paths
  scanText(path.relative(root, p), fs.readFileSync(p, 'utf8'), true, /package-lock\.json$/.test(p));
});

// 2) the finished app (what the installer carries)
if (dist) {
  const out = path.join(root, 'dist');
  const res = path.join(out, 'win-unpacked', 'resources');
  let scanned = 0;
  const raw = (file) => { const s = fs.readFileSync(file).toString('latin1'); scanned++; const o = ownHit(s); if (o) findings.push([path.relative(root, file), 0, 'this computer\'s name/user/home (inside the built app)', mask(o)]); for (const [label, re] of rx.slice(0, 3)) { re.lastIndex = 0; const m = re.exec(s); if (m) findings.push([path.relative(root, file), 0, label + ' (inside the built app)', mask(m[0])]); } };
  if (fs.existsSync(res)) fs.readdirSync(res).forEach((f) => { const p = path.join(res, f); if (fs.statSync(p).isFile() && fs.statSync(p).size < 300e6 && /\.(asar|json|yml|txt)$/i.test(f)) raw(p); });
  if (fs.existsSync(out)) fs.readdirSync(out).filter((f) => /Setup.*\.exe$/i.test(f)).forEach((f) => { for (const v of own) if (f.toLowerCase().includes(v.toLowerCase())) findings.push([f, 0, 'installer file name', mask(v)]); });
  if (!scanned) console.log('privacy-check: no built app found in dist/ to scan (skipped).');
  else console.log(`privacy-check: scanned ${scanned} built file(s).`);
}

if (findings.length) {
  console.error('\nPRIVACY CHECK FAILED - personal or computer details found:');
  findings.forEach(([f, l, k, v]) => console.error(`  ${f}${l ? ':' + l : ''}  ${k}  [${v}]`));
  console.error('\nRemove these before building or sharing.\n');
  process.exit(1);
}
console.log('privacy-check: OK - no computer or personal details found.');
