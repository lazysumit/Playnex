'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { Remote } = require('../main/remote');

let passed = 0; const tests = [];
const t = (n, f) => tests.push([n, f]);

function req(port, method, p, { body, token, raw } = {}) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request({ host: '127.0.0.1', port, method, path: p, headers: { ...(token ? { Authorization: 'Bearer ' + token } : {}), ...(data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}) } }, (res) => {
      const ch = []; res.on('data', (c) => ch.push(c)); res.on('end', () => { const buf = Buffer.concat(ch); let json = null; if (!raw) { try { json = JSON.parse(buf.toString()); } catch (_) { /* not json */ } } resolve({ code: res.statusCode, json, buf, headers: res.headers }); });
    });
    r.on('error', reject); if (data) r.write(data); r.end();
  });
}
async function setup(extra = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rm-')); const sd = path.join(dir, 'static'); fs.mkdirSync(sd);
  fs.writeFileSync(path.join(sd, 'index.html'), '<html>hi</html>'); fs.writeFileSync(path.join(sd, 'remote.js'), '//js');
  fs.writeFileSync(path.join(dir, 'secret.txt'), 'SECRET');
  const shot = path.join(dir, 'shot.png'); fs.writeFileSync(shot, Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  const calls = [];
  const remote = new Remote({
    dir: path.join(dir, 'data'), staticDir: sd,
    status: async () => ({ now: Date.now(), running: [{ id: 'g1', title: 'Game', start: Date.now() - 60000 }], music: [], sys: { cpu: 5, mem: 40, gpu: null }, power: { allowed: true, pending: null } }),
    actions: {
      screenshot: async () => { calls.push('shot'); return { id: 'cap1', label: 'Game', ts: 1 }; },
      music: async (c, a) => { calls.push('music:' + c); return true; },
      quitGame: async (id) => { calls.push('quit:' + id); return id === 'g1'; },
      power: async (k) => { calls.push('power:' + k); return { ok: true, at: Date.now() + 10000 }; },
      captureFile: (id) => (id === 'cap1' ? shot : null),
      cover: (id) => (id === 'g1' ? path.join(dir, 'secret.txt') : ''),
    }, ...extra,
  });
  const info = await remote.start(0);
  return { remote, port: remote.port, calls, dir, info };
}
async function pair(s, name = 'My phone') { const c = s.remote.startPairing().code; const r = await req(s.port, 'POST', '/api/pair', { body: { code: c, name } }); return r; }

t('off by default: nothing listens until start()', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rm-')); const r = new Remote({ dir, staticDir: dir, status: async () => ({}), actions: {} });
  assert.strictEqual(r.info().running, false); assert.deepStrictEqual(r.info().urls, []);
});
t('serves the phone page without a token but nothing else, and never other files', async () => {
  const s = await setup();
  try {
    const home = await req(s.port, 'GET', '/', { raw: true }); assert.strictEqual(home.code, 200); assert.ok(/default-src 'self'/.test(home.headers['content-security-policy']));
    assert.strictEqual((await req(s.port, 'GET', '/..%2fsecret.txt')).code, 404);
    assert.strictEqual((await req(s.port, 'GET', '/../secret.txt')).code, 404);
    assert.strictEqual((await req(s.port, 'GET', '/secret.txt')).code, 404);
    assert.strictEqual((await req(s.port, 'GET', '/api/status')).code, 401);
    assert.strictEqual((await req(s.port, 'POST', '/api/power', { body: { action: 'shutdown' } })).code, 401);
    assert.ok(!s.calls.length, 'no action ran without a token');
  } finally { await s.remote.stop(); }
});
t('pairing: wrong code rejected, right code gives a token that works once', async () => {
  const s = await setup();
  try {
    assert.strictEqual((await req(s.port, 'POST', '/api/pair', { body: { code: '123456' } })).code, 400, 'no pairing open yet');
    const { code } = s.remote.startPairing(); const wrong = code === '000000' ? '111111' : '000000';
    assert.strictEqual((await req(s.port, 'POST', '/api/pair', { body: { code: wrong } })).code, 403);
    const ok = await req(s.port, 'POST', '/api/pair', { body: { code, name: 'Pixel <b>' } }); assert.strictEqual(ok.code, 200); assert.ok(/^[0-9a-f]{64}$/.test(ok.json.token));
    assert.strictEqual((await req(s.port, 'POST', '/api/pair', { body: { code } })).code, 400, 'the code works only once');
    const st = await req(s.port, 'GET', '/api/status', { token: ok.json.token }); assert.strictEqual(st.code, 200); assert.strictEqual(st.json.running[0].title, 'Game');
    assert.strictEqual(s.remote.publicDevices().length, 1); assert.ok(!/<|>/.test(s.remote.publicDevices()[0].name));
    assert.ok(!fs.readFileSync(s.remote.file, 'utf8').includes(ok.json.token), 'the token itself is never stored, only its hash');
  } finally { await s.remote.stop(); }
});
t('five wrong codes lock pairing', async () => {
  const s = await setup();
  try {
    const { code } = s.remote.startPairing(); const wrong = code === '000000' ? '111111' : '000000'; let last;
    for (let i = 0; i < 5; i++) last = await req(s.port, 'POST', '/api/pair', { body: { code: wrong } });
    assert.strictEqual(last.code, 429); assert.strictEqual(s.remote.startPairing(), null, 'cannot open a new pairing while locked');
    assert.strictEqual((await req(s.port, 'POST', '/api/pair', { body: { code } })).code, 429, 'even the right code is refused while locked');
  } finally { await s.remote.stop(); }
});
t('actions run for a paired phone: screenshot, music, quit, power', async () => {
  const s = await setup();
  try {
    const { json: { token } } = await pair(s);
    const shot = await req(s.port, 'POST', '/api/screenshot', { token, body: {} }); assert.strictEqual(shot.json.id, 'cap1');
    const img = await req(s.port, 'GET', '/api/capture/cap1', { token, raw: true }); assert.strictEqual(img.code, 200); assert.strictEqual(img.headers['content-type'], 'image/png');
    assert.strictEqual((await req(s.port, 'GET', '/api/capture/nope', { token })).code, 404);
    assert.strictEqual((await req(s.port, 'POST', '/api/music', { token, body: { cmd: 'next' } })).code, 200);
    assert.strictEqual((await req(s.port, 'POST', '/api/music', { token, body: { cmd: 'rm -rf' } })).code, 400);
    assert.strictEqual((await req(s.port, 'POST', '/api/quit-game', { token, body: { id: 'g1' } })).code, 200);
    assert.strictEqual((await req(s.port, 'POST', '/api/quit-game', { token, body: { id: 'zzz' } })).code, 404);
    assert.strictEqual((await req(s.port, 'POST', '/api/power', { token, body: { action: 'shutdown' } })).code, 200);
    assert.strictEqual((await req(s.port, 'POST', '/api/power', { token, body: { action: 'format' } })).code, 400);
    assert.deepStrictEqual(s.calls, ['shot', 'music:next', 'quit:g1', 'quit:zzz', 'power:shutdown']);
  } finally { await s.remote.stop(); }
});
t('covers only serve images, never arbitrary files', async () => {
  const s = await setup();
  try { const { json: { token } } = await pair(s); assert.strictEqual((await req(s.port, 'GET', '/api/cover/g1', { token })).code, 404, 'a .txt path is not an image'); } finally { await s.remote.stop(); }
});
t('removing a phone cuts it off straight away; paired phones survive a restart', async () => {
  const s = await setup();
  try {
    const { json: { token } } = await pair(s); const id = s.remote.publicDevices()[0].id;
    const again = new Remote({ dir: path.join(s.dir, 'data'), staticDir: s.dir, status: async () => ({}), actions: {} }); assert.strictEqual(again.publicDevices().length, 1, 'reloaded from disk');
    s.remote.revoke(id); assert.strictEqual((await req(s.port, 'GET', '/api/status', { token })).code, 401);
  } finally { await s.remote.stop(); }
});
t('a phone can unpair itself; garbage tokens and oversized bodies are refused', async () => {
  const s = await setup();
  try {
    const { json: { token } } = await pair(s);
    assert.strictEqual((await req(s.port, 'GET', '/api/status', { token: 'a'.repeat(64) })).code, 401);
    assert.strictEqual((await req(s.port, 'POST', '/api/music', { token, body: { cmd: 'toggle', pad: 'x'.repeat(9000) } }).catch(() => ({ code: 0 }))).code === 200, false);
    assert.strictEqual((await req(s.port, 'POST', '/api/unpair', { token, body: {} })).code, 200);
    assert.strictEqual((await req(s.port, 'GET', '/api/status', { token })).code, 401);
  } finally { await s.remote.stop(); }
});
t('stop() closes the port', async () => {
  const s = await setup(); const port = s.port; await s.remote.stop();
  await assert.rejects(() => req(port, 'GET', '/api/ping'));
  assert.strictEqual(s.remote.info().running, false);
});
t('a busy port is reported, not thrown', async () => {
  const a = await setup(); const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rm-')); const b = new Remote({ dir, staticDir: dir, status: async () => ({}), actions: {} });
  try { const info = await b.start(a.port); assert.strictEqual(info.running, false); assert.ok(/already in use/.test(info.error)); } finally { await a.remote.stop(); }
});

(async () => { for (const [n, f] of tests) { try { await f(); passed++; } catch (e) { console.error('FAIL', n, '\n', e && e.stack || e); process.exitCode = 1; } } console.log(`${passed} passed (remote)`); })();
