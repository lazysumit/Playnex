'use strict';
const assert = require('assert'); const fs = require('fs'); const os = require('os'); const path = require('path');
const W = require('../main/wallpapers');
let n = 0; const queue = []; const t = (name, f) => queue.push([name, f]);

const png = (w, h) => { const b = Buffer.alloc(64); Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(b); b.writeUInt32BE(w, 16); b.writeUInt32BE(h, 20); return b; };
const jpg = (w, h) => { const b = Buffer.alloc(64); b[0] = 0xff; b[1] = 0xd8; b[2] = 0xff; b[3] = 0xe0; b.writeUInt16BE(16, 4); b[20] = 0xff; b[21] = 0xc0; b.writeUInt16BE(17, 22); b[24] = 8; b.writeUInt16BE(h, 25); b.writeUInt16BE(w, 27); return b; };
const webpX = (w, h) => { const b = Buffer.alloc(64); b.write('RIFF', 0); b.write('WEBP', 8); b.write('VP8X', 12); b.writeUIntLE(w - 1, 24, 3); b.writeUIntLE(h - 1, 27, 3); return b; };
const webpL = (w, h) => { const b = Buffer.alloc(64); b.write('RIFF', 0); b.write('WEBP', 8); b.write('VP8L', 12); b[20] = 0x2f; b.writeUInt32LE((w - 1) | ((h - 1) << 14), 21); return b; };
const webpLossy = (w, h) => { const b = Buffer.alloc(64); b.write('RIFF', 0); b.write('WEBP', 8); b.write('VP8 ', 12); b.writeUInt16LE(w, 26); b.writeUInt16LE(h, 28); return b; };

t('image sizes: png / jpeg / webp (3 kinds)', () => {
  assert.deepStrictEqual([W.imageSize(png(3840, 2160)).w, W.imageSize(png(3840, 2160)).h], [3840, 2160]);
  assert.deepStrictEqual([W.imageSize(jpg(2560, 1440)).w, W.imageSize(jpg(2560, 1440)).h], [2560, 1440]);
  for (const f of [webpX, webpL, webpLossy]) { const s = W.imageSize(f(3840, 2160)); assert.deepStrictEqual([s.w, s.h, s.ext], [3840, 2160, 'webp']); }
  assert.strictEqual(W.imageSize(Buffer.from('not an image at all, just text bytes here....')), null);
});
t('16:9 and labels', () => { assert.ok(W.is169(3840, 2160) && W.is169(2560, 1440) && !W.is169(1920, 1200) && !W.is169(1080, 1920)); assert.deepStrictEqual([3840, 2560, 1920, 5120].map(W.qualityLabel), ['4K UHD', '2K QHD', 'Full HD', '5K']); });
t('wallhaven parse filters size/ratio', () => {
  const j = { data: [{ id: 'abc', path: 'https://w.wallhaven.cc/full/ab/wallhaven-abc.jpg', url: 'https://wallhaven.cc/w/abc', resolution: '3840x2160' }, { id: 'low', path: 'x', resolution: '1920x1080' }, { id: 'tall', path: 'y', resolution: '2560x1600' }] };
  const r = W.parseWallhaven(j, W.TOPICS.gaming, W.QUALITY['2k']); assert.deepStrictEqual(r.map((x) => x.id), ['wh-abc']);
});
t('bing parse -> UHD url', () => { const r = W.parseBing({ images: [{ urlbase: '/th?id=OHR.Peak_EN-US1', title: 'Peak &amp; sky', copyright: 'A (© B)', hsh: 'h1' }] }); assert.strictEqual(r[0].urls[0], 'https://www.bing.com/th?id=OHR.Peak_EN-US1_UHD.jpg'); assert.strictEqual(r[0].title, 'Peak & sky'); });
t('wallpapercave ids + page', () => {
  const ids = W.parseCaveIds('<a href="/w/wp16635338">x</a><a href="/w/wp16635338">dup</a><img src="/wp/wp123456.jpg"><a href="/w/uwp5122258">u</a>');
  assert.deepStrictEqual(ids, ['wp16635338', 'wp123456', 'uwp5122258']);
  const p = W.parseCavePage('wp1', '<meta property="og:title" content="Cyber City 4K Wallpapers - WallpaperCave"><meta property="og:image" content="https://wallpapercave.com/wp/wp1.jpg">', W.TOPICS.cities);
  assert.deepStrictEqual([p.title, p.urls[0]], ['Cyber City 4K', 'https://wallpapercave.com/wp/wp1.jpg']);
});
t('wallhalla ids + page (4K variant first, resolution hint)', () => {
  const u = '61e9742e-baed-430f-a63a-17c2b761ee3b';
  assert.deepStrictEqual(W.parseHallIds(`<a href="/wallpaper/${u}?s=best">a</a><a href="/wallpaper/${u}">b</a>`), [u]);
  const p = W.parseHallPage(u, '<title>Rainy Spy - Wallhalla</title><div>3840 × 2160</div>');
  assert.deepStrictEqual([p.title, p.hint.w, p.urls[0].endsWith('/3840.webp')], ['Rainy Spy', 3840, true]);
});

const harness = (settings, extra = {}) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wp-')); const dir = path.join(root, 'tmp'), persistDir = path.join(root, 'kept'); const dl = []; const st = { online: true };
  const fakeFetch = async (url) => {
    const ok = (body) => ({ ok: true, headers: { get: () => '0' }, json: async () => body, text: async () => body, arrayBuffer: async () => body.buffer.slice(body.byteOffset, body.byteOffset + body.length) });
    if (!st.online) throw new Error('offline');
    if (url.startsWith('https://wallhaven.cc/api')) return ok({ data: ['g1', 'small', 'tall', 'g2', 'g3', 'g4', 'g5', 'g6', 'g7', 'g8'].map((u, i) => ({ id: 'w' + i, path: 'https://img/' + u, url: 'p', resolution: '3840x2160' })) });
    if (url.startsWith('https://www.bing.com/HPImageArchive')) return ok({ images: [] });
    if (url.startsWith('https://img/')) { dl.push(url); const u = url.split('/').pop(); return ok(u === 'small' ? png(1920, 1080) : u === 'tall' ? png(2560, 1600) : png(3840, 2160)); }
    return { ok: false, status: 503, headers: { get: () => '0' } };
  };
  const base = { saverWebQuality: '4k', saverCatGaming: true, saverCatNature: false, saverCatAnimals: false, ...settings };
  const make = () => new W.Wallpapers({ dir, persistDir, getSettings: () => base, fetchImpl: fakeFetch, ...extra });
  return { dir, persistDir, dl, st, base, make, wp: make() };
};
const count = (d) => (fs.existsSync(d) ? fs.readdirSync(d).filter((f) => f !== 'index.json').length : 0);

t('keep OFF: one picture per call, few files, temp only, all gone on quit', async () => {
  const { dir, persistDir, dl, wp } = harness({ saverWebKeep: false });
  assert.strictEqual(dl.length, 0, 'creating it downloads nothing');
  const a = await wp.next(); assert.ok(a && a.url.startsWith('file:') && a.quality === '4K UHD');
  assert.ok(dl.length >= 1 && dl.length <= 3, 'only a few attempts: ' + dl.length);
  for (let i = 0; i < 8; i++) await wp.next();
  assert.ok(count(dir) <= 4, 'at most 4 temp files: ' + count(dir)); assert.ok(!fs.existsSync(persistDir), 'nothing saved'); assert.ok(dl.length < 16, 'never bulk');
  const [x, y] = await Promise.all([wp.next(), wp.next()]); assert.strictEqual(x.id, y.id, 'overlapping calls share one download');
  wp.onQuit(); assert.ok(!fs.existsSync(dir) && !fs.existsSync(persistDir), 'everything removed on quit');
});
t('keep ON: pictures saved, survive quit + restart, cap enforced', async () => {
  const h = harness({ saverWebKeep: true, saverWebCap: 10 }); const { wp, persistDir } = h;
  for (let i = 0; i < 6; i++) await wp.next();
  assert.ok(count(persistDir) >= 3, 'saved some: ' + count(persistDir)); assert.ok(!fs.existsSync(h.dir) || count(h.dir) === 0, 'not in temp');
  const had = count(persistDir); wp.onQuit();
  assert.strictEqual(count(persistDir), had, 'kept on quit');
  const wp2 = h.make(); assert.strictEqual(wp2.saved.length, had, 'reloaded from index');
  h.base.saverWebCap = 10; const sv = wp2.saved.length; assert.ok(sv <= 10);
});
t('keep ON: works offline from saved pictures', async () => {
  const h = harness({ saverWebKeep: true }); await h.wp.next(); await h.wp.next(); await h.wp.next();
  const wp2 = h.make(); h.st.online = false;
  const r = await wp2.next(); assert.ok(r && r.url.startsWith('file:'), 'served from disk while offline');
});
t('keep OFF: offline with nothing cached returns null, no crash', async () => {
  const h = harness({ saverWebKeep: false }); h.st.online = false; assert.strictEqual(await h.wp.next(), null);
});
t('turning keep OFF deletes saved pictures at next start; deleteAll wipes everything', async () => {
  const h = harness({ saverWebKeep: true }); await h.wp.next(); await h.wp.next(); assert.ok(count(h.persistDir) >= 1);
  h.base.saverWebKeep = false; h.wp.onQuit(); assert.ok(!fs.existsSync(h.persistDir), 'quit with keep off removes saved');
  h.base.saverWebKeep = true; const w3 = h.make(); await w3.next(); assert.ok(count(h.persistDir) >= 1);
  w3.deleteAll(); assert.ok(!fs.existsSync(h.persistDir) && !fs.existsSync(h.dir) && w3.state().saved === 0);
  const h2 = harness({ saverWebKeep: true }); await h2.wp.next(); h2.base.saverWebKeep = false; const w4 = h2.make(); assert.ok(!fs.existsSync(h2.persistDir), 'start with keep off clears old saved pictures');
});

t('keep ON rolling: at the limit every call is a NEW picture and the oldest file is deleted', async () => {
  const mkFetch = () => async (url) => {
    const ok = (body) => ({ ok: true, headers: { get: () => '0' }, json: async () => body, text: async () => body, arrayBuffer: async () => body.buffer.slice(body.byteOffset, body.byteOffset + body.length) });
    if (url.startsWith('https://wallhaven.cc/api')) return ok({ data: Array.from({ length: 60 }, (_, i) => ({ id: 'w' + i, path: 'https://img/' + i, url: 'p', resolution: '3840x2160' })) });
    if (url.startsWith('https://img/')) return ok(png(3840, 2160));
    return { ok: false, status: 503, headers: { get: () => '0' } };
  };
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wp-')); const persistDir = path.join(root, 'k');
  const S = { saverWebKeep: true, saverWebCap: 20, saverWebQuality: '2k', saverCatGaming: true, saverCatNature: false, saverCatAnimals: false, saverWebBing: false, saverWebCave: false, saverWebHalla: false };
  const wp = new W.Wallpapers({ dir: path.join(root, 't'), persistDir, getSettings: () => S, fetchImpl: mkFetch() });
  const ids = []; let first = null;
  for (let i = 0; i < 45; i++) { const r = await wp.next(); ids.push(r.id); if (i === 0) first = r.url; }
  assert.strictEqual(new Set(ids).size, 45, 'never repeats / never stuck');
  assert.strictEqual(count(persistDir), 20, 'exactly the limit on disk');
  assert.ok(!fs.existsSync(new URL(first)), 'the first (oldest) picture was deleted');
});

(async () => { for (const [name, f] of queue) { try { await f(); n++; console.log('  ok  ' + name); } catch (e) { process.exitCode = 1; console.error('FAIL ' + name + '\n' + e.stack); } } console.log(n + ' passed'); })();
