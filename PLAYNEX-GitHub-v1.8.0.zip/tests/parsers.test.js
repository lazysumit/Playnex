'use strict';
const assert = require('assert');
const C = require('../main/scanners/common');
const steam = require('../main/scanners/steam');
const epic = require('../main/scanners/epic');
const { cleanTitle } = require('../main/scanners/manual');
const { similarity, norm } = require('../main/metadata');
const ach = require('../main/achievements');

let passed = 0;
const t = (name, fn) => { try { fn(); passed++; console.log('  ok  ' + name); } catch (e) { console.error('FAIL  ' + name + '\n' + e.stack); process.exitCode = 1; } };

t('VDF: libraryfolders', () => {
  const v = C.parseVdf('"libraryfolders"\n{\n\t"0"\n\t{\n\t\t"path"\t\t"C:\\\\Program Files (x86)\\\\Steam"\n\t}\n\t"1"\n\t{\n\t\t"path"\t\t"D:\\\\Games\\\\SteamLibrary"\n\t}\n}');
  assert.strictEqual(v.libraryfolders['1'].path, 'D:\\Games\\SteamLibrary');
});
t('Steam appmanifest', () => {
  const s = steam.parseManifest('"AppState"\n{\n "appid" "730"\n "name" "Counter-Strike 2"\n "StateFlags" "4"\n "installdir" "Counter-Strike Global Offensive"\n}');
  assert.strictEqual(s.appid, '730'); assert.strictEqual(s.name, 'Counter-Strike 2');
  assert.strictEqual(steam.parseManifest('garbage'), null);
});
t('Epic manifest: game parsed, DLC skipped', () => {
  const g = epic.parseItem({ DisplayName: 'Fortnite', InstallLocation: 'C:\\Epic\\Fortnite', LaunchExecutable: 'FortniteLauncher.exe', AppName: 'Fortnite', CatalogNamespace: 'fn', CatalogItemId: 'abc', AppCategories: ['public', 'games'] });
  assert.strictEqual(g.platform, 'epic'); assert.match(g.launch.target, /^com\.epicgames\.launcher:\/\/apps\/fn%3Aabc%3AFortnite/);
  assert.strictEqual(epic.parseItem({ DisplayName: 'DLC', InstallLocation: 'C:\\x', AppCategories: ['addons'] }), null);
  assert.strictEqual(epic.parseItem({ DisplayName: 'Half', InstallLocation: 'C:\\x', bIsIncompleteInstall: true }), null);
});
t('reg query output parser', () => {
  const out = 'HKEY_LOCAL_MACHINE\\SOFTWARE\\GOG.com\\Games\\123\r\n    gameName    REG_SZ    The Witcher 3\r\n    exe    REG_SZ    C:\\GOG\\witcher3.exe\r\n\r\n';
  const r = C.parseReg(out);
  assert.strictEqual(r.length, 1); assert.strictEqual(r[0].values.gameName, 'The Witcher 3');
});
t('regChildren returns direct children only', () => {
  const e = [{ key: 'HKLM\\A\\B' }, { key: 'HKLM\\A\\B\\C' }, { key: 'HKLM\\A\\D' }];
  assert.deepStrictEqual(C.regChildren(e, 'HKLM\\A').map((x) => x.key), ['HKLM\\A\\B', 'HKLM\\A\\D']);
});
t('cleanTitle', () => {
  assert.strictEqual(cleanTitle('Cyberpunk_2077-v1.5'), cleanTitle('Cyberpunk_2077-v1.5'));
  assert.ok(typeof cleanTitle('elden.ring') === 'string' && cleanTitle('elden.ring').length > 0);
});
t('title similarity', () => {
  assert.ok(similarity('The Witcher 3: Wild Hunt', 'Witcher 3 Wild Hunt') > similarity('The Witcher 3: Wild Hunt', 'Fortnite'));
  assert.strictEqual(norm('Hello, World!'), norm('hello world'));
});
t('achievements unlock from sessions and level rises', () => {
  const now = Date.now(), H = 3600e3;
  const mk = (n) => ({
    games: [{ id: 'steam:1', platform: 'steam', favorite: false, source: 'auto' }, { id: 'custom:x', platform: 'custom', favorite: false, source: 'manual' }],
    sessions: Array.from({ length: n }, (_, i) => ({ id: 's' + i, gameId: 'steam:1', start: now - (i + 1) * 24 * H, end: now - (i + 1) * 24 * H + 2 * H, duration: 7200 })),
    collections: [], unlocked: {}, notifications: [], profile: {},
  });
  const lo = ach.evaluate(mk(0)), hi = ach.evaluate(mk(8));
  assert.ok(hi.level.level >= lo.level.level);
  assert.ok(hi.list.find((a) => a.id === 'streak-7').unlockedAt, 'streak-7 should unlock after 8 consecutive days');
  assert.ok(!lo.list.find((a) => a.id === 'streak-7').unlockedAt);
});
console.log(`${passed} passed`);
