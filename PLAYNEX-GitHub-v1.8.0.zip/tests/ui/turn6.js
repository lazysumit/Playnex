'use strict';
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state');
const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.addInitScript((st) => { window.__calls = []; window.api = { platform: 'win32', invoke: async (ch, ...a) => { window.__calls.push([ch, ...a]); return ch === 'state:get' ? st : {}; }, on: () => () => {} }; }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(900);
  const wait = (n) => page.waitForTimeout(n);
  const shot = async (n) => { await wait(600); await page.screenshot({ path: path.join(out, n + '.png') }); };
  await shot('home-glass60');
  await page.evaluate(() => { GL.S.settings.glassLevel = 100; GL.applyTheme(); }); await shot('home-glass100');
  await page.evaluate(() => { GL.S.settings.glassLevel = 0; GL.applyTheme(); }); await shot('home-glass0');
  await page.evaluate(() => { GL.S.settings.glassLevel = 60; GL.applyTheme(); GL.go('profile'); }); await wait(300);
  await page.evaluate(() => { const b = document.querySelector('.pf-tabs [data-v="trophies"]'); b && b.click(); }); await shot('trophies');
  await page.evaluate(() => { document.getElementById('main').scrollTop = 520; }); await shot('trophies-2');
  await page.evaluate(() => { GL.go('settings'); GL.act.stab({ v: 'library' }); }); await shot('settings-library');
  await page.evaluate(() => { document.getElementById('main').scrollTop = 600; }); await shot('settings-library-2');
  await page.evaluate(() => { GL.act.stab({ v: 'appearance' }); document.getElementById('main').scrollTop = 500; }); await shot('settings-appearance');
  // screensaver auto start from Home
  await page.evaluate(() => { GL.go('home'); GL.S.settings.saverDelay = 10; GL.showcase.poke(); });
  // delay is clamped to >= 10s; fast-forward by backdating last activity through a forced-less path
  await page.evaluate(() => { GL.S.settings.saverDelay = 10; });
  await wait(10800);
  const on = await page.evaluate(() => GL.showcase.active && document.getElementById('showcase').classList.contains('saver'));
  console.log('saver auto-started on Home:', on); if (!on) errors.push('saver did not start');
  const calls = await page.evaluate(() => window.__calls.filter((c) => c[0] === 'app:screensaver'));
  console.log('fullscreen IPC:', JSON.stringify(calls));
  await wait(1500); await page.screenshot({ path: path.join(out, 'saver-1.png') });
  await wait(10500); await page.screenshot({ path: path.join(out, 'saver-2.png') });
  await page.mouse.move(200, 200); await page.mouse.move(400, 300); await wait(400);
  console.log('saver exits on input:', await page.evaluate(() => !GL.showcase.active), JSON.stringify(await page.evaluate(() => window.__calls.filter((c) => c[0] === 'app:screensaver'))));
  console.log('errors:', errors.length ? errors.join('\n') : 'none');
  await browser.close(); process.exitCode = errors.length ? 1 : 0;
})();
