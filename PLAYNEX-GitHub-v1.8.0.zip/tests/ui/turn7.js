'use strict';
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state'); const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
state.version = '1.2.4';
state.music = { available: true, now: [{ appId: 'Spotify.exe', app: 'Spotify', browser: false, title: 'Blinding Lights', artist: 'The Weeknd', album: 'After Hours', status: 'playing' }, { appId: 'chrome.exe', app: 'Chrome', browser: true, title: 'Lofi Beats - SoundCloud', artist: 'chillhop', album: '', status: 'paused' }],
  installed: [{ id: 'spotify', name: 'Spotify', color: '#1ed760', exe: 'C:\\Spotify.exe' }, { id: 'applemusic', name: 'Apple Music', color: '#fa2d48', aumid: 'x!App' }, { id: 'vlc', name: 'VLC', color: '#ff8800', exe: 'C:\\vlc.exe' }] };
state.settings.musicApps = [{ id: 'custom-1', name: 'MusicBee', exe: 'D:\\MusicBee.exe' }];
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } }); const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.addInitScript((st) => {
    window.api = { platform: 'win32', invoke: async (ch) => (ch === 'state:get' ? st : {}), on: () => () => {} };
    const mk = (index, id, n, axes) => ({ index, id, connected: true, mapping: 'standard', timestamp: 1, axes, buttons: Array.from({ length: n }, () => ({ pressed: false, value: 0 })), vibrationActuator: {} });
    window.__pads = [mk(0, 'Xbox 360 Controller (STANDARD GAMEPAD Vendor: 045e Product: 028e)', 17, [0, 0, 0, 0]), mk(1, 'DualSense Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 0ce6)', 17, [0, 0, 0, 0])];
    navigator.getGamepads = () => { window.__pads.forEach((p) => { p.timestamp++; }); return window.__pads; };
  }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(900);
  const shot = async (n) => { await page.waitForTimeout(500); await page.screenshot({ path: path.join(out, n + '.png') }); };
  await shot('home-dark');
  await page.evaluate(() => { GL.S.settings.themeMode = 'light'; GL.applyTheme(); }); await shot('home-light');
  await page.evaluate(() => { GL.go('library'); }); await shot('library-light');
  await page.evaluate(() => { GL.go('settings'); GL.act.stab({ v: 'appearance' }); }); await shot('settings-appearance-light');
  await page.evaluate(() => { GL.S.settings.themeMode = 'dark'; GL.applyTheme(); GL.go('home'); });
  await page.click('.music-btn'); await shot('music-popover'); await page.keyboard.press('Escape');
  await page.evaluate(() => { GL.go('settings'); GL.act.stab({ v: 'music' }); }); await shot('settings-music');
  await page.evaluate(() => { GL.act.stab({ v: 'data' }); }); await shot('settings-data');
  await page.evaluate(() => { GL.go('controllers'); }); await page.waitForTimeout(400);
  await page.evaluate(() => { const p = window.__pads[0]; p.buttons[0].pressed = true; p.buttons[0].value = 1; p.buttons[7].value = 0.7; p.buttons[7].pressed = true; p.axes[0] = 0.8; p.axes[1] = -0.4; p.axes[2] = -0.5; p.axes[3] = 0.6; p.buttons[12].pressed = true;
    const q = window.__pads[1]; q.buttons[2].pressed = true; q.buttons[6].value = 0.35; q.axes[0] = -0.7; });
  await shot('controllers');
  await page.evaluate(() => { window.__pads.length = 1; }); await page.waitForTimeout(400);
  console.log('cards after unplugging 2nd:', await page.evaluate(() => document.querySelectorAll('.pad-card').length));
  await page.evaluate(() => { window.__pads.length = 0; }); await page.waitForTimeout(400);
  console.log('empty state:', await page.evaluate(() => !!document.querySelector('.padtest .empty-lib')));
  console.log('version text:', await page.evaluate(() => { GL.go('settings'); GL.act.stab({ v: 'data' }); return [...document.querySelectorAll('.srow b')].map((e) => e.textContent).filter((t) => /Game Launcher/.test(t)).join('|'); }));
  console.log('errors:', errors.length ? errors.join('\n') : 'none');
  await browser.close(); process.exitCode = errors.length ? 1 : 0;
})();
