'use strict';
// UI preview of Settings -> Remote (phone control + power) with a mocked window.api.
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state'); const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
(async () => {
  const browser = await chromium.launch(); const errors = [];
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
  page.on('pageerror', (e) => errors.push(e.message));
  Object.assign(state.settings, { remoteEnabled: true, remotePort: 47600, remotePower: true, powerForce: false });
  state.remote = { running: true, port: 47600, error: '', urls: ['http://PC-ADDRESS:47600'], locked: false, pairing: null, devices: [{ id: 'a1', name: 'Pixel 8', created: Date.now() - 86400e3 * 3, lastSeen: Date.now() - 600e3 }] };
  state.power = { pending: null, allowed: true };
  await page.addInitScript((st) => { window.__calls = []; window.api = { platform: 'win32', invoke: async (ch, ...a) => { window.__calls.push([ch, ...a]); if (ch === 'state:get') return st; if (ch === 'remote:pair') return { code: '482913', expires: Date.now() + 180000 }; if (ch === 'power:run') return { ok: true }; return {}; }, on: () => () => {} }; }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(800);
  await page.evaluate(() => GL.go('settings')); await page.click('[data-v="remote"]'); await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(out, 'remote-settings.png') });
  await page.evaluate(() => { GL.S.remote.pairing = { code: '482913', expires: Date.now() + 180000 }; GL.S.power = { pending: { action: 'shutdown', at: Date.now() + 9000 }, allowed: true }; GL.render(); }); await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(out, 'remote-pairing.png') });
  await page.click('[data-act="powercancel"]'); await page.click('[data-act="powerrun"][data-kind="restart"]');
  console.log('calls:', JSON.stringify(await page.evaluate(() => window.__calls.filter((c) => /power|remote/.test(c[0])))));
  console.log('tabs:', (await page.$$eval('.s2-nav b', (b) => b.map((x) => x.textContent))).join(', '));
  console.log('errors:', errors.join('\n') || 'none'); await browser.close();
})();
