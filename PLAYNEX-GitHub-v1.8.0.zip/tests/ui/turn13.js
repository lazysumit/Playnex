'use strict';
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state'); const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
const art = (a, b, c) => 'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient><radialGradient id="r" cx=".75" cy=".4" r=".4"><stop offset="0" stop-color="${c}" stop-opacity=".9"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></radialGradient></defs><rect width="1920" height="1080" fill="url(#g)"/><rect width="1920" height="1080" fill="url(#r)"/></svg>`);
(async () => {
  const browser = await chromium.launch(); const errors = [];
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
  page.on('pageerror', (e) => errors.push(e.message));
  state.settings.saverSource = 'web'; state.settings.saverWebKeep = true;
  const WEBS = [{ id: 'a', url: art('#0b1530', '#27406b', '#e8b25a'), title: 'Rainy Spy', topic: 'Animals', sourceName: 'Wallhalla', w: 3840, h: 2160, quality: '4K UHD' }, { id: 'b', url: art('#2a0a3a', '#ff4d8d', '#ffd36b'), title: 'Neon Racer', topic: 'Gaming', sourceName: 'Wallhaven', w: 2560, h: 1440, quality: '2K QHD' }];
  state.wall = { busy: false, found: 55, shown: 3, active: 0, saved: 14, folder: 'D:\\Data\\PLAYNEX\\wallpapers', fetchedAt: Date.now() - 600e3, diag: { wallhaven: { found: 40, shown: 2, failed: 0 }, bing: { found: 16, shown: 1, failed: 0 }, wallpapercave: { found: 0, shown: 0, failed: 0, error: 'HTTP 403' }, wallhalla: { found: 9, shown: 0, failed: 2 } } };
  state.music = { available: true, installed: [], diag: {}, now: [{ appId: 's', app: 'Spotify', title: 'Blinding Lights', artist: 'The Weeknd', status: 'playing', thumb: '' }] };
  state.__w = WEBS;
  await page.addInitScript((st) => { window.__n = 0; window.__calls = []; window.api = { platform: 'win32', invoke: async (ch) => { window.__calls.push(ch); if (ch === 'state:get') return st; if (ch === 'wall:next') { await new Promise((r) => setTimeout(r, 300)); return window.__webs[window.__n++ % window.__webs.length]; } return {}; }, on: () => () => {} }; window.__webs = st.__w; }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(800);
  await page.evaluate(() => GL.go('settings')); await page.click('[data-v="screensaver"]'); await page.waitForTimeout(400);
  await page.evaluate(() => document.querySelector('#sBody .sgroup:nth-of-type(2)').scrollIntoView());
  await page.screenshot({ path: path.join(out, 'settings-pictures.png') });
  console.log('groups:', (await page.$$eval('#sBody h2', (h) => h.map((x) => x.textContent))).join(' | '));
  for (const [name, set] of [['saver-web', {}], ['saver-web-music-bl', { saverMusicPos: 'bottom-left' }], ['saver-web-nocaption', { saverWebCaption: false }]]) {
    await page.evaluate((s) => { Object.assign(GL.S.settings, { saverMusicPos: 'bottom-right', saverWebCaption: true }, s); GL.showcase.start(true, 'saver'); }, set); await page.waitForTimeout(2200);
    await page.screenshot({ path: path.join(out, name + '.png') });
    console.log(name, await page.evaluate(() => document.getElementById('scInfo').textContent.trim().slice(0, 60)));
    await page.evaluate(() => GL.showcase.stop());
  }
  await page.evaluate(() => { GL.S.settings.saverSource = 'mix'; GL.showcase.start(true, 'saver'); }); await page.waitForTimeout(600);
  await page.evaluate(() => GL.showcase.stop());
  console.log('wall:next calls so far:', await page.evaluate(() => window.__calls.filter((c) => c === 'wall:next').length));
  console.log('errors:', errors.join('\n') || 'none'); await browser.close();
})();
