'use strict';
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state'); const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
const svg = (a, b) => 'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="220" height="220" fill="url(#g)"/></svg>`);
(async () => {
  const browser = await chromium.launch(); const errors = [];
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
  page.on('pageerror', (e) => errors.push(e.message));
  state.music = { available: true, installed: [], diag: {}, now: [{ appId: 'Spotify.exe', app: 'Spotify', title: 'Blinding Lights', artist: 'The Weeknd', status: 'playing', thumb: svg('#ff3d6e', '#2a0a5e') }] };
  await page.addInitScript((st) => { window.api = { platform: 'win32', invoke: async (ch) => (ch === 'state:get' ? st : {}), on: () => () => {} }; }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(900);
  const shot = async (name, mode, set) => {
    await page.evaluate(([s]) => Object.assign(GL.S.settings, s), [set || {}]);
    await page.evaluate((m) => GL.showcase.start(true, m), mode); await page.waitForTimeout(1800);
    await page.screenshot({ path: path.join(out, name + '.png') });
    console.log(name, await page.evaluate(() => { const m = document.getElementById('scMusic'); return m.classList.contains('show') + ' ' + m.dataset.pos; }));
    await page.evaluate(() => GL.showcase.stop());
  };
  await shot('saver-default', 'saver');
  await shot('saver-clock-corner', 'saver', { saverMusicPos: 'top-right' });
  await shot('library-default', 'library', { saverMusicPos: 'bottom-right' });
  await shot('library-bl', 'library', { saverMusicPos: 'bottom-left' });
  await shot('saver-off', 'saver', { saverMusic: false });
  await page.evaluate(() => { GL.S.settings.saverMusic = true; GL.S.music.now[0].status = 'paused'; });
  await shot('saver-paused', 'saver');
  console.log('errors:', errors.join('\n') || 'none');
  await browser.close();
})();
