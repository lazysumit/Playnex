'use strict';
// Headless UI check: loads the real renderer with a mock `window.api` and screenshots each view.
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');
const state = require('./demo-state');
const out = process.argv[2] || path.join(__dirname, 'out');
fs.mkdirSync(out, { recursive: true });

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + ' @ ' + String(e.stack).split('\n').slice(1, 4).join(' | ')));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.addInitScript((st) => {
    const calls = [];
    window.__calls = calls;
    window.api = {
      platform: 'win32',
      invoke: async (ch, ...a) => { calls.push([ch, ...a]); if (ch === 'state:get') return st; if (ch === 'game:launch') return { ok: true }; return {}; },
      on: () => () => {},
    };
  }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html'));
  await page.waitForTimeout(800);
  const shot = async (name) => { await page.waitForTimeout(500); await page.screenshot({ path: path.join(out, name + '.png') }); };
  const ids = Object.keys(state.games);
  const wait = (ms) => page.waitForTimeout(ms);
  await shot('home');
  await page.evaluate(() => GL.go('library')); await shot('library');
  await page.evaluate((id) => GL.go('game', id), ids[0]); await shot('details');
  // layout check: main column must never run under the side column
  const overlap = await page.evaluate(() => { const m = document.querySelector('.d-main'), s = document.querySelector('.d-side'); return m && s ? m.getBoundingClientRect().right - s.getBoundingClientRect().left : null; });
  console.log('details main/side overlap px (must be <= 0):', overlap); if (overlap > 0) errors.push('details overlap ' + overlap);
  // showcase: idle trigger on Library after the configured delay
  await page.evaluate(() => { GL.S.settings.showcaseDelay = 1; GL.go('library'); });
  await wait(3200);
  const on = await page.evaluate(() => GL.showcase.active && document.getElementById('showcase').classList.contains('on'));
  console.log('showcase auto-started after idle:', on); if (!on) errors.push('showcase did not start');
  await wait(900); await page.screenshot({ path: path.join(out, 'showcase-1.png') });
  await page.evaluate(() => document.querySelector('#showcase') && document.querySelectorAll('.sc-bg').length); await page.waitForTimeout(100);
  await page.mouse.move(300, 300); await page.mouse.move(420, 360); await wait(300);
  const off = await page.evaluate(() => !GL.showcase.active);
  console.log('showcase closes on mouse move:', off); if (!off) errors.push('showcase did not close');
  await page.evaluate(() => { GL.S.settings.showcaseDelay = 0; GL.showcase.poke(); });
  await wait(2500);
  console.log('stays off when delay is Off:', await page.evaluate(() => !GL.showcase.active));
  await page.evaluate(() => { GL.S.settings.showcaseDelay = 10; GL.go('settings'); GL.act.stab({ v: 'library' }); }); await shot('settings-library');
  await page.evaluate(() => { GL.S.settings.showcaseDelay = 10; GL.go('home'); }); await shot('home-after');
  console.log('errors:', errors.length ? '\n' + errors.join('\n') : 'none');
  await browser.close();
  process.exitCode = errors.length ? 1 : 0;
})();
