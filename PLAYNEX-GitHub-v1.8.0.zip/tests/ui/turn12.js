'use strict';
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state'); const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
(async () => {
  const browser = await chromium.launch(); const errors = [];
  const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } });
  page.on('pageerror', (e) => errors.push(e.message));
  await page.addInitScript((st) => { window.api = { platform: 'win32', invoke: async (ch) => (ch === 'state:get' ? st : {}), on: () => () => {} }; }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(800);
  await page.evaluate(() => GL.go('settings')); await page.waitForTimeout(300);
  const tabs = await page.$$eval('.s2-nav button', (b) => b.map((x) => x.querySelector('span:last-child b, b')?.textContent || x.textContent.trim().split('\n')[0]));
  console.log('tabs:', tabs.join(' | '));
  await page.click('[data-v="library"]'); await page.waitForTimeout(300);
  console.log('library groups:', (await page.$$eval('#sBody h2', (h) => h.map((x) => x.textContent))).join(' | '));
  await page.click('[data-v="screensaver"]'); await page.waitForTimeout(300);
  console.log('screensaver groups:', (await page.$$eval('#sBody h2', (h) => h.map((x) => x.textContent))).join(' | '));
  await page.screenshot({ path: path.join(out, 'screensaver-tab.png') });
  console.log('errors:', errors.join('\n') || 'none'); await browser.close();
})();
