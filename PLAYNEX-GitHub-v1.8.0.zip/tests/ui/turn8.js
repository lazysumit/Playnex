'use strict';
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state'); const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
const art = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff3d6e"/><stop offset="1" stop-color="#2a0a5e"/></linearGradient></defs><rect width="220" height="220" fill="url(#g)"/><circle cx="110" cy="110" r="60" fill="none" stroke="#fff" stroke-width="8" opacity=".8"/></svg>');
state.version = '1.3.1';
state.music = { available: true, now: [{ appId: 'Spotify.exe', app: 'Spotify', browser: false, title: 'Blinding Lights', artist: 'The Weeknd', album: 'After Hours', status: 'playing', thumb: art }], installed: [] };
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1600, height: 900 } }); const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.addInitScript((st) => {
    window.__calls = [];
    window.api = { platform: 'win32', invoke: async (ch, ...a) => { window.__calls.push([ch, ...a]); return ch === 'state:get' ? st : {}; }, on: () => () => {} };
    const mk = (index, id) => ({ index, id, connected: true, mapping: 'standard', timestamp: 1, axes: [0, 0, 0, 0], buttons: Array.from({ length: 17 }, () => ({ pressed: false, value: 0 })), vibrationActuator: { playEffect: (t, o) => { window.__rumble = (window.__rumble || 0) + 1; return Promise.resolve('complete'); } } });
    window.__pads = [mk(0, 'Xbox 360 Controller for Windows (STANDARD GAMEPAD Vendor: 045e Product: 028e)'), mk(1, 'DualSense Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 0ce6)')];
    navigator.getGamepads = () => { window.__pads.forEach((p) => { p.timestamp++; }); return window.__pads; };
  }, state);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(900);
  const shot = async (n) => { await page.waitForTimeout(500); await page.screenshot({ path: path.join(out, n + '.png') }); };
  await page.click('.music-btn'); await shot('music-thumb'); await page.keyboard.press('Escape');
  await page.evaluate(() => GL.go('controllers')); await page.waitForTimeout(500);
  await shot('pad-idle');
  // sweep the left stick round a circle, press some buttons
  for (let i = 0; i < 60; i++) { await page.evaluate((i) => { const p = window.__pads[0]; const a = i / 60 * Math.PI * 2; p.axes[0] = Math.cos(a) * 0.98; p.axes[1] = Math.sin(a) * 0.98; p.axes[2] = Math.cos(a * 2) * .5; p.axes[3] = Math.sin(a * 2) * .5; }, i); await page.waitForTimeout(16); }
  await page.evaluate(() => { const p = window.__pads[0]; p.buttons[0].pressed = true; p.buttons[3].pressed = true; p.buttons[4].pressed = true; p.buttons[7].value = .8; p.buttons[7].pressed = true; p.buttons[6].value = .35; p.buttons[12].pressed = true; p.buttons[16].pressed = true; p.axes[0] = .6; p.axes[1] = -.5; });
  await page.click('[data-act="rumble"][data-m="heavy"]'); await page.waitForTimeout(120);
  await shot('pad-active');
  console.log('rumble calls:', await page.evaluate(() => window.__rumble || 0));
  await page.click('[data-act="padsel"][data-i="1"]'); await shot('pad-p2');
  console.log('p2 title:', await page.evaluate(() => document.getElementById('padName').textContent));
  await page.click('[data-act="padrename"]'); await page.keyboard.type('Couch pad'); await page.keyboard.press('Enter'); await page.waitForTimeout(200);
  console.log('renamed:', await page.evaluate(() => document.getElementById('padName').textContent), JSON.stringify(await page.evaluate(() => window.__calls.filter((c) => c[0] === 'settings:set'))));
  console.log('errors:', errors.length ? errors.join('\n') : 'none');
  await browser.close(); process.exitCode = errors.length ? 1 : 0;
})();
