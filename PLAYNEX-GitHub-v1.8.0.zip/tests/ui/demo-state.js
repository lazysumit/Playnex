'use strict';
// Builds a realistic fake app state (used for headless UI checks only).
const ach = require('../../main/achievements');
const { DEFAULTS } = require('../../main/store');
const { PLATFORMS } = require('../../main/scanners');

const svg = (w, h, h1, h2, label) => 'data:image/svg+xml;utf8,' + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h1},70%,38%)"/><stop offset="1" stop-color="hsl(${h2},75%,12%)"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><circle cx="${w * 0.75}" cy="${h * 0.3}" r="${h * 0.35}" fill="hsla(${h1},90%,70%,.18)"/></svg>`);

const TITLES = [
  ['steam', 'Cyberpunk 2077', 190], ['steam', 'Elden Ring', 38], ['epic', 'Fortnite', 265], ['riot', 'VALORANT', 350],
  ['gog', 'The Witcher 3: Wild Hunt', 20], ['xbox', 'Forza Horizon 5', 150], ['battlenet', 'Overwatch 2', 30],
  ['ubisoft', "Assassin's Creed Valhalla", 210], ['ea', 'Apex Legends', 5], ['rockstar', 'Grand Theft Auto V', 120],
  ['steam', 'Hades II', 330], ['steam', 'Counter-Strike 2', 45], ['custom', 'Minecraft Java', 100], ['epic', 'Rocket League', 215],
];
const DAY = 864e5, now = Date.now();
const games = {};
const sessions = [];
TITLES.forEach(([platform, title, hue], i) => {
  const id = `${platform}:${1000 + i}`;
  const g = games[id] = {
    id, appId: String(1000 + i), title, platform, installed: true, installDir: 'C:\\Games\\' + title, favorite: i % 4 === 0, hidden: false,
    added: now - (i + 3) * DAY, playtime: 0, lastPlayed: null,
    art: { cover: svg(300, 450, hue, hue + 40, title), banner: svg(1600, 900, hue, hue + 60, title), header: svg(460, 215, hue, hue + 30, title) },
    meta: { description: 'An award-winning adventure with a sprawling open world, deep systems and a story that stays with you long after the credits.', genres: ['Action', 'RPG'], developers: ['Demo Studio'], publishers: ['Demo Games'], releaseDate: 'Dec 10, 2020', metacritic: 80 + (i % 15) },
    metaFetched: now,
  };
  const n = i < 8 ? 14 - i : 1;
  for (let k = 0; k < n; k++) {
    const start = now - ((k * 3 + i) % 60) * DAY - (i * 1.7 + 12) * 36e5;
    const dur = Math.round((30 + ((k * 37 + i * 11) % 150)) * 60);
    sessions.push({ id: `s${i}-${k}`, gameId: id, start, end: start + dur * 1000, duration: dur });
    g.playtime += dur; g.lastPlayed = Math.max(g.lastPlayed || 0, start + dur * 1000);
  }
});
sessions.sort((a, b) => a.start - b.start);
const g0 = Object.values(games)[0];
g0.art.screenshots = Array.from({ length: 9 }, (_, i) => svg(1280, 720, (g0.art ? 190 : 0) + i * 25, 260 + i * 20, 'shot'));
g0.art.thumbs = g0.art.screenshots;
const data = {
  ...JSON.parse(JSON.stringify(DEFAULTS)), games, sessions, unlocked: {},
  collections: [{ id: 'c1', name: 'Co-op nights', gameIds: Object.keys(games).slice(0, 4) }, { id: 'c2', name: 'Backlog', gameIds: Object.keys(games).slice(5, 9) }],
  notifications: [{ id: 'n1', ts: now - 6e5, title: 'Library updated', body: '14 new games found.', type: 'library', read: false }],
  meta: { firstRun: false, scans: 3 },
};
const ids = Object.keys(games);
ids.slice(0, 3).forEach((id) => { games[id].art.screenshots = Array.from({ length: 10 }, (_, k) => svg(1280, 720, (k * 36) % 360, (k * 36 + 50) % 360)); });
data.captures = [0, 1, 2, 3, 4, 5].map((i) => ({ id: 'cap' + i, gameId: ids[i % 3], label: games[ids[i % 3]].title, file: 'x', url: games[ids[i % 3]].art.banner, ts: now - i * 36e5 * 5 }));
const derived = ach.evaluate(data);
module.exports = {
  games: data.games, collections: data.collections, sessions: data.sessions, settings: data.settings, profile: data.profile,
  notifications: data.notifications, captures: data.captures, meta: data.meta, running: {}, achievements: derived.list, level: derived.level,
  platforms: PLATFORMS, systemDark: true, isFullscreen: false,
};
