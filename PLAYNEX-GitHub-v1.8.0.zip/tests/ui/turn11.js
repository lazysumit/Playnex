'use strict';
const path = require('path'); const fs = require('fs'); const { chromium } = require('playwright');
const state = require('./demo-state'); const out = process.argv[2]; fs.mkdirSync(out, { recursive: true });
(async () => {
  const browser = await chromium.launch(); const errors = [];
  const page = await browser.newPage({ viewport: { width: 1600, height: 1000 } });
  page.on('pageerror', (e) => errors.push(e.message));
  const ids = Object.keys(state.games);
  const R = { v: 4, steamAppId: '1222680', reviews: { critic: [{ kind: 'critic', score: 80, who: 'IGN', author: 'Jane Doe', date: '2019-11-05', quote: 'A thrilling, beautifully lit racer with a real sense of speed and a police chase system that keeps you on edge all night long.' }, { kind: 'critic', score: 70, who: 'PC Gamer', quote: 'Great handling and a living, breathing city to drive around in, held back by a forgettable story.' }, { kind: 'critic', score: 65, who: 'GameSpot', quote: 'Heat nails the day and night split but the rubber-banding AI occasionally spoils the fun.' }], user: [{ kind: 'user', score: 7, who: 'racer99', quote: 'Best Need for Speed in years. The night time police chases are fantastic.' }, { kind: 'user', score: 3, who: 'oldschool', quote: 'Too many microtransaction-flavoured grind walls for my taste.' }] }, fetchedAt: Date.now() - 3600e3, critic: { score: 96, count: 57, headline: 'PC', word: 'Universal acclaim', platforms: [['PS3',97,50],['Xbox 360',97,58],['PS4',97,66],['Xbox One',97,14],['PC',96,57],['PS5',81,25],['Xbox Series X',79,11]].map(([platform,score,count]) => ({platform,score,count})), url: 'https://www.metacritic.com/game/need-for-speed-heat/' },
    steam: { percent: 78, total: 41234, desc: 'Mostly Positive', url: 'https://store.steampowered.com/app/1222680/', reviews: [{ text: 'Best looking night racing game. The police chases are tense and the handling feels great once you tune the cars properly.', up: true, votes: 214, hours: 42 }, { text: 'Story is forgettable and the online is dead, but the driving alone is worth the sale price.', up: false, votes: 31, hours: 9 }] },
    rawg: { rating: 3.8, count: 5120, url: 'https://rawg.io/games/need-for-speed-heat' } };
  await page.addInitScript(([st, R]) => { window.__calls = []; window.__R = R; window.api = { platform: 'win32', invoke: async (ch, ...a) => { window.__calls.push(ch); if (ch === 'state:get') return st; if (ch === 'game:ratings') return R; if (ch === 'ratings:search') return { title: a[0], ...R }; return {}; }, on: () => () => {} }; }, [state, R]);
  await page.goto('file://' + path.resolve(__dirname, '../../renderer/index.html')); await page.waitForTimeout(800);
  await page.evaluate((id) => GL.go('game', id), ids[0]); await page.waitForTimeout(1200);
  await page.screenshot({ path: path.join(out, 'details-ratings.png'), fullPage: false });
  console.log('panel tiles:', await page.evaluate(() => document.querySelectorAll('#ratingsBody .rt').length), 'reviews:', await page.evaluate(() => document.querySelectorAll('#ratingsBody .rv').length), 'calls:', await page.evaluate(() => window.__calls.filter((c) => c === 'game:ratings').length));
  for (const n of [2, 3, 5, 7]) {
    await page.evaluate(([n, id]) => { const g = GL.S.games[id]; g.ratings = JSON.parse(JSON.stringify(window.__R)); g.ratings.fetchedAt = Date.now(); g.ratings.critic.platforms = g.ratings.critic.platforms.slice(0, n); GL.go('library'); GL.go('game', id); }, [n, ids[0]]);
    await page.waitForTimeout(500); await page.screenshot({ path: path.join(out, 'plats-' + n + '.png'), clip: { x: 40, y: 600, width: 1130, height: 400 } });
  }
  await page.evaluate(() => GL.go('library')); await page.waitForTimeout(600);
  await page.click('[data-act="ratingslookup"]'); await page.fill('#rtForm input[name=q]', 'Need for Speed Heat'); await page.press('#rtForm input[name=q]', 'Enter'); await page.waitForTimeout(700);
  await page.screenshot({ path: path.join(out, 'lookup.png') }); await page.click('.rt-tabs button[data-p=user]'); await page.waitForTimeout(500); await page.screenshot({ path: path.join(out, 'lookup-players.png') });
  console.log('lookup tiles:', await page.evaluate(() => document.querySelectorAll('#rtRes .rt').length));
  await page.setViewportSize({ width: 910, height: 760 }); await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(out, 'lookup-narrow.png') });
  const ov = await page.evaluate(() => [...document.querySelectorAll('#rtRes .plat')].map((t) => { const pt = t.querySelector('.pt').getBoundingClientRect(), sb = t.querySelector('.sb').getBoundingClientRect(); return pt.right <= sb.left + 1; }));
  console.log('tiles without overlap:', ov.filter(Boolean).length + '/' + ov.length);
  await page.evaluate(() => GL.go('settings')); await page.waitForTimeout(300);
  console.log('errors:', errors.join('\n') || 'none'); await browser.close();
})();
