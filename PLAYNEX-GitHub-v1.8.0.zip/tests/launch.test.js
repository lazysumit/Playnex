'use strict';
// Simulates Windows launch errors to prove admin-only games fall back to the UAC prompt instead of failing with EACCES.
const assert = require('assert');
const cp = require('child_process');
const { EventEmitter } = require('events');

const calls = { spawn: [], exec: [] };
let spawnFail = null; let execFail = null;
cp.spawn = (exe, args, opts) => {
  calls.spawn.push([exe, args, opts]);
  const c = new EventEmitter(); c.unref = () => {};
  setImmediate(() => (spawnFail ? c.emit('error', Object.assign(new Error('spawn ' + exe + ' ' + spawnFail.code), spawnFail)) : c.emit('spawn')));
  return c;
};
cp.execFile = (file, args, opts, cb) => { calls.exec.push([file, args]); setImmediate(() => (execFail ? cb(Object.assign(new Error('cancelled by the user'), {}), '', 'The operation was canceled by the user.') : cb(null, '', ''))); };
const { Tracker } = require('../main/tracker');

let passed = 0;
const t = async (name, fn) => { calls.spawn.length = 0; calls.exec.length = 0; spawnFail = execFail = null; try { await fn(); passed++; console.log('  ok  ' + name); } catch (e) { console.error('FAIL  ' + name + '\n' + e.stack); process.exitCode = 1; } };
const mk = () => new Tracker({ getGames: () => ({}), recordSession() {}, onChange() {}, openExternal: async () => {} });

(async () => {
  await t('normal game starts directly, no UAC prompt', async () => {
    const g = { id: 'a', launch: { type: 'exe', target: 'C:\\Games\\a.exe' } };
    await mk().launch(g); assert.strictEqual(calls.spawn.length, 1); assert.strictEqual(calls.exec.length, 0); assert.ok(!g.needsAdmin);
  });
  for (const err of [{ code: 'EACCES' }, { code: 'EPERM' }, { code: 'UNKNOWN', errno: -4094 }, { code: 'X', errno: 740 }]) {
    await t(`admin-only game (${err.code}) falls back to Run-as-administrator`, async () => {
      spawnFail = err; const g = { id: 'b', launch: { type: 'exe', target: "C:\\Games\\it's admin.exe", args: '-windowed' } };
      await mk().launch(g);
      assert.strictEqual(calls.exec.length, 1); const ps = calls.exec[0][1].join(' ');
      assert.match(ps, /-Verb RunAs/); assert.match(ps, /it''s admin\.exe/); assert.match(ps, /-ArgumentList '-windowed'/);
      assert.strictEqual(g.needsAdmin, true);
    });
  }
  await t('remembered: next launch goes straight to the prompt', async () => {
    const g = { id: 'c', needsAdmin: true, launch: { type: 'exe', target: 'C:\\Games\\c.exe' } };
    await mk().launch(g); assert.strictEqual(calls.spawn.length, 0); assert.strictEqual(calls.exec.length, 1);
  });
  await t('declined UAC gives a clear message', async () => {
    spawnFail = { code: 'EACCES' }; execFail = true; const g = { id: 'd', launch: { type: 'exe', target: 'C:\\Games\\d.exe' } };
    await assert.rejects(() => mk().launch(g), /declined/);
    assert.ok(!g.needsAdmin);
  });
  await t('other errors (file missing) are not treated as admin', async () => {
    spawnFail = { code: 'ENOENT' }; const g = { id: 'e', launch: { type: 'exe', target: 'C:\\nope.exe' } };
    await assert.rejects(() => mk().launch(g), /ENOENT/); assert.strictEqual(calls.exec.length, 0);
  });
  console.log(`${passed} passed`);
  process.exit(process.exitCode || 0);
})();
