'use strict';
const assert = require('assert'); const R = require('../main/ratings');
const html = (o) => `<html><head><title>Need for Speed Heat Reviews</title><script type="application/ld+json">${JSON.stringify(o)}</script></head></html>`;
let n = 0; const t = (name, f) => { try { f(); n++; console.log('  ok  ' + name); } catch (e) { console.error('FAIL ' + name + '\n' + e.stack); process.exitCode = 1; } };
t('slug', () => assert.strictEqual(R.slug("Need for Speed™ Heat"), 'need-for-speed-heat'));
t('slug candidates strip editions & subtitles', () => { const c = R.slugCandidates('Need for Speed Heat Deluxe Edition'); assert.ok(c.includes('need-for-speed-heat')); assert.ok(R.slugCandidates("Marvel's Spider-Man: Remastered").includes('marvels-spider-man')); });
t('metacritic ld+json (nested)', () => { const m = R.parseMetacritic(html({ '@graph': [{ '@type': 'VideoGame', name: 'Need for Speed Heat', aggregateRating: { ratingValue: '72', reviewCount: '56', bestRating: '100' } }] })); assert.deepStrictEqual([m.score, m.count, m.name], [72, 56, 'Need for Speed Heat']); });
t('metacritic missing -> null', () => { assert.strictEqual(R.parseMetacritic('<html></html>'), null); assert.strictEqual(R.parseMetacritic(html({ a: 1 })), null); });
t('steam summary + reviews', () => { const s = R.parseSteam({ query_summary: { total_reviews: 200, total_positive: 150, review_score_desc: 'Very Positive' }, reviews: [{ review: '[b]Great[/b] game with fun driving and a solid story overall', voted_up: true, votes_up: 9, author: { playtime_forever: 600 } }, { review: 'short', voted_up: false }] }, 1); assert.deepStrictEqual([s.percent, s.total, s.desc, s.reviews.length, s.reviews[0].hours], [75, 200, 'Very Positive', 1, 10]); assert.ok(!/\[b\]/.test(s.reviews[0].text)); });
t('steam none -> null', () => assert.strictEqual(R.parseSteam({ query_summary: { total_reviews: 0 } }, 1), null));
t('score words', () => assert.deepStrictEqual([92, 80, 72, 30, 5].map(R.scoreWord), ['Universal acclaim', 'Generally favorable', 'Mixed or average', 'Generally unfavorable', 'Overwhelming dislike']));
t('metacritic feed parse (critic + user shapes)', () => {
  const c = R.parseMcFeed({ data: { items: [{ quote: 'A thrilling, beautifully lit racer with a great sense of speed.', score: 80, publicationName: 'IGN', author: 'Jo', date: '2019-11-05' }, { quote: 'short' }] } }, 'critic');
  assert.deepStrictEqual([c.length, c[0].who, c[0].score], [1, 'IGN', 80]);
  const u = R.parseMcFeed({ data: { items: [{ quote: 'Fun but the story is quite forgettable overall.', score: 7, author: 'racer99' }] } }, 'user'); assert.strictEqual(u[0].who, 'racer99');
  assert.deepStrictEqual(R.parseMcFeed(null, 'user'), []);
});
t('metacritic html fallback parse', () => {
  const h = '<div class="c-siteReview g-grid"><div class="c-siteReviewHeader_publicationName">PC Gamer</div><div class="c-siteReviewScore u-flexbox"><span>85</span></div><div class="c-siteReview_quote"><span>Great handling and a living, breathing city to drive around in.</span></div></div>';
  const r = R.parseMcHtml(h, 'critic'); assert.deepStrictEqual([r.length, r[0].score, r[0].who], [1, 85, 'PC Gamer']);
});
t('platform tiles from html (score after text)', () => {
  const tile = (pf, n, sc) => `<a class="c-gamePlatformTile" href="/game/gta-v/?platform=${pf}"><svg aria-label="x"></svg><div>Based on <span>${n}</span> Critic Reviews</div><div class="score"><span>${sc}</span></div></a>`;
  const h = tile('ps3', 50, 97) + tile('xbox-360', 58, 97) + tile('pc', 57, 96) + tile('xbox-series-x', 11, 79);
  const p = R.parsePlatformsHtml(h);
  assert.deepStrictEqual(p.map((x) => [x.platform, x.score, x.count]), [['PS3', 97, 50], ['Xbox 360', 97, 58], ['PC', 96, 57], ['Xbox Series X', 79, 11]]);
});
t('platform tiles from html (score before text)', () => {
  const tile = (pf, n, sc) => `<a href="/game/x/?platform=${pf}"><div class="score"><span>${sc}</span></div><div>Based on ${n} Critic Reviews</div></a>`;
  const p = R.parsePlatformsHtml(tile('ps4', 66, 97) + tile('ps5', 25, 81));
  assert.deepStrictEqual(p.map((x) => [x.platform, x.score]), [['PS4', 97], ['PS5', 81]]);
});
t('platform tiles from json', () => {
  const p = R.parsePlatformsJson({ components: [{ data: { item: { platforms: [{ platform: 'PC', criticScoreSummary: { score: 96, reviewCount: 57 } }, { platform: { name: 'PS5' }, score: 81, reviewCount: 25 }, { platform: 'PC', score: 1 }] } } }] });
  assert.deepStrictEqual(p.map((x) => [x.platform, x.score, x.count]), [['PC', 96, 57], ['PS5', 81, 25]]);
});
t('platform names', () => assert.deepStrictEqual(['xbox-series-x', 'Xbox One', 'switch-2', 'ps-vita'].map(R.platName), ['Xbox Series X', 'Xbox One', 'Switch 2', 'PS Vita']));
console.log(n + ' passed');
