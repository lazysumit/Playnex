'use strict';
// The installer's identity must never change, or Windows installs a new version as a second app instead of an upgrade.
const assert = require('assert');
const pkg = require('../package.json');
const fs = require('fs'); const path = require('path');
const LOCKED_APP_ID = 'com.local.gamelauncher';   // internal id only; the visible name is productName
assert.strictEqual(pkg.build.appId, LOCKED_APP_ID, 'build.appId changed: this breaks upgrades');
assert.ok(!pkg.build.nsis.guid, 'do not set nsis.guid: it must stay derived from the locked appId');
assert.ok(fs.readFileSync(path.join(__dirname, '../main/main.js'), 'utf8').includes(`setAppUserModelId('${LOCKED_APP_ID}')`), 'AppUserModelId must match appId');
assert.strictEqual(pkg.build.productName, 'PLAYNEX');
console.log('2 passed (identity)');
